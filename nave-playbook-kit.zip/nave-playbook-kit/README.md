# The Nave Playbook — the tools 🛸

The build-it-yourself tools that come with **"How I Make a Month of Quality Content in a Day"**
by Enrique "Quique" Marquez — nave.infinitxai.com · @enriquemarq-0.

These are the **actual** Claude Code skills, agents, and a dynamic-workflow example I use to turn
one footage drop into a month of content. They're plain text. Read them, edit them, keep them.
Nothing is hidden — that's the whole point.

## What's inside

- `skills/extracting-transcripts` — word-level transcripts via AssemblyAI Universal-3 Pro. The spine.
- `skills/footage-intelligence` — reads a whole footage drop (who's on screen, what's usable, what's
  said) into one library doc. **This is the dynamic workflow** (`scripts/footage-intelligence.workflow.js`).
- `skills/zernio-publish` — publish to every platform from one place (platform-native captions).
- `skills/zernio-comment-to-dm` — turn "comment KEYWORD → I'll DM it" into an automation.
- `agents/humanizer` — strips the AI tells out of any caption/script before you save it.
- `workflows/` — a copy of the dynamic workflow, where you'd look for it.

Built on your own keys (AssemblyAI + Zernio). The Zernio skills also live, public, at
github.com/Enriquemarq1/zernio-library-skills.

## Install (2 minutes)

1. Drop the `skills/`, `agents/`, and `workflows/` folders into your project's `.claude/` directory
   (so you have `.claude/skills/...`, `.claude/agents/...`).
2. Copy `.env.example` to `.env` and fill in your own keys (see `SETUP.md`). You bring your own —
   no middleman, no markup.
3. Open Claude Code in the project and say *"transcribe this and pull the best clips"* — it will
   discover the skills automatically.

## The honest upgrade

By hand, running all of this is a full day a month. **Nave** is this exact kit, assembled, installed
on your machine, tuned to your brand, and run for you — the day compressed to about an hour.
It's optional. These tools work without it. → **nave.infinitxai.com**

*Build first. Give first. Own it.*
