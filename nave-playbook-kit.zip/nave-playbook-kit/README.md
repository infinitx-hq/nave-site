# The Nave Playbook Kit 🛸

The free, build-it-yourself content crew from **"How I Make a Month of Quality Content in a Day"**
by Enrique "Quique" Marquez — nave.infinitxai.com · @enriquemarq-0.

These are the **actual** Claude Code skills, agents, and a dynamic-workflow example I use to turn
one footage drop into a month of content. They're plain text. Read them, edit them, keep them.
Nothing is hidden — that's the whole point.

## What's inside

- `skills/` — the recipes Claude Code follows the same way every time (transcribe, score clips,
  reframe, edit, build carousels, publish).
- `agents/` — the specialist workers (a clip-editor and its little crew, plus the humanizer that
  de-AIs every line before save).
- `workflows/` — a readable **dynamic workflow** that orchestrates the agents: fan the per-clip
  work out across many editors at once, then assemble the batch.

## Install (2 minutes)

1. Drop the `skills/`, `agents/`, and `workflows/` folders into your project's `.claude/` directory
   (so you have `.claude/skills/...`, `.claude/agents/...`).
2. Copy `.env.example` to `.env` and fill in your own keys (see `SETUP.md`). You bring your own —
   no middleman, no markup.
3. Open Claude Code in the project and say *"transcribe this and pull the best clips"* — it will
   discover the skills automatically.

## The honest upgrade

By hand, running all of this is a full day a month. **Nave** is this exact kit, assembled, installed
on your machine, tuned to your brand, and run for you — the day compressed to about an hour.
It's optional. The kit works without it. → **nave.infinitxai.com**

*Build first. Give first. Own it.*
