# SETUP — your keys, your accounts

Everything here runs on **your own** keys. Put them in a `.env` file at your project root.

```
# AssemblyAI — word-level transcripts (Universal-3 Pro). ~$0.27/hr of audio.
# Used by: extracting-transcripts, footage-intelligence.
# Get it free at assemblyai.com → dashboard → API key.
ASSEMBLYAI_API_KEY=

# Zernio — multi-platform publishing + comment-to-DM + analytics. Your accounts, your profile.
# Used by: zernio-publish, zernio-comment-to-dm.
ZERNIO_API_KEY=
ZERNIO_PROFILE_ID=
```

That's it. The skills here run on those two keys. The `humanizer` agent needs no key, and the
`footage-intelligence` scripts run on plain Python 3 (see that skill's folder for any extras).

No Anthropic API key needed — these run inside your existing Claude Code subscription.

> Want the rest of the system (the face-tracking reframe engine, the Hyperframes editing
> framework, the full format crew)? That's the assembled department — it's Nave.
> → nave.infinitxai.com
