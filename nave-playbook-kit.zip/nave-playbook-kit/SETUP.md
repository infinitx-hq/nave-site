# SETUP — your keys, your accounts

Everything here runs on **your own** keys. Put them in a `.env` file at your project root.

```
# AssemblyAI — word-level transcripts (Universal-3 Pro). ~$0.27/hr of audio.
# Get it free at assemblyai.com → dashboard → API key.
ASSEMBLYAI_API_KEY=

# Zernio — multi-platform publishing + comment-to-DM. Your accounts, your profile.
ZERNIO_API_KEY=
ZERNIO_PROFILE_ID=

# KIE.ai — optional. AI image/voice/video to fill a footage GAP, not replace footage.
KIE_API_KEY=
```

Render engine (for the edit step): `npm i -g hyperframes`, then `npx hyperframes render`.
Reframe engine (clip-extractor / clip-machine): Python 3.12, `pip install -r requirements.txt`
inside `skills/clip-machine/clip_extractor/`. The face-detection model files are downloaded on
first run (they're not shipped in this kit to keep it small).

No Anthropic API key needed — the operator is your existing Claude Code subscription.
