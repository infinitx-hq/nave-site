# MANIFEST

## Skills
- `skills/extracting-transcripts/`
- `skills/footage-intelligence/`
- `skills/zernio-comment-to-dm/`
- `skills/zernio-publish/`

## Agents
- `agents/humanizer.md`

## Workflows
- `workflows/` — dynamic-workflow example(s)

_Total text files: 34_
