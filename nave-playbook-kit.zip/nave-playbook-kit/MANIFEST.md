# MANIFEST

## Skills
- `skills/extracting-transcripts/`
- `skills/clip-selection/`
- `skills/clip-extractor/`
- `skills/footage-intelligence/`
- `skills/carousel/`
- `skills/hyperframes-edit/`
- `skills/video-download/`
- `skills/social-media-publishing/`
- `skills/clip-machine/`

## Agents
- `agents/clip-editor.md`
- `agents/scene-director.md`
- `agents/move-designer.md`
- `agents/sound-designer.md`
- `agents/asset-fetcher.md`
- `agents/humanizer.md`

## Workflows
- `workflows/` — dynamic-workflow example(s)

_Total text files: 71_
