/**
 * clip-machine.workflow.js — a DYNAMIC WORKFLOW example (Claude Code).
 *
 * This is the readable shape of the orchestration that turns ONE footage drop into a
 * finished batch of short clips — the "kick it off and walk away" piece from the playbook.
 *
 * A workflow is a script that ORCHESTRATES agents. Instead of editing clip 1, then clip 2,
 * then clip 3, it fans every clip out to its own editor agent at the same time, then
 * collects them back into one batch. One command moves the whole month.
 *
 * Run it from Claude Code with the Workflow tool. It's deterministic: same input, same run,
 * and it never gets tired on clip number nine. Swap the agent names / schema for your own.
 *
 * No keys, no private data — this is a teaching example. Adapt the paths and the slate counts.
 */

export const meta = {
  name: 'clip-machine',
  description: 'One footage drop -> a finished batch of 9:16 clips, fanned out across editor agents',
  phases: [
    { title: 'Understand', detail: 'transcribe + score the strongest moments' },
    { title: 'Edit', detail: 'one editor agent per clip, in parallel' },
    { title: 'Assemble', detail: 'quality-gate + stage the batch for approval' },
  ],
}

// The schema each "understand" agent returns — a ranked shortlist of moments.
const MOMENTS = {
  type: 'object',
  properties: {
    moments: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          startMs: { type: 'number' },
          endMs: { type: 'number' },
          why: { type: 'string' },
        },
        required: ['title', 'startMs', 'endMs'],
      },
    },
  },
  required: ['moments'],
}

const SOURCE = args?.source || 'footage/your-drop.mp4'   // pass your file via Workflow args
const MAX_CLIPS = args?.maxClips || 10

// ── Phase 1: understand the drop ────────────────────────────────────────────
// One agent transcribes (AssemblyAI Universal-3 Pro, word-level) and scores every
// candidate moment, then hands back a ranked shortlist with exact in/out times.
phase('Understand')
const picked = await agent(
  `Transcribe ${SOURCE} with AssemblyAI Universal-3 Pro (word-level), then score every ` +
  `candidate moment on hook strength, whether it teaches or proves, standalone clarity, ` +
  `emotion, and shareability. Return the top ${MAX_CLIPS} as {title, startMs, endMs, why}.`,
  { label: 'understand', phase: 'Understand', schema: MOMENTS }
)
const moments = (picked?.moments || []).slice(0, MAX_CLIPS)
log(`picked ${moments.length} moments`)

// ── Phase 2 + 3: edit each clip in PARALLEL, then quality-gate each as it lands ──
// pipeline() runs each moment through BOTH stages independently — no barrier — so clip A
// can be quality-gating while clip B is still rendering. Wall-clock = the slowest single
// clip, not the sum.
const finished = await pipeline(
  moments,
  // stage 1 — reframe to 9:16 + edit to the standard (captions, keyword pops, title, brand color)
  (m, _orig, i) => agent(
    `Cut ${SOURCE} from ${m.startMs}ms to ${m.endMs}ms on a completed sentence (+~2s tail). ` +
    `Face-track reframe 16:9 -> 9:16 (caption-safe band, no black gaps). Edit to the standard: ` +
    `word-level burn-in captions, pop the 1-2 key words in the brand accent, one-line title card. ` +
    `Title: "${m.title}". Return the output path.`,
    { label: `edit:${i + 1}`, phase: 'Edit' }
  ),
  // stage 2 — quality gate (PUBLISH / FIX / REJECT) before it counts as done
  (clipPath, m, i) => agent(
    `Quality-gate this clip: ${clipPath}. Hook in first 3s? Captions legible muted? Starts on ` +
    `the point? Sounds like the creator? Return {verdict: PUBLISH|FIX|REJECT, note}.`,
    { label: `gate:${i + 1}`, phase: 'Assemble' }
  ).then(v => ({ moment: m, clipPath, ...v }))
)

// ── Assemble the batch (nothing auto-posts — staged for the human) ──────────
const keepers = finished.filter(Boolean).filter(c => c.verdict === 'PUBLISH')
log(`${keepers.length}/${finished.length} cleared the quality gate`)

return {
  source: SOURCE,
  clips: keepers,
  staged: true,            // a workflow STAGES — the human says "schedule it", then it fires
  note: 'Review the batch, then publish. The workflow never auto-posts.',
}
