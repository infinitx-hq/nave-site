---
name: social-media-publishing
description: Stage and publish a piece of content across platforms (YouTube, Instagram, TikTok, Threads, LinkedIn, etc.) behind an approval gate. Multi-platform in one request via Zernio. Use when a rendered clip or carousel is ready to ship across channels with platform-native captions.
---

# Social Media Publishing

Take a finished piece (a short clip, a carousel, a long-form video) and stage it across every
platform you publish to — with platform-native captions and a staggered schedule — then publish
on your say-so. Built around **Zernio** so one request fans out to all your accounts.

**The rule that never bends:** this skill *stages*, it does not auto-post. It lays out the
schedule, you review it, you say "schedule it," and only then does it fire. Your accounts, your
keys, your approval.

## What it does

1. **Reads the piece** and its transcript, and writes a **platform-native caption** for each
   target (the LinkedIn version argues, the IG version hooks, the YouTube version describes) —
   not one caption copy-pasted everywhere.
2. **Routes the CTA** per platform (see `reference/cta-routing.md`) — the give-first
   comment-keyword-to-DM move, never a reach-killing link in the body.
3. **Stages a staggered schedule** across the week behind your approval gate.
4. **Publishes via Zernio** once you approve — multi-platform in a single API call.

## Setup (your keys, your accounts)

Keys come from your project's `.env`:

```
ZERNIO_API_KEY=        # your Zernio key — Authorization: Bearer <key>
ZERNIO_PROFILE_ID=     # which set of social accounts to publish to
```

Zernio authenticates with a Bearer API key. The full API surface (posts, schedule, the
comment-to-DM automation, the per-platform account IDs) is in `reference/zernio-openapi.yaml`.
Per-platform best practices (formats, caption shape, what each algorithm rewards) live in
`reference/platforms/*.md`. YouTube tag/length limits are in `reference/youtube-tag-rules.md`.

## The flow

1. Confirm the piece is rendered and quality-gated.
2. Generate the per-platform captions from the transcript.
3. Pick the CTA keyword per post; rewrite the caption to "comment KEYWORD and I'll DM it."
4. Stage the schedule and show it to the user.
5. On approval, publish through Zernio and record the post IDs.

Pair this with the `zernio-comment-to-dm` setup so each reel turns comments into conversations
automatically — same keyword logic, on your own account.
