# YouTube Tag Rules — Structure, Limits, Pre-Flight Validation

Called from `youtube-package` Step 3B. Tags are the most commonly rejected part of a YouTube post — these rules exist because the official limits are stricter than documented.

---

## Tag Structure

Tags should be **simple, short, and psychologically aligned** with how real people search.

| Category | Count | Description |
|----------|-------|-------------|
| Core topic | 3-5 | What the video IS about |
| Outcome | 2-3 | What the viewer GETS |
| Identity | 2-3 | WHO this is for |
| Tool/method | 2-3 | Specific tools/systems shown |
| Discovery | 2-3 | Adjacent topics for related audiences |

Target **12-20 tags total.** Any more and you run into the length rules below.

---

## Hard Limits

- **Each tag under 28 characters.** YouTube API rejects anything longer with `invalidTags`.
- Keep tags **1-3 words each** (4 words only if total stays under 28 chars).
- No filler words (`how to use`, `best way to`, `the most common`).
- No duplicating the title verbatim.

---

## The "500 character" limit is actually 300

**Discovered 2026-03-07:** YouTube's stated "500 character" limit counts MORE than just tag text. Separators (commas) between tags count toward the total.

Safe formula:

```
youtube_total = sum(len(tag) for tag in tags) + (num_tags - 1)
```

**Keep `youtube_total` ≤ 300 to be safe.**

- 20 tags at 280 chars text (299 with commas) → works
- 31 tags at 449 chars text (479 with commas) → rejected as "Video tags are invalid"
- **Max tested working: 20 tags, 280 chars text**

If you hit the limit, cut from the Discovery category first — those are the lowest-value tags.

---

## API format (for Zernio POST)

**Comma-separated string, NOT a JSON array.** Per Zernio docs it says `string[]`, but YouTube requires a single comma-separated string.

```json
{
  "platformSpecificData": {
    "tags": "claude code,clip extractor,short form content,ai video editing"
  }
}
```

Passing a JSON array silently breaks the tags (they get uploaded but don't route for search). This is a Zernio-docs-lies-about-YouTube gotcha — trust the string format.

---

## Pre-Flight Validation (MANDATORY before POST)

Loop through every tag and verify length before posting. This script catches both the per-tag limit (28 chars) and the combined limit (300 chars) in one pass:

```bash
python3 -c "
tags = 'YOUR_COMMA_SEPARATED_TAGS'
over = []
total = 0
count = 0
for t in [x.strip() for x in tags.split(',')]:
    count += 1
    total += len(t)
    ok = '✅' if len(t) < 28 else '❌ OVER'
    print(f'{ok} ({len(t)} chars) \"{t}\"')
    if len(t) >= 28: over.append(t)
combined = total + (count - 1)
print(f'')
print(f'{count} tags, {total} chars text, {combined} chars with commas')
status = 'OK' if (combined <= 300 and not over) else 'REJECT — fix and retry'
print(f'Status: {status}')
"
```

**If ANY tag is ≥ 28 characters OR combined total exceeds 300, shorten and re-validate.**

YouTube API rejects the **entire post** with `invalidTags` if even one tag exceeds the limit. This is expensive — you lose the upload and have to retry the whole POST, including the media items that each temp URL will only accept once.

Pre-flight validation is mandatory, not optional.
