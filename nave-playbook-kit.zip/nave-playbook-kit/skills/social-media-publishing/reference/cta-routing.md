# CTA Routing & Creator Configuration

Called from `publish` and format-specific packages (`youtube-package`, etc.) when building descriptions, first comments, and bio links. Everything here is **config-driven** — the CTA channel, text, and links come from `config.json`, not hardcoded in skills.

---

## CTA Config Schema (from config.json)

```json
{
  "cta": {
    "channel": "whatsapp",
    "contact_name": "the agent",
    "primary_text": "Talk with the agent to get the free resources, repo access, and community invite",
    "primary_link": "https://wa.me/1234567890",
    "per_platform_links": {
      "youtube": "https://wa.me/1234567890?text=Hey+the agent+from+YouTube",
      "instagram": "https://wa.me/1234567890?text=Hey+the agent+from+Instagram",
      "tiktok": "https://wa.me/1234567890?text=Hey+the agent+from+TikTok",
      "linkedin": "https://wa.me/1234567890?text=Hey+the agent+from+LinkedIn",
      "threads": "https://wa.me/1234567890?text=Hey+the agent+from+Threads"
    },
    "community_link": null,
    "affiliate_links": {}
  }
}
```

**Fields:**

| Field | Type | Required | Purpose |
|-------|------|----------|---------|
| `cta.channel` | `string` | Yes | Primary CTA channel: `whatsapp`, `email`, `discord`, `calendly`, `telegram`, `custom` |
| `cta.contact_name` | `string` | Yes | Who the lead will interact with (shown in CTA text) |
| `cta.primary_text` | `string` | Yes | The CTA sentence (configurable per creator — default provided at onboarding) |
| `cta.primary_link` | `string` | Yes | The main CTA URL (channel-dependent: wa.me link, mailto:, Discord invite, Calendly URL, etc.) |
| `cta.per_platform_links` | `object` | No | Per-platform URL overrides for attribution tracking (e.g., different `?text=` params per platform) |
| `cta.community_link` | `string` | No | Optional community link (Skool, Discord server, Slack workspace) |
| `cta.affiliate_links` | `object` | No | Optional affiliate URLs keyed by partner name |

If `per_platform_links.{platform}` exists, use it. Otherwise fall back to `primary_link`.

---

## CTA Placement Rules (by context)

### In description / caption (above the fold)

The CTA should appear in the first 2 lines of the description (YouTube) or first paragraph of the caption (Instagram, LinkedIn, TikTok). This is what's visible before "Show more" / "...more".

```
{CTA_EMOJI} {cta.primary_text}: {platform_link}
```

Example (WhatsApp creator):
```
📞 Talk with the agent to get the free resources, repo access, and community invite: https://wa.me/...
```

Example (Email-based B2B):
```
📧 Get the free implementation guide: hello@company.com
```

Example (Discord community):
```
💬 Join the builder community: https://discord.gg/...
```

**The exact text comes from `config.cta.primary_text` — the agent never invents CTA copy.** If the field is empty, ask the creator what their CTA should say during onboarding.

### In first comment (when platform supports it)

```
[Engagement question about the video topic] 👇

{cta.primary_text}:
{CTA_EMOJI} {platform_link}
```

The engagement question is crafted by the format skill (e.g., `youtube-package` writes it based on the video content). The CTA text and link come from config.

### In bio / profile

For platforms without clickable in-caption links (Instagram), the CTA link goes in the bio. the agent can suggest the bio text but the creator sets it manually.

---

## Per-Platform Link Resolution

When building a post for platform X:

1. Check `config.cta.per_platform_links.{X}` — if it exists, use it (has attribution tracking)
2. Fall back to `config.cta.primary_link` — universal link without attribution
3. If neither exists, skip the CTA link and flag to the creator: "No CTA link configured for {X}"

Per-platform links are valuable for attribution (the creator knows which platform a lead came from). But they're optional — a single `primary_link` works fine for creators who don't need attribution tracking.

---

## Creator Profile Fields (from config.json)

| Template var | config.json source | Purpose |
|--------------|-------------------|---------|
| `{creator_name}` | `first_name` + `last_name` | Description signature |
| `{youtube_handle}` | `zernio.accounts.youtube.username` | Social links |
| `{instagram_handle}` | `zernio.accounts.instagram.username` | Social links |
| `{tiktok_handle}` | `zernio.accounts.tiktok.username` | Social links |
| `{threads_handle}` | `zernio.accounts.threads.username` | Social links |
| `{linkedin_handle}` | `zernio.accounts.linkedin.username` | Social links |
| `{twitter_handle}` | `zernio.accounts.twitter.username` | Social links |
| `{brand_color}` | `style.brand_color` | Thumbnail accent + description branding |

Zernio account IDs come from `config.zernio.accounts.{platform}.account_id`. Profile ID from `config.zernio.profile_id`.

---

## Social Links Block (for description)

Only include platforms the creator has connected (check `config.zernio.accounts`):

```
🔗 Connect with me:
YouTube: https://www.youtube.com/@{youtube_handle}
LinkedIn: https://www.linkedin.com/in/{linkedin_handle}/
Instagram: https://www.instagram.com/{instagram_handle}/
TikTok: https://www.tiktok.com/@{tiktok_handle}
Threads: https://www.threads.net/@{threads_handle}
```

---

## Affiliate Links (optional)

Only include if `config.cta.affiliate_links` has entries:

- **Zernio:** `https://zernio.com?atp={creator_handle}`
- **Community:** `{cta.community_link}` (Skool, Discord, Slack — whatever the creator uses)

---

## Branding

- **Creator brand color:** `{brand_color}` from `config.style.brand_color`. Used in thumbnails and description accent elements.
- **Thumbnail accent default:** Orange `#F97316` when no brand color is set.

---

## CTA Channel Examples

| Channel | `primary_link` format | Best for |
|---------|----------------------|----------|
| WhatsApp | `https://wa.me/{number}?text={prefilled}` | Personal brands, creators, coaches |
| Email | `mailto:{email}?subject={subject}` | B2B SaaS, professional services |
| Discord | `https://discord.gg/{invite}` | Developer communities, gaming, tech |
| Calendly | `https://calendly.com/{user}/{event}` | B2B sales, consulting, coaching |
| Telegram | `https://t.me/{channel}` | Tech audiences, crypto, international |
| Custom | Any URL | Landing pages, Typeform, Gumroad, etc. |

The channel choice is the creator's — set during onboarding, stored in config.json, never assumed by the agent.
