---
name: video-download
description: "Download a video from YouTube (or any yt-dlp-supported site) to local disk as an mp4 ready for the clip pipeline. Uses yt-dlp with cookies-file fallback for member-only or region-locked content. Use for 'download youtube video', 'fetch video', 'pull this video down', 'ingest source video', 'grab the source mp4', 'download for clipping'."
argument-hint: [video_url]
allowed-tools:
  - Bash(yt-dlp:*)
  - Bash(ffprobe:*)
  - Bash(mkdir:*)
  - Read
  - Write
metadata:
  category: video-production
  version: 1.0
  phase: 0
---

# Video Download (yt-dlp)

Download the source video for downstream clipping. yt-dlp is the canonical tool — supports YouTube, Vimeo, Twitter/X video, TikTok, and most other public video hosts. Output is always a single merged mp4 (best video + best audio) ready for `clip-extractor` and `clip-selection`.

**Why yt-dlp not Apify:** yt-dlp runs locally with zero per-video cost, no API key, no credits. Apify is a fallback if you need to scale across many cloud workers — for the local engine running on a creator's machine, yt-dlp is correct.

---

## Prerequisites

```bash
# Install yt-dlp (one-time)
# macOS
brew install yt-dlp
# Windows
winget install yt-dlp.yt-dlp
# Linux / pip
python -m pip install -U yt-dlp

# Verify
yt-dlp --version
ffmpeg -version | head -1   # required for merging
```

**RULE:** ffmpeg is required for the merge step (`bv*+ba` = best video + best audio, separate streams that yt-dlp combines via ffmpeg). If ffmpeg is missing, the download will succeed but produce two unmerged files instead of one mp4.

---

## Workflow

| Phase | Name | What Happens |
|-------|------|-------------|
| 0 | CONTEXT | Validate URL, check yt-dlp + ffmpeg present, ensure output dir exists |
| 1 | DOWNLOAD | Run yt-dlp with the canonical format selector |
| 2 | VERIFY | Run ffprobe on the output file; reject if 0 bytes or unreadable |
| 3 | METADATA | Capture title, duration, uploader → emit `source.metadata.json` |
| 4 | EVOLVE | Note any new failure mode (geo-block, age-gate, member-only) |

### Phase 0: CONTEXT

1. URL must look like a video URL — basic shape check, not URL parsing gymnastics.
2. Check tools installed: `yt-dlp --version` and `ffmpeg -version`.
3. Ensure target output directory exists: `mkdir -p {output_dir}`.

### Phase 1: DOWNLOAD

**Canonical command** (use this for 95% of cases):

```bash
yt-dlp \
  -f "bv*+ba/b" \
  --merge-output-format mp4 \
  -o "{output_dir}/source.%(ext)s" \
  "{video_url}"
```

Format selector explained:
- `bv*` — best video stream of any codec/container
- `ba` — best audio stream
- `bv*+ba` — combine them (yt-dlp invokes ffmpeg under the hood)
- `/b` — fallback to single best file if no separate streams available
- `--merge-output-format mp4` — final container is always mp4, even if source was webm

**With cookies (for member-only / age-gated / region-locked content):**

```bash
yt-dlp \
  -f "bv*+ba/b" \
  --merge-output-format mp4 \
  --cookies "{cookies_file}" \
  -o "{output_dir}/source.%(ext)s" \
  "{video_url}"
```

Cookies file is in Netscape format. Easiest way to produce it: install the [Get cookies.txt LOCALLY](https://chrome.google.com/webstore/detail/get-cookiestxt-locally/cclelndahbckbenkjhflpdbgdldlbecc) Chrome extension, sign into the source site, export, save as `cookies.txt`.

**With format/quality cap** (rarely needed — long-form-to-clips wants the highest quality available):

```bash
# Cap at 1080p if disk space is tight
yt-dlp -f "bv[height<=1080]+ba/b" ...
```

### Phase 2: VERIFY

After download, confirm the file is real:

```bash
ffprobe -v quiet -print_format json -show_format -show_streams "{output_dir}/source.mp4"
```

Reject if:
- File missing or 0 bytes → throw
- `format.duration` missing or < 1 second → throw
- No video stream → throw

### Phase 3: METADATA

Emit a sidecar `source.metadata.json` next to the file with what we know about the source. Downstream skills use this for context (clip captions, posting descriptions, attribution):

```bash
yt-dlp --skip-download --print-json "{video_url}" > "{output_dir}/source.metadata.json"
```

The JSON includes `title`, `uploader`, `upload_date`, `duration`, `description`, `thumbnail`, `webpage_url`, `tags`, etc. Downstream code reads what it needs and ignores the rest.

### Phase 4: EVOLVE

If the download fails, the error pattern matters more than the error itself:

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| `Sign in to confirm your age` | Age-gated YouTube video | Add `--cookies cookies.txt` from a logged-in session |
| `Video unavailable` (region) | Geo-blocked | Cookies from a region-allowed account, OR a VPN at the network level |
| `Members-only content` | Channel membership required | Member-account cookies |
| `HTTP Error 429: Too Many Requests` | yt-dlp got rate-limited | Wait 15 min, retry. If persistent, add `--sleep-interval 5` |
| `Requested format is not available` | Source has only single-stream or non-mp4 | The `/b` fallback should catch this; if not, drop to `-f best` |
| `ERROR: ffmpeg not found` | ffmpeg missing | Install ffmpeg; merge step needs it |

---

## Output Structure

```
{output_dir}/
  source.mp4              # The downloaded video (single merged file)
  source.metadata.json    # Title, duration, uploader, description, etc.
```

`source.mp4` is the canonical filename. Downstream skills (`clip-extractor`, `extracting-transcripts`) expect this name.

---

## Integration

- **Upstream:** none — this is the first phase of `long-form-to-clips`.
- **Downstream:** `extracting-transcripts` (transcribe the audio) and `clip-extractor` (face-tracked reframe). Both read `source.mp4` from the same output dir.
- **Workflow:** the `long-form-to-clips/WORKFLOW.md` step `id: ingest` invokes this skill with `params.video_url = "{{inputs.source}}"`.

---

## Non-Negotiable Rules

1. **NEVER** download to a location that isn't an explicit output directory. No Downloads, no temp, no home dir.
2. **ALWAYS** use `--merge-output-format mp4` so the downstream pipeline gets a single file.
3. **ALWAYS** verify the downloaded file with ffprobe before reporting success.
4. **NEVER** silently accept a `--cookies` file that isn't readable — fail loudly so the user knows the cookies didn't apply.
5. **NEVER** invoke yt-dlp without the format selector — defaults can change between yt-dlp versions and silently produce wrong files.

---

## Anti-Patterns

- **Apify scraper for YouTube** — costs $$$ per video, slower, requires account. Use yt-dlp.
- **Manual ffmpeg cut after download** — `clip-extractor` does this. Don't double-process.
- **Re-downloading on every run** — if `source.mp4` exists with the right duration, reuse it. Workflow runner enforces this; the skill itself doesn't need to.

---

## References

- yt-dlp docs: https://github.com/yt-dlp/yt-dlp
- Format selector reference: https://github.com/yt-dlp/yt-dlp#format-selection
- Cookies extension: https://chrome.google.com/webstore/detail/get-cookiestxt-locally/cclelndahbckbenkjhflpdbgdldlbecc

---

## Evolution Check (End of Every Invocation)

1. Did the download fail with a new symptom not in the table? → Add it.
2. Did a new yt-dlp flag prove necessary? → Document it in the canonical command.
3. Did the source URL pattern reveal a new host (Vimeo, Twitter, etc.) needing different format selector? → Note the host-specific tweak.

**Version:** 1.0
**Status:** Initial — yt-dlp canonical, cookies fallback, metadata sidecar
