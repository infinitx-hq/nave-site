# HyperFrames 0.6.56 — what changed & what to adopt (your project alignment)

Engine pinned to **0.6.56** (`tools/hyperframes/package.json`). This note exists so
every tenant adopts the same capabilities instead of rediscovering them per-clip. Verified live on
2026-05-28 (Windows, RTX 5060, 16-core, FFmpeg 8.0.1, Chrome headless-shell).

## Adopt now (fixes the recurring pain: slow renders, wrong reframe, off captions)

| Lever | Use it for | Command |
|---|---|---|
| `--gpu` | **Encode-bound** renders (60–90s clips, video b-roll, 4K, HDR). NVENC. *No gain on short text-only comps* — capture dominates there. Default is **off** — turn it on for keeper renders. | `render … --gpu` |
| `--workers auto` | **Capture-bound** renders (the common case). Parallel Chrome (~256 MB each). The #1 speed lever. | `render … --workers auto` |
| `--page-side-compositing` | ~6× faster SDR shader-transition renders (on by default; auto-off for HDR/alpha/video). | (default) |
| `-q draft` → `-q high` | Iterate on draft, ship on high. Don't burn `high`+`--gpu` on every preview. | `render … -q draft` |
| `--resolution portrait` | **The correct 9:16 reframe** — render the composition native vertical (1080×1920) instead of cropping a landscape master. Aspect must match the comp; integer DPR scale. | `render … --resolution portrait` |
| `transcribe` | Word-level caption timing (Whisper, local, no key). Use AAI Universal-3 Pro when brand-term spelling matters. | `npx hyperframes transcribe <video>` |
| `benchmark` / `doctor` / `docs <topic>` | Tune speed on the actual machine / verify deps / local `rendering`+`troubleshooting` reference. | `npx hyperframes doctor` |

## Also available (reach for when the moment calls)

- **Formats:** `--format mov`/`webm` (alpha — overlays, lower-thirds), `--format png-sequence` (AE/Nuke/Fusion ingest), `--resolution 4k`/`portrait-4k`/`square`.
- **`remove-background`** (u2net) — subject cutouts for PIP/overlay without green screen.
- **Modular skill suite upstream** (`npx skills add heygen-com/hyperframes`): `hyperframes-cli`, `hyperframes-media`, `hyperframes-registry`, `website-to-hyperframes`, plus animation backends `animejs` / `lottie` / `three` / `waapi` / `css-animations` / `tailwind`. The your project currently ships a monolithic `hyperframes` + custom `hyperframes-edit`/`editing-standard`. Full modular adoption + `skills add` sync is a deliberate follow-up (deferred — keeps us from drifting from upstream), not done in this pass.

## Clip-machine angle (why this matters there)

The reframe failures (face-track cropping graphics, split-renderer crash) come from running the old
Python face-track on **finished, graphics-dense sources**. The fix is **scene-type routing**:
talking-head → face-track; finished/graphic/screen-share → rebuild as a portrait HyperFrames
composition (`--resolution portrait`) or blur-letterbox. See `clip-machine` § Source scene-type →
layout (FIRST gate) + § Platform compatibility (Windows), and `clip-extractor` § Environment
constraints wall 3.
