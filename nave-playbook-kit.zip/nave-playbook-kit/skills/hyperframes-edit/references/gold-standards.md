> # ⚠️ SUPERSEDED — DO NOT FOLLOW (2026-06-01)
> The per-sub-type "gold standards" below encode the **OLD sparse model** — 5–8 pop-outs, 7-second /
> 6-second spacing, 60/40 visual-weight mix, hand-authored sub-type compositions. **That doctrine is
> OVERTURNED.** The canonical editor is the **pipeline-clip-pro auto-EDL** with a density floor 12 /
> target 20, illustrated scene-takeover archetypes, glossy stickers, and sparse whoosh-led SFX. The
> build-to reference is `../../../tools/hyperframes/registry/9x16-editing/showcase-pro/showcase-pro.mp4`,
> and the doctrine lives in `../../../tools/hyperframes/registry/9x16-editing/`. See `../SKILL.md`.
>
> The still-correct **native render contract** principles this file carried (first 3 frames sacred,
> source video as a NATIVE media track — never GSAP `currentTime`, all audio as native
> `<audio data-track-index>` tracks, dense-keyframe pre-encode, ffprobe verify) are **SALVAGED** into
> `../../../tools/hyperframes/templates/pipeline-clip-pro/RENDER-CONTRACT.md`. Read that, not this.
>
> A follow-up step DELETES this file after the salvage. Nothing below is authoritative.

---

# Gold Standards — Per Sub-Type Editorial Decisions  ·  ⚠️ SUPERSEDED

Quick-reference editorial decisions per sub-type. The full working composition for the pipeline-clip gold standard lives at `tools/hyperframes/examples/pipeline-clip-gold-standard/index.html`.

---

## Pipeline Clip Gold Standard

**Source:** Long-form tutorial extract, 60-90 seconds, talking-head with face fill.
**Density:** 5-8 pop-outs (A+B tier scored only).
**Structure:**

```
Frame 0-3 (0.0-0.1s)    — Triple hook burst (brand flash + zoom punch + impact SFX)
Frame 0-45 (0-1.5s)     — Title card overlay
Frame 45 (1.5s)         — Source video starts (native media track via data-start — NOT a GSAP currentTime tween)
Frame 45-60 (1.5-2.0s)  — Optional HookOverlay text springs in
Frame 60-180 (2-6s)     — Speaker delivers hook, captions running, NO pop-outs (let hook breathe)
Frame 180-240 (6-8s)    — A-tier moment 1 (concept-overlay or apple-popup)
Frame 240-450 (8-15s)   — Speaker carries point with captions only
Frame 450-510 (15-17s)  — A-tier moment 2 (concept-overlay if previous was popup, vice versa)
Frame 510-720 (17-24s)  — Captions only
Frame 720-810 (24-27s)  — B-tier moment 3 (floating-keyword)
... continue 5-8 pop-outs total, MIN 210 frames between centers
Last 75 frames (last 2.5s) — CTA card "Watch the full video" + handle
```

**Pop-out mix:**
- 1-2 concept-overlays (heavy, A-tier hero moments)
- 2-4 floating-keywords (light, B-tier supporting beats — color-coded brand)
- 1-2 social UI cards from registry (`instagram-follow`, `x-post`, `tiktok-follow`) when speaker references a platform/post

**SFX:**
- Hook impact at frame 2: `whoosh-large-sub-384631.mp3` @ 0.24
- Per pop-out entrance: varied whoosh @ 0.14-0.18 (j-cut 3 frames before visual)
- Per individual platform pop: `pop-402324.mp3` @ 0.20
- CTA entrance: whoosh @ 0.16
- Background music: `lofi-background.mp3` @ 0.02 continuous

**Audio handling (NATIVE — no ffmpeg mux):**
- Source dialogue = a native `<audio data-track-index="5" data-volume="1">` track (the `<video>` is muted)
- Background music + each SFX = their own `<audio data-start data-volume>` tracks; HyperFrames mixes all natively into the output mp4. No post-render ffmpeg mux. See snippets Pattern 7/9 + § Native render contract.

**Caption:** word-level at `bottom: 28%`, 72px Inter 800, brand-color emphasis on power words. Hide during concept-overlay frames.

**CTA:** "Watch the full video" + tutorial title (small subtitle), YouTube logo accent, handle from active profile config.

---

## Standalone Demo Gold Standard

**Source:** Recorded specifically as short-form, 30-60 seconds, demo style with screen-share or mixed.
**Density:** 4-6 pop-outs (1-2 Tier 1 apple-popup + 2-4 Tier 2 floating-card).
**Structure:**

```
Frame 0-3       — Hook burst (lighter — scale 1.04 instead of 1.06, no brand flash)
Frame 0-30      — Title card (1s, shorter than pipeline)
Frame 30        — Source video starts
Frame 60-180    — Speaker delivers WOW moment, FloatingCard intro at right
... 1-2 Tier 1 apple-popup at A-tier moments (full takeover)
... 3-5 Tier 2 floating-card at result/brand reveals (speaker visible)
Last 60 frames  — CTA "Follow for more" + handle
```

**Pop-out mix:**
- Tier 1 apple-popup × 2: WOW moment + core concept (max 2 — don't overuse the heavy treatment)
- Tier 2 floating-card × 3-5: brands, results, supporting details

**SFX:**
- Hook burst: `whoosh-large-sub-384631.mp3` @ 0.24
- Tier 1 popup: `pop-402324.mp3` @ 0.22
- Tier 2 floating-card: `whoosh-bamboo-389752.mp3` @ 0.16
- Background: `lofi-background.mp3` @ 0.02

**Caption:** phrase-chunk captions (3-5 word chunks), `accentColor: brand` on emphasis words.

**CTA:** "Follow for more" + handle.

---

## Announcement Gold Standard

**Source:** News/reaction format, 30-90s, often with embedded source frame PIP.
**Density:** 8-12 pop-outs (rapid-fire — for breaking-news energy).
**Structure:**

```
Frame 0-3        — Hook burst (full intensity)
Frame 0-45       — Title card with announcement
Frame 45         — Source video starts (or reaction-overlay format)
Throughout       — apple-popup × 3-5 for big concept reveals
Throughout       — floating-keyword × 5-7 for rapid-fire keyword punctuation
                   (lower spacing minimum for announcements: 180 frames / 6s instead of 210/7s)
Optional         — source-frame PIP top-right with brand-color border (when referencing the source post)
Last 60 frames   — CTA "Follow for AI updates" or per source type
```

**Pop-out mix:**
- apple-popup × 3-5: big concept moments
- floating-keyword × 5-7: brand names, product names, version numbers, key features

**SFX:**
- Hook burst: `whoosh-large-sub-384631.mp3` @ 0.24
- apple-popup entrance: `pop-402324.mp3` @ 0.22
- floating-keyword entrance: `pop-402324.mp3` @ 0.18 (varied with whoosh for variety)
- Background music: optional for announcements (sometimes the source audio is too dense)

**Caption:** word-by-word full-width captions, hide during apple-popup moments.

**Source-frame PIP** (when applicable) — a second native video track (dense-keyframe source):
```html
<div id="source-pip" class="source-frame-pip">
  <video id="source-original" muted playsinline src="./source-original-dense.mp4"
         data-start="{PIP_START}" data-duration="{PIP_DURATION}" data-track-index="3"></video>
</div>

<style>
.source-frame-pip {
  position: absolute;
  top: 80px; right: 40px;
  width: 380px; height: 213px;  /* 16:9 mini */
  border-radius: 16px;
  overflow: hidden;
  border: 4px solid var(--brand);
  z-index: 25;
}
.source-frame-pip video {
  width: 100%; height: 100%;
  object-fit: cover;
}
</style>

<!-- No script — the PIP plays natively via its data-start/data-duration. The timeline only animates the PIP container's reveal (opacity/scale), never the video clock. -->
```

---

## Cross-sub-type editorial principles

These apply regardless of sub-type:

- **First 3 frames are sacred** — hook burst lands here. Always.
- **Last frame is sacred** — composition must end with CTA visible.
- **Captions are GSAP-driven, not setInterval-driven** — every word is a span with explicit fade-in/fade-out tweens. (Overlays ARE timeline-driven; media clocks are NOT.)
- **Source video is a NATIVE media track** — `<video id muted data-start data-duration data-track-index>`, framework-owned playback. NEVER `video.play()` AND NEVER a GSAP `currentTime` tween (both → black/frozen video). Source must be dense-keyframe pre-encoded. See snippets Pattern 9 + § Native render contract.
- **All audio is NATIVE `<audio data-track-index data-volume>` tracks** — mixed into the output mp4 at render. No GSAP currentTime audio driving, no ffmpeg post-mux.
- **Compose from registry blocks before hand-authoring** — `tools/hyperframes/registry/blocks/` ships 45 patterns. Most pop-out moments have a registry equivalent.
- **Verification before declaring done** — ffprobe the rendered mp4: duration ≈ expected, resolution = 1080×1920, codec = h264, file size > 0.

---

## What "gold standard" means in practice

Not "perfect" — **reproducible to a quality bar.** A sub-agent following this spec + the snippets in `references/snippets.md` produces a clip that passes:

- ✅ Mute test: viewer understands the concept without audio
- ✅ Squint test: captions readable at small size on phone
- ✅ Hook test: first 3 seconds make the viewer pause scrolling
- ✅ Density test: pop-out count matches sub-type target, spacing ≥ 7s pipeline / 6s announcement
- ✅ Variety test: visual weight mix is 60-70% light/medium, 30-40% heavy
- ✅ Distinct test: every illustration is a unique metaphor (no template, no reuse)
- ✅ CTA test: last frame is the CTA card with handle visible

If any test fails, the composition is below the bar — refine before declaring done.
