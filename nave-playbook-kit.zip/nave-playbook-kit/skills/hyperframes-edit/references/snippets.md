> # ⚠️ SUPERSEDED — DO NOT FOLLOW (2026-06-01)
> This file teaches the **OLD hand-authored, sparse editorial model** — Impact-Score A/B/C tiers,
> 5–8 pop-outs, 7-second / 210-frame spacing, "less is more," one hand-built `index.html` per clip.
> **That doctrine is OVERTURNED.** The canonical editor is now the **pipeline-clip-pro auto-EDL**
> (density floor 12 / target 20, a move every ~1.5–3s, keyword-pops never echo the caption, model-
> written scene-takeovers, glossy stickers, sparse whoosh-led SFX). See `../SKILL.md`.
>
> The still-correct knowledge that lived here — the **native HyperFrames 0.6.56 render contract**
> (native `<video>`/`<audio data-track-index>` tracks, dense-keyframe source prep, no ffmpeg post-mux,
> no GSAP `currentTime` on media) — has been **SALVAGED** into
> `../../../tools/hyperframes/templates/pipeline-clip-pro/RENDER-CONTRACT.md`. Read that, not this.
>
> A follow-up step DELETES this file after the salvage. Nothing below is authoritative.

---

# Hyperframes-Edit Snippets — Copy-Paste-Adapt  ·  ⚠️ SUPERSEDED

Pattern library for short-form editing. Every pattern is HTML+CSS+GSAP, frame-driven (GSAP timeline), composable inside a single `index.html` per clip.

**Conventions:**
- Composition root: `<div id="root" data-composition-id="main" data-start="0" data-duration="..." data-width="1080" data-height="1920">`
- Master timeline: `window.__timelines["main"] = tl` (paused)
- All times below in seconds. Convert to/from frames: `frame = round(seconds * 30)` at 30fps.

---

## Impact Score Rubric (apply BEFORE picking patterns)

Score every candidate moment 0-100, then map to tier:

| Score | Tier | Action |
|---|---|---|
| 80-100 | **A** | Heavy treatment: concept-overlay (full-screen) or apple-popup |
| 60-79 | **B** | Medium-light: floating-keyword (with crystal-box if brand reveal) or floating-card |
| <60 | **C** | NO POP-OUT. Speaker carries the moment. |

**Score categories (0-20 each, sum to 100):**
- **Hook strength** — Does this moment grab attention?
- **Value delivery** — Does it teach/reveal something concrete?
- **Clarity** — Single clear message, no ambiguity
- **Shareability** — Would someone screenshot/share this?
- **Completeness** — Self-contained beat, doesn't need surrounding context

Below 60 → C → no pop-out. The speaker plus captions is the right treatment.

---

## Pattern 1 — Concept-Overlay (Full-Screen Heavy)

For A-tier hero moments. Solid white background, clip-circle entrance, illustration + headline, exit reveals video.

```html
<div id="overlay-{N}" class="concept-overlay" style="opacity: 0;">
  <div class="overlay-circle">
    <!-- Inline SVG illustration here, viewBox="0 0 600 600" -->
    <svg viewBox="0 0 600 600">
      <!-- Unique visual metaphor — never reuse, never templated -->
    </svg>
  </div>
  <div class="overlay-headline">
    {HEADLINE — 3-7 words, all caps, brand-color emphasis on key word}
  </div>
</div>

<style>
.concept-overlay {
  position: absolute; inset: 0; z-index: 100;
  background: #FFFFFF;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  clip-path: circle(0% at 50% 50%);  /* hidden by default */
}
.concept-overlay .overlay-circle {
  width: 600px; height: 600px;
  display: flex; align-items: center; justify-content: center;
}
.concept-overlay .overlay-headline {
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 900;
  font-size: 96px;
  line-height: 1.0;
  letter-spacing: -2px;
  text-align: center;
  color: #0A0A0A;
  max-width: 940px;
  padding: 0 60px;
  margin-top: 32px;
  text-transform: uppercase;
}
.concept-overlay .overlay-headline .accent { color: var(--brand); }
</style>

<script>
// In the master timeline. CONCEPT_START + CONCEPT_DURATION in seconds.
const CONCEPT_START = 12.5;
const CONCEPT_DURATION = 2.5;
const overlay = document.getElementById('overlay-{N}');

// Clip-circle reveal — circular wipe from center
tl.fromTo(overlay,
  { clipPath: 'circle(0% at 50% 50%)', opacity: 1 },
  { clipPath: 'circle(75% at 50% 50%)', duration: 0.4, ease: 'power3.out' },
  CONCEPT_START
);
// Hold full
tl.set(overlay, { clipPath: 'circle(75% at 50% 50%)' }, CONCEPT_START + 0.4);
// Exit — fade out
tl.to(overlay, { opacity: 0, duration: 0.25, ease: 'power2.in' }, CONCEPT_START + CONCEPT_DURATION - 0.25);

// Hide captions during concept-overlay
tl.to('#caption', { opacity: 0, duration: 0.15 }, CONCEPT_START - 0.05);
tl.to('#caption', { opacity: 1, duration: 0.15 }, CONCEPT_START + CONCEPT_DURATION + 0.05);
</script>
```

**Density rule:** A-tier only. Pipeline clip target = 1-2 concept-overlays (don't overuse — heavy weight).

---

## Pattern 2 — Apple-Style Popup (Tier 1 Standalone)

Premium white popup card, frosted-glass feel, spring entrance. For standalone-demo Tier 1 moments (max 2 per clip).

```html
<div id="popup-{N}" class="apple-popup">
  <div class="popup-card">
    <div class="popup-icon">
      <!-- Inline SVG, 120×120 viewBox -->
    </div>
    <div class="popup-headline">{HEADLINE — 4-8 words}</div>
    <div class="popup-subtext">{Optional 1-line elaboration}</div>
  </div>
</div>

<style>
.apple-popup {
  position: absolute; inset: 0; z-index: 100;
  display: flex; align-items: center; justify-content: center;
  opacity: 0;
}
.apple-popup .popup-card {
  background: rgba(255, 255, 255, 0.97);
  backdrop-filter: blur(40px);
  border-radius: 48px;
  padding: 56px 64px;
  max-width: 880px;
  text-align: center;
  box-shadow: 0 40px 120px rgba(0, 0, 0, 0.5);
  transform: scale(0.9);
}
.apple-popup .popup-icon { width: 120px; height: 120px; margin: 0 auto 24px; }
.apple-popup .popup-headline {
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 800;
  font-size: 78px;
  line-height: 0.95;
  letter-spacing: -1.5px;
  color: #0A0A0A;
}
.apple-popup .popup-subtext {
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 500;
  font-size: 32px;
  color: #4B5563;
  margin-top: 16px;
}
</style>

<script>
const POPUP_START = 8.0;
const POPUP_DURATION = 3.0;
const popup = document.getElementById('popup-{N}');
const popupCard = popup.querySelector('.popup-card');

// Spring entrance — back.out for the bounce
tl.to(popup, { opacity: 1, duration: 0.05 }, POPUP_START);
tl.to(popupCard, { scale: 1, duration: 0.5, ease: 'back.out(1.7)' }, POPUP_START);
// Hold
tl.to(popup, { opacity: 1, duration: 0.001 }, POPUP_START + POPUP_DURATION - 0.3);
// Exit — fade + scale-down
tl.to(popupCard, { scale: 0.92, duration: 0.25, ease: 'power2.in' }, POPUP_START + POPUP_DURATION - 0.3);
tl.to(popup, { opacity: 0, duration: 0.25, ease: 'power2.in' }, POPUP_START + POPUP_DURATION - 0.3);
</script>
```

---

## Pattern 3 — Floating Card (Tier 2 — speaker visible)

Smaller card overlay, top-right corner, speaker remains in frame. For brand reveals, results, supporting details.

```html
<div id="card-{N}" class="floating-card">
  <div class="card-icon"><!-- 64×64 SVG or img --></div>
  <div class="card-content">
    <div class="card-title">{TITLE — 2-5 words}</div>
    <div class="card-detail">{Optional 1-line context}</div>
  </div>
</div>

<style>
.floating-card {
  position: absolute;
  top: 220px; right: 60px;
  z-index: 20;
  width: 380px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(20px);
  border-radius: 24px;
  padding: 24px 28px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
  display: flex; align-items: flex-start; gap: 16px;
  transform: translateX(420px);  /* offscreen right */
  opacity: 0;
}
.floating-card .card-icon { width: 64px; height: 64px; flex-shrink: 0; }
.floating-card .card-title {
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 700; font-size: 28px; line-height: 1.1;
  color: #0A0A0A;
}
.floating-card .card-detail {
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 500; font-size: 18px; line-height: 1.3;
  color: #4B5563;
  margin-top: 4px;
}
</style>

<script>
const CARD_START = 18.0;
const CARD_DURATION = 4.0;
const card = document.getElementById('card-{N}');

// Slide in from right + fade in
tl.to(card, { x: 0, opacity: 1, duration: 0.4, ease: 'back.out(1.4)' }, CARD_START);
// Exit — slide out
tl.to(card, { x: 420, opacity: 0, duration: 0.3, ease: 'power2.in' }, CARD_START + CARD_DURATION - 0.3);
</script>
```

---

## Pattern 4 — Floating Keyword (B-tier, light weight)

Inline highlighted keyword over the video. For B-tier supporting moments. The cheapest, most-used pattern.

```html
<div id="kw-{N}" class="floating-keyword">{WORD or 2-3 WORDS}</div>

<style>
.floating-keyword {
  position: absolute;
  left: 50%; top: 38%;
  transform: translate(-50%, -50%) scale(0.9);
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 900;
  font-size: 92px;
  line-height: 1.0;
  letter-spacing: -2px;
  color: var(--brand);    /* brand color from CSS variable */
  text-transform: uppercase;
  text-shadow:
    0 4px 20px rgba(0, 0, 0, 0.85),
    0 0 40px rgba(0, 0, 0, 0.5);
  z-index: 22;
  opacity: 0;
  white-space: nowrap;
}
</style>

<script>
const KW_START = 22.5;
const KW_DURATION = 1.5;
const kw = document.getElementById('kw-{N}');

tl.to(kw, { opacity: 1, scale: 1, duration: 0.18, ease: 'back.out(1.6)' }, KW_START);
tl.to(kw, { opacity: 0, scale: 0.95, duration: 0.18, ease: 'power2.in' }, KW_START + KW_DURATION - 0.18);
</script>
```

For brand-reveal variant, wrap the keyword in a "crystal box":

```html
<div id="kw-brand-{N}" class="floating-keyword crystal-box">
  <img src="/public/logos/{platform}.svg" class="kw-icon" />
  <span>{BRAND NAME}</span>
</div>

<style>
.floating-keyword.crystal-box {
  background: rgba(255, 255, 255, 0.12);
  backdrop-filter: blur(24px);
  border: 1px solid rgba(255, 255, 255, 0.25);
  border-radius: 28px;
  padding: 24px 36px;
  display: flex; align-items: center; gap: 18px;
  font-size: 64px;
  color: #fafafa;
}
.crystal-box .kw-icon { width: 72px; height: 72px; }
</style>
```

---

## Pattern 5 — Triple Hook Burst (frame 0-3)

The mandatory pipeline-clip + announcement opener. Brand flash + zoom punch + impact SFX. Three things in 3 frames.

```html
<div id="hook-flash"></div>

<style>
#hook-flash {
  position: absolute; inset: 0; z-index: 90;
  background: var(--brand);
  pointer-events: none;
  opacity: 0;
}
</style>

<script>
// Frame 0-3 = 0 to 0.1 seconds at 30fps

// Brand color flash
tl.fromTo('#hook-flash',
  { opacity: 1 },
  { opacity: 0, duration: 0.1, ease: 'power3.in' },
  0
);

// Zoom punch on the whole composition
tl.fromTo('#root',
  { scale: 1.06 },
  { scale: 1, duration: 0.1, ease: 'power3.out' },
  0
);

// (No SFX code here — the hook impact is a NATIVE audio track, see below + Pattern 7)
</script>

<!-- Impact SFX = native audio track at frame 2 (j-cut). data-start = 0.067s (2/30). No GSAP, no mux. -->
<audio src="/public/audio/whoosh-large-sub-384631.mp3" data-start="0.067" data-track-index="6" data-volume="0.24"></audio>
```

---

## Pattern 6 — Word-Level Captions (per-word fade)

Captions at `bottom: 28%` (above any source-burned captions). Each word fades in at its `start` ms, fades out at `end` ms.

```html
<div id="caption" class="caption"></div>

<style>
.caption {
  position: absolute;
  left: 0; right: 0;
  bottom: 28%;
  text-align: center;
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 800;
  font-size: 72px;
  line-height: 1.1;
  letter-spacing: -1px;
  padding: 0 80px;
  color: #FFFFFF;
  text-transform: uppercase;
  text-shadow:
    0 4px 16px rgba(0, 0, 0, 0.85),
    0 0 24px rgba(0, 0, 0, 0.65);
  z-index: 30;
}
.caption .word {
  display: inline-block;
  margin: 0 10px;
  opacity: 0;
  transform: translateY(14px);
}
.caption .word.emphasis { color: var(--brand); }
</style>

<script>
// TRANSCRIPT_WORDS = injected by workflow runner.
// Each entry: { word: string, start: ms, end: ms, emphasis?: boolean }
const captionRoot = document.getElementById('caption');

TRANSCRIPT_WORDS.forEach((w, i) => {
  const span = document.createElement('span');
  span.className = 'word' + (w.emphasis ? ' emphasis' : '');
  span.textContent = w.word.trim();
  captionRoot.appendChild(span);
});

const VIDEO_OFFSET = 1.5;  // title card duration before video starts
TRANSCRIPT_WORDS.forEach((w, i) => {
  const span = captionRoot.querySelectorAll('.word')[i];
  const startS = VIDEO_OFFSET + (w.start / 1000);
  const endS = VIDEO_OFFSET + (w.end / 1000);
  tl.to(span, { opacity: 1, y: 0, duration: 0.12, ease: 'power2.out' }, startS);
  tl.to(span, { opacity: 0, duration: 0.12, ease: 'power2.in' }, endS - 0.05);
});
</script>
```

For phrase-chunk captions (standalone-demo style), pre-chunk the words array into 3-5 word groups before generating spans. Each phrase animates as a unit.

---

## Pattern 7 — SFX Integration (NATIVE audio tracks)

**SFX library (global, canonical):** `your project/assets/audio/sfx/` — whoosh-effect-382717, pop-402324,
whoosh-large-sub-384631 (hook impact), whoosh-bamboo-389752, lofi-background / background-music (beds),
mouse-click-290204, clock-ticking, error-sting. See its `MANIFEST.md` for type + use. Copy the SFX you
use into the composition's `public/audio/` (HyperFrames serves `/public/...` from the project dir).
Source of truth = M3 `content-production-engine/public/audio/`; binaries are gitignored (text-only repo).

Every SFX is a **native `<audio>` track** — HyperFrames captures and mixes them into the output mp4 at render. **No GSAP `currentTime` driving, no ffmpeg `amix` post-mux** (both are the deprecated pattern). Place each SFX with `data-start` (the j-cut time = visual − 0.1s), set level with `data-volume`, give each a distinct `data-track-index`.

```html
<!-- SFX: one native audio track each. data-start = j-cut (3 frames before the visual). -->
<audio src="/public/audio/pop-402324.mp3"            data-start="12.4" data-track-index="6" data-volume="0.20"></audio>
<audio src="/public/audio/whoosh-effect-382717.mp3"  data-start="22.4" data-track-index="7" data-volume="0.16"></audio>

<!-- Background music: low volume, full clip length -->
<audio src="/public/audio/lofi-background.mp3"       data-start="0" data-duration="{TOTAL}" data-track-index="8" data-volume="0.02"></audio>

<!-- Source dialogue: the a-roll audio track (see Pattern 9) -->
<audio id="a-roll-audio" src="./source-dense.mp4"    data-start="0" data-duration="{VIDEO_DURATION}" data-track-index="5" data-volume="1"></audio>
```

That's the whole SFX system — declarative tracks, mixed natively. No `<script>` SFX code, no sidecar JSON, no `ffmpeg amix`. HyperFrames captures every `<audio data-volume>` (+ any un-muted `<video>`) and mixes them into the rendered mp4. To trim into a long SFX file, add `data-media-start` (offset into the source). The output already has the full audio — nothing to mux afterward.

---

## Pattern 8 — Title Card + CTA Card (bracket the video)

Standard short-form bracket — 1.5s title in, video plays, 2.5s CTA out.

```html
<div id="title-card" class="title-card">
  <div>
    <div class="title">{CLIP_TITLE}</div>
    <div class="accent-bar"></div>
  </div>
</div>

<div id="cta-card" class="cta-card">
  <div class="cta-text">{CTA_TEXT}</div>
  <div class="cta-handle">{CTA_HANDLE}</div>
</div>

<style>
.title-card, .cta-card {
  position: absolute; inset: 0; z-index: 60;
  display: flex; align-items: center; justify-content: center;
  opacity: 0;
}
.title-card { background: linear-gradient(180deg, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.4) 100%); }
.cta-card {
  flex-direction: column;
  background: rgba(0, 0, 0, 0.94);
}
.title-card .title {
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 900; font-size: 110px; line-height: 0.95;
  letter-spacing: -3px; text-align: center;
  color: #FAFAFA;
  max-width: 940px; padding: 0 60px;
}
.title-card .accent-bar {
  width: 180px; height: 6px;
  background: var(--brand);
  border-radius: 999px;
  margin: 28px auto 0;
  transform: scaleX(0); transform-origin: left;
}
.cta-card .cta-text {
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 900; font-size: 96px; line-height: 1;
  letter-spacing: -2px; text-align: center;
  color: #FAFAFA;
  max-width: 940px; padding: 0 60px;
}
.cta-card .cta-handle {
  margin-top: 32px;
  font-family: 'Inter', system-ui, sans-serif;
  font-weight: 500; font-size: 44px;
  color: var(--brand);
}
</style>

<script>
const TITLE_DURATION = 1.5;
const VIDEO_DURATION = 78.5;  // ffprobe the actual reframed clip
const CTA_DURATION = 2.5;
const VIDEO_OFFSET = TITLE_DURATION;
const CTA_START = VIDEO_OFFSET + VIDEO_DURATION;

// Title card in
tl.to('#title-card', { opacity: 1, duration: 0.25, ease: 'power2.out' }, 0);
tl.to('#title-card .accent-bar', { scaleX: 1, duration: 0.6, ease: 'power3.out' }, 0.15);
tl.to('#title-card', { opacity: 0, duration: 0.2, ease: 'power2.in' }, TITLE_DURATION - 0.2);

// CTA card in (no exit — composition ends with CTA visible)
tl.to('#cta-card', { opacity: 1, duration: 0.25, ease: 'power2.out' }, CTA_START);
</script>
```

---

## Pattern 9 — Source Video (NATIVE media track — framework-owned)

The CRITICAL pattern. The video is a **native media track**; HyperFrames owns playback via
`data-*`. **NEVER** drive `video.currentTime` from GSAP and **NEVER** `video.play()` — both
produce a black/frozen video (verified 2026-05-29). Two hard requirements: the `<video>` needs
an **`id`** + **`data-start`** to be discovered, and the **source MUST have dense keyframes**
(pre-encode `-g 30 -keyint_min 30`) or the per-frame seek fails → black.

```html
<!-- Body sibling (NOT nested in a timed/composition element). muted = silent visual; sound rides the <audio> track. -->
<video id="a-roll" src="./source-dense.mp4" muted playsinline
       data-start="0" data-duration="78.5" data-track-index="0"></video>
<audio id="a-roll-audio" src="./source-dense.mp4"
       data-start="0" data-duration="78.5" data-track-index="5" data-volume="1"></audio>

<style>
  /* layout via CSS only — no GSAP touches the video clock */
  #a-roll { position: absolute; inset: 0; width: 1080px; height: 1920px; object-fit: cover; }
</style>
```

Source prep (mandatory — sparse-keyframe YouTube downloads render black):
```bash
ffmpeg -i src.mp4 -c:v libx264 -r 30 -g 30 -keyint_min 30 -sc_threshold 0 \
  -pix_fmt yuv420p -crf 18 -preset veryfast -movflags +faststart -c:a aac source-dense.mp4
```

**Letterbox-self-blur** (preserve a finished 16:9 master with its graphics/captions) = two native
video tracks, same `src`, CSS only — no ffmpeg:
```html
<video id="bg" src="./source-dense.mp4" muted data-start="0" data-duration="78.5" data-track-index="0"
       style="position:absolute;inset:0;width:1080px;height:1920px;object-fit:cover;filter:blur(30px) brightness(0.42);transform:scale(1.12)"></video>
<video id="fg" src="./source-dense.mp4" muted data-start="0" data-duration="78.5" data-track-index="1"
       style="position:absolute;inset:0;width:1080px;height:1920px;object-fit:contain"></video>
```

The GSAP timeline animates only the OVERLAYS (captions, cards, pop-outs, CTA) — never the video/audio clocks.

---

## Pattern 10 — Composing from registry blocks

For social UI moments, transitions, cinematic effects, polish overlays — DON'T hand-author. Drop in a registry block.

```html
<!-- Need to reference a tweet? Use the x-post block. -->
<div id="x-post-1">
  <!-- Copy the relevant HTML/CSS from tools/hyperframes/registry/blocks/x-post/ -->
  <!-- Substitute the post content -->
</div>

<script>
// Animate the registry block's reveal in your master timeline
const xPost = document.getElementById('x-post-1');
tl.fromTo(xPost,
  { opacity: 0, y: 40, scale: 0.95 },
  { opacity: 1, y: 0, scale: 1, duration: 0.5, ease: 'back.out(1.4)' },
  POST_START
);
tl.to(xPost, { opacity: 0, y: -40, duration: 0.3 }, POST_START + POST_DURATION - 0.3);
</script>
```

Same pattern for `instagram-follow`, `tiktok-follow`, `reddit-post`, `spotify-card`, `glitch`, `light-leak`, `cinematic-zoom`, `apple-money-count`, etc. The registry block provides the visual; your master timeline composes when it shows up + when it leaves.

---

## Render command (reminder)

```bash
# source MUST be dense-keyframe pre-encoded first (Pattern 9) or video renders black
npx hyperframes render tools/hyperframes/compositions/{ClipName}/ \
  -o output/runs/{slug}/clips/edited/{clip-id}.mp4 \
  --no-browser-gpu --gpu --quality high --fps 30 --format mp4
# --no-browser-gpu = software capture (avoids the Windows multi-worker D3D11 crash); --gpu = NVENC encode.
# Leave --workers UNSET (explicit -w disables the auto-retry ladder).
```

No post-render audio mux — audio is captured natively from the `<audio data-track-index data-volume>`
track(s) (Pattern 7/9). The output mp4 already has video + audio. See hyperframes-edit § Native render contract.
