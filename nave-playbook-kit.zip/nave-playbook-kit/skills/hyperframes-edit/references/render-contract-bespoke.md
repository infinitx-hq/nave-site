---
title: Bespoke-composition render contract (Windows, validated 2026-06-09)
description: Hard rules for hand-built HyperFrames compositions (outside pipeline-clip-pro) — video hosting, audio, render flags, QA gates. Each rule was paid for with a failed render on the fable5-launch-short / two-models productions.
section: references
priority: high
updated: 2026-06-11
---

# Bespoke composition render contract

Validated on hyperframes 0.6.88, Windows 11 + NVIDIA. Every rule below was discovered by a
real failure; do not relearn them.

## Composition structure (silently broken otherwise)
1. **Videos live at body level, ≤2 levels deep** (`body > untimed-wrapper > video` or
   `body > video`). A video inside the `data-composition-id` div inside a wrapper (3 deep)
   renders as NOTHING in production — while `snapshot` shows it fine.
2. **Composition div FIRST in body** (linter requires root-first) with explicit
   `z-index` ABOVE the video layer; overlays paint on top of body-level videos.
   Consequence: a body-level video can never appear "inside" an opaque comp card — leave a
   transparent window in the card, or compose the card as stacked elements around the video.
3. **One video clip per `data-track-index`** when a track would otherwise sit idle >10s
   before its next clip — long-idle track reuse drops the later clip. Tracks are free; use one
   per video.
4. **Strip audio from every video asset** (`ffmpeg -c:v copy -an` remux). Neither the HTML
   `muted` attribute nor `data-volume="0"` prevents the capture engine from mixing video audio
   — source speech WILL bleed under your VO. Picture-only files are the only reliable mute.
5. **ONE pre-mixed audio track** (`combined.m4a`: VO loudnorm -14 + music duck envelope +
   adelay'd SFX + sound-ups) as a single native `<audio data-volume="1">` clip.
6. Segments pre-encoded H.264 `-g 30 -keyint_min 30` (sparse-keyframe sources scrub black).

## Render invocation (NATIVE process, validated 2026-06-11 on Video #2, 1249.8s/37.5k frames)
- **Default — multi-worker FORCED-SCREENSHOT capture (~4× faster, video-correct):**
  `PRODUCER_FORCE_SCREENSHOT=true npx hyperframes render . -w 4 --gpu --browser-gpu --fps 30`
  - `PRODUCER_FORCE_SCREENSHOT=true` is the load-bearing env: without it, multi-worker runs
    auto-pick **"beginframe" capture, which renders WRONG-TIME video frames** on body-level-video
    comps (overlays/captions stay perfectly synced — only the video layer is wrong, and it looks
    fine in the first ~50s; diff render-vs-source at LATE timestamps to catch it). Screenshot
    capture is deterministic per frame and worker-safe (validated by frame-diff at 10–125s).
  - Throughput: ~1.2× realtime marginal at 4 workers vs ~4.7× single-worker.
- **Fallback (constrained machines / weird captures):** single worker —
  `npx hyperframes render . --no-browser-gpu --fps 30 --low-memory-mode` (+ `--gpu` when fresh).
- **NVENC pin (Windows + NVIDIA):** long (>240s) renders take the disk-capture path whose
  GPU-encoder probe has a 2s timeout; under load it silently falls back to libx264, which
  crashes on the reference box (cost: a full 2.5h capture, frames deleted on failure). No
  flag/env forces the encoder — pin it in the npm-global install:
  in `…npm\node_modules\hyperframes\dist\cli.js` replace
  `cachedGpuEncoder = await detectGpuEncoder();` with `cachedGpuEncoder = "nvenc";`
  (re-apply after every hyperframes upgrade).
- **Serialize renders.** Never run two renders, or a render + heavy ffmpeg jobs, concurrently
  — encoder contention stalls the encode at ~1fps until the renderer dies ("Try --docker" tail).
- Pre-flight: kill stray `ffmpeg` and orphaned headless chrome/node from prior runs (leaked
  GPU-encoder sessions are the stall cause after several back-to-back renders). Launch from an
  interactive session — Chrome fails with 0xC0000142 from detached/hidden Start-Process contexts.
- Verify output before any downstream step: file exists, ffprobe duration ≈ composition total,
  1 video + 1 audio stream, **and frame-diff render-vs-source at ≥3 late timestamps** (the
  wrong-time-video failure passes every other check).

## QA gates (all mandatory before showing the creator)
1. **Frame QA**: extract 30+ frames across the timeline into labeled contact sheets; read them.
   (Catches: missing videos, overlapping cards, caption collisions, layout drift.)
2. **ASR audio gate**: extract a VO-only window from the OUTPUT and transcribe it — the text
   must match the script with ONE voice. Two interleaved voices = video-audio bleed. Also
   verify each intentional sound-up window transcribes as the source line.
3. **Master**: `-c:v copy -af loudnorm=I=-14:TP=-1.5:LRA=11 -ar 44100 -movflags +faststart`
   (render output can land at +1dBTP — always re-master; story-safe spec).
4. Caption hygiene: word-timing comes from AAI on the assembled VO; drop caption groups that
   would duplicate full-screen takeover text (AAI may time the first word ~0.3s early — cut
   off at the end of the previous speech, not the next line's nominal start).

## Debug decision tree
- Element missing in render but present in `snapshot` → capture-path bug: check nesting depth,
  track idle-gap, worker mode. NOT your composition.
- `snapshot` itself fails `Page.captureScreenshot Internal error` → videos nested too deep.
- Encode crawling at ~1fps with q=24 lines → encoder contention/leaked sessions: kill strays,
  retry CPU encode, serialize.
