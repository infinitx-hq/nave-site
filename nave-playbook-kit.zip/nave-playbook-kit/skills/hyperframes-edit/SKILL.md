---
name: hyperframes-edit
description: "Edit short-form videos (under 90 seconds) into premium 9:16 Hyperframes clips via the pipeline-clip-pro auto-EDL editor: dense motivated moves (density floor 12 / target 20), always-on karaoke captions, glossy keyword-pop stickers, illustrated scene-takeovers, sparse whoosh-led SFX. The engine's canonical compose path. Triggers on 'edit clip', 'edit short', 'short-form editing', 'edit pipeline clip', 'reels editing', 'shorts editing', 'tiktok editing', 'auto-edl', 'clip machine'."
argument-hint: [reframed_clip_path]
allowed-tools:
  - Bash(npx:*)
  - Bash(node:*)
  - Bash(python3:*)
  - Bash(ffprobe:*)
  - Bash(ffmpeg:*)
  - Bash(./render_clip.sh:*)
  - Read
  - Write
  - Edit
metadata:
  category: video-production
  version: 3.0
---

# Short-Form Editing — pipeline-clip-pro (Engine Canonical)

Edit a reframed 9:16 clip into a premium short via the **pipeline-clip-pro auto-EDL editor**. The
editor walks the transcript and auto-populates a DENSE, motivated edit — keyword-pop stickers, logo
callouts, stat cards, punch-in zooms, whip transitions, draw-on annotations, and illustrated
scene-takeovers — then enforces a density floor and renders through the native HyperFrames 0.6.56
contract. **You do not hand-author a composition.** You stage the inputs, run `render_clip.sh`, and
QA the result against the showcase bar.

> ## ⚡ Start here
>
> 1. **`tools/hyperframes/templates/pipeline-clip-pro/RENDER-CONTRACT.md`** — the load-bearing physics
>    (native tracks, dense-keyframe prep, no ffmpeg post-mux, no GSAP `currentTime` on media). Read it
>    FIRST. A clip that violates the contract renders black/frozen/silent no matter how good the editorial.
> 2. **`tools/hyperframes/templates/pipeline-clip-pro/README.md`** — the template's file structure,
>    `clip.json` schema, caption safe-box rules, tool-name glossary, and the v1–v10 load-bearing bug fixes.
> 3. **`tools/hyperframes/registry/9x16-editing/`** — the editing DOCTRINE (the 5 docs below). This is
>    the quality bar the auto-EDL is calibrated to.
>
> Author a composition by hand only for a treatment the pro template genuinely can't express. The
> default answer is: stage inputs → `render_clip.sh` → QA → tune the EDL.

---

## ⚠️ Doctrine change — the old philosophy is OVERTURNED

This skill used to teach an **Impact-Score A/B/C** sparse model: 5–8 pop-outs per clip, a 7-second /
210-frame minimum between pop-out centers, "less is more," let the speaker breathe. **That is dead.**
A premium short has something happening almost every beat; the old sparse clips read as flat. The new
doctrine inverts every one of those numbers. If you remember the old rules, unlearn them:

| OLD (dead) | NEW (pipeline-clip-pro) |
|---|---|
| Impact-Score A/B/C gate; C-tier = no move | **Density floor 12, target 20+.** `gen_edl.py` back-fills toward target and ABORTS below 12. |
| 5–8 pop-outs / clip | **A motivated move every ~1.5–3s; 3–6 moves per 10s; no gap > 5s.** |
| Min 210 frames (7s) between pop-out centers | **~1.5–3s between moves.** The 7-second gap is the OLD bar. |
| "Less is more" — let the speaker breathe | **Motivation, not metronome** — every move serves the message; restraint = energy oscillation (calm→burst→calm), NOT fewer moves. |
| Pop-out can mirror the caption word | **Keyword-pops must NEVER echo the live caption word.** |
| Heavy/medium/light "visual weight mix" 60/40 | **Glossy beveled sticker tiles** + 5 illustrated scene-takeover archetypes; weight comes from variety of move TYPE, not a fixed ratio. |
| Dense pops + per-pop SFX | **Sparse, whoosh-led SFX** — scene/whip = whoosh, ONE cash on the biggest stat, else silent (~5–8 SFX on a 60s clip). |
| Hand-author one `index.html` per clip | **Auto-EDL.** `render_clip.sh` generates `edl.json`; you tune it, you don't author HTML. |

Keep nothing from the old model except the **caption discipline** (always-on, word-synced, thick black
stroke, one accent) and the **native render contract** — both of which carry forward, sharpened.

---

## The doctrine (read these — the auto-EDL is calibrated to them)

`tools/hyperframes/registry/9x16-editing/` — five docs, owned by specialist agents:

| Doc | What it gives you |
|---|---|
| **`CLIP-EDITING-SYSTEM.md`** | The master index: the long-form→short flow, the four pillars (density / scene takeovers / logos / sound), and the hard-won lessons. Start here. |
| **`RESEARCH-editing-bar.md`** | The full numbered bar — pacing spine (cut every 1.5–3s, 3–6/10s), the 17-move library with exact frames/easings, the per-line decision heuristic, the 5 things that separate 95–100% from 70%. Source of truth. |
| **`PLACEMENT-PLAYBOOK.md`** | WHERE each effect goes on 9:16 — the frame zones (A top / B face-KEEP-CLEAR / C seam / D lower-third / E bottom-UI), variants, and the per-effect SFX. Never cover the face. |
| **`EDITING-COMPONENTS.md`** | The practical index of the bar — move list + decision heuristic + build contract in one page. |
| **`REFERENCE-ANALYSIS.md`** | The routed-spine / illustrated-explainer caliber (the "US-map" bar) — the craft ceiling the showcase reaches for. |

Canonical build-to reference: **`registry/9x16-editing/showcase-pro/showcase-pro.mp4`** — open it to
calibrate the craft bar before QAing any clip.

---

## The four pillars (each an EDL move family)

**1. Edit density** (`EDIT-DENSITY.md` · agent `move-designer`) — hard floor **12 visible edits**,
target **20+**, a move every ~1.5–3s, no gap > 5s. `gen_edl.py` auto-builds the bed from `words.js` +
the logo manifest and ABORTS below the floor. Moves: keyword-pops (glossy beveled tiles — the density
workhorse), logo callouts (tool's first mention), stat cards (spoken numbers), draw-on annotations,
whip transitions (topic pivots), punch-in zooms (≥4 guaranteed, spread, alternating in/out). Captions
are always-on and counted SEPARATELY — not part of the floor.

**2. Scene takeovers** (`scenes.tmpl` · agent `scene-director`) — **2–3 per clip** at hero moments,
spaced **>8s apart** (the generator spreads chosen sentences >12s). Talking head → flash → full-frame
ILLUSTRATED motion scene (warm paper, editorial serif headline, draw-on SVG) explains the point →
flash back. 5 archetypes: **vs / flow / result / problem / spark**. **Headlines MUST be model-written**
— `gen_edl.py`'s scene-takeover copy is a keyword-mash PLACEHOLDER (produces "FEEL CLAUDE GETTING");
always patch the chosen scene's `head`/`sub` with model copy at the hero beat (e.g. "70% Gone / Six
generations torched the plan"). Drop a redundant stat-card if the scene already carries the number.

**3. Logos & reference images** (`LOGO-FETCH.md` · agent `asset-fetcher`) — `fetch_logos.py` 12-rung
ladder (no-key first), gates on bytes+content-type+dims NOT HTTP status (soft-404 SPAs return HTML
200), scores 0–100, returns a manifest with `ok | needs_human | failed`. Clean brand-correct marks →
glossy lower-third logo tiles. Eyeball every `needs_human`.

**4. Sound** (sparse + whoosh-led · agent `sound-designer`) — scene flashes + whips = `whoosh`; the
single biggest stat = ONE `cash`; everything else SILENT. **~5–8 SFX on a 60s clip, not 20+.** A wall
of pops/impacts reads cheap. SFX are **native `<audio>` track-6** (emitted by `build.mjs`), J-cut −0.1s.

---

## The compose path — `render_clip.sh` (the one command)

The auto-EDL chain. `render_clip.sh` lives in the template dir and does the whole job: de-stutter →
auto-EDL (density gate) → stage logos → token-substitute + emit native SFX → render all comps.

```bash
# Brand is SCOPE-TAILORED — resolved by the workflow from the active scope's
# content-production/brand-profile.md '## Brand Colors'. Passed as env (NO hardcoded creator).
BRAND_COLOR='#F97316' CTA_HANDLE='@handle' PROFILE_NAME='Name' \
MIN_MOVES=12 TARGET_MOVES=20 \
  tools/hyperframes/templates/pipeline-clip-pro/render_clip.sh \
    <workdir> <reframed.mp4> <words.js> <clip.json> <ytid|-> <out.mp4>
```

- **`BRAND_COLOR` is REQUIRED** — `render_clip.sh` + `build.mjs` fail loud if unset (they NEVER fall
  back to a hardcoded creator). Resolve the hex from the active scope's
  `content-production/brand-profile.md` `## Brand Colors`. Pass neutral `#E0E0E0` if the profile is
  `[TBD]`. `CTA_HANDLE` / `PROFILE_NAME` default to `@creator` / `Creator`.
- **`<ytid>` `"-"`** = non-YouTube source → skip the frame-0 cover banner.
- **Override the auto-EDL by hand:** drop a tuned `edl.json` next to `clip.json` and `render_clip.sh`
  uses it instead of generating one (hand-tuned moves win). This is where you patch model scene copy.

### What the chain does (so you can tune it)

1. **`destutter_words.py`** rewrites `words.js` in place — collapses adjacent duplicate words ("what's
   what's" → "what's"). MUST rewrite `words.js` itself; the captions comp re-reads it directly.
2. **`gen_edl.py`** walks `words.js` + the logo manifest → `edl.json`: logo-callouts, stat-cards, whips
   + progress-steps on pivots, keyword-pops on emphasis words, ≥4 spread punch-ins, a couple draw-on
   annotations, 2–3 scene-takeovers. Each move carries an `sfx`. Back-fills the largest gaps with
   emphasis pops until target; **fails if the transcript is too sparse to reach 12**.
   - **keyword_echo guard:** each pop fires ~0.1s AFTER its word (caption has rolled to the next
     phrase) and SKIPS any pop whose word is in the caption phrase visible at that instant
     (`caption_echoes()`); back-fill pushes the pop to the phrase-end gap rather than echo. Pops
     reinforce a word JUST heard, never the live caption word.
3. **`build.mjs`** substitutes `{{BRAND_COLOR}}`/`{{CTA_HANDLE}}`/`{{PROFILE_NAME}}` + the transcript +
   the EDL into all `.tmpl` files → `.html`. Splits the EDL: `punch-in` → a-roll zoom in `index.html`,
   `scene-takeover` → the scenes comp, the rest → the moves comp. Emits the native SFX `<audio>` track-6.
4. **`npx hyperframes render`** — `--workers auto --quality standard --fps 30 --format mp4`. The
   renderer mixes native tracks (dialogue track-5 + SFX track-6) into the output. **No ffmpeg post-mux.**

---

## Per-clip prep (before `render_clip.sh`)

1. **Transcribe the reframed clip** via AssemblyAI Universal-3 Pro (`extracting-transcripts` skill) →
   word-level ms timing. NEVER slice a master transcript (clip extraction adds 0.5–4s pre-roll drift).
   `convert-assemblyai.mjs` / `aai_to_words.py` → `words.js`.
2. **Apply the tool-name glossary** to `words.js` AND the intro/stat/cta copy BEFORE build, or captions
   burn the wrong spelling. Canonical fixes (see README): Cernio→**Zernio**, Hixfield/Highsfield→
   **Higgsfield**, Cloud Code→**Claude Code**, CDance→**Seedance**, 11Labs→**ElevenLabs**,
   Hyperframes→**HyperFrames**, etc.
3. **Hook decision — COMPARE, don't blindly restructure.** Score the clip (5-cat) and compare its
   NATIVE opening sentence against the best PULLED alternative. **Only restructure if a pulled hook
   beats the native open by 2+ points.** If it already opens strong, keep the natural hook. If you do
   restructure, the hook's end must land on a sentence boundary (plays to completion, never cut
   mid-thought); ffmpeg-extract + concat on the SOURCE, then **RE-TRANSCRIBE** (timestamps shifted) and
   reframe.
4. **Write `clip.json`** (all fields optional, see README schema): `videoDuration` (EXACT reframed
   duration — CTA = +3s), `introHeadline`/`ctaHead`/`ctaSub`, single `statNumber`/`statLabel`, and
   **`capSegments`** (per-segment caption CENTER-Y — `measure_caption_gap.py <reframed.mp4>` per layout
   segment; ~1500 for talking-head, the measured seam centroid for splits — guessing lands captions on
   the face).
5. **Fetch logos** (`fetch_logos.py`) into a `logos/` dir beside `clip.json` so callouts resolve.
6. **Run on a CLEAN reframe.** A pre-edited clip already has moves/logos baked in and double-stacks.

---

## QA before declaring done

Against the showcase bar + the render contract:

1. **Density:** ≥12 visible edits, 3–6/10s, max gap ≤5s (the EDL build reports these). Below floor =
   the build already aborted.
2. **Scene takeovers:** 2–3, model-written copy (not keyword-mash), >8s apart, archetype fits the beat.
3. **Keyword-pops:** none echo the live caption word; glossy beveled tiles (not flat boxes).
4. **Captions:** layout-aware (never on the face), one dark pill at a time, thick black stroke, brand
   accent on power words, de-stuttered.
5. **SFX:** sparse + whoosh-led (~5–8 on 60s); whips/scenes = whoosh, one cash on the biggest stat.
6. **Render contract** (see `RENDER-CONTRACT.md`): `ffprobe` the output — 1080×1920, h264, BOTH video
   + audio streams, duration ≈ expected, size > 0; then sample-frame check (decode mid-clip, confirm
   not black). Audio is native — no ffmpeg post-mux ran.

If any check fails, tune the `edl.json` (or `clip.json`) and re-render. **Own the outcome** — would
you be 100% confident showing this to the creator? If not, iterate.

---

## The agents — `content-production-engine/.claude/agents/`

- **`clip-editor`** — ORCHESTRATOR: coordinates the four pillars, assembles the EDL, renders, QAs vs
  the showcase. Invoke for a full clip.
- `scene-director` · `asset-fetcher` · `move-designer` · `sound-designer` — the specialists. Invoke one
  directly to improve just that layer.

---

## Hard-won lessons (don't repeat)

- Run on a CLEAN reframe (pre-edited clips double-stack moves).
- Scene copy MUST be model-written; the heuristic produces "FEEL CLAUDE GETTING". Scene-takeovers <8s
  apart collide. Drop a redundant stat-card if the scene already carries the number.
- SFX: sparse + whoosh-led. A wall of pops/impacts reads cheap.
- Stickers must be glossy (beveled tile), never flat colored boxes.
- Logo fetch: never trust HTTP status (soft-404 SPAs return HTML 200) — gate on content-type+bytes+dims.
- Captions never echo the on-screen card or the live keyword-pop word; one dark pill at a time; never
  cover the face; measure the gap, don't guess.
- De-stutter `words.js` itself before captioning (the comp re-reads it directly).
- **Native render contract is non-negotiable** — see `RENDER-CONTRACT.md`. Sparse-keyframe source →
  black video; GSAP `currentTime` on media → frozen video; never add an ffmpeg post-mux (SFX are
  native track-6).

---

## References

| File | Purpose |
|---|---|
| [`tools/hyperframes/templates/pipeline-clip-pro/RENDER-CONTRACT.md`](../../tools/hyperframes/templates/pipeline-clip-pro/RENDER-CONTRACT.md) | **The physics.** Native video/audio tracks, dense-keyframe prep, no ffmpeg post-mux, no GSAP `currentTime` on media, frame-0 cover banner, `window.__timelines`, ffprobe+sample-frame verify, render flags, vendored GSAP/fonts. Read FIRST. |
| [`tools/hyperframes/templates/pipeline-clip-pro/README.md`](../../tools/hyperframes/templates/pipeline-clip-pro/README.md) | Template structure, `clip.json` schema, caption safe-box, tool-name glossary, v1–v10 load-bearing bug fixes. |
| [`tools/hyperframes/templates/pipeline-clip-pro/EDIT-DENSITY.md`](../../tools/hyperframes/templates/pipeline-clip-pro/EDIT-DENSITY.md) | The density requirement (floor 12 / target 20) + how `gen_edl.py` builds the move bed. |
| [`tools/hyperframes/templates/pipeline-clip-pro/LOGO-FETCH.md`](../../tools/hyperframes/templates/pipeline-clip-pro/LOGO-FETCH.md) | The logo-fetch ladder + manifest scoring. |
| [`tools/hyperframes/registry/9x16-editing/CLIP-EDITING-SYSTEM.md`](../../tools/hyperframes/registry/9x16-editing/CLIP-EDITING-SYSTEM.md) | **Doctrine master index** — the flow, the four pillars, the hard-won lessons. |
| [`tools/hyperframes/registry/9x16-editing/RESEARCH-editing-bar.md`](../../tools/hyperframes/registry/9x16-editing/RESEARCH-editing-bar.md) | The full numbered editing bar (pacing spine, 17 moves, decision heuristic, the 5 differentiators). Source of truth. |
| [`tools/hyperframes/registry/9x16-editing/PLACEMENT-PLAYBOOK.md`](../../tools/hyperframes/registry/9x16-editing/PLACEMENT-PLAYBOOK.md) | WHERE each effect goes on 9:16 (zones, variants, SFX). Never cover the face. |
| [`tools/hyperframes/registry/9x16-editing/EDITING-COMPONENTS.md`](../../tools/hyperframes/registry/9x16-editing/EDITING-COMPONENTS.md) | One-page practical index of the bar. |
| [`tools/hyperframes/registry/9x16-editing/REFERENCE-ANALYSIS.md`](../../tools/hyperframes/registry/9x16-editing/REFERENCE-ANALYSIS.md) | The routed-spine / illustrated-explainer caliber (the craft ceiling). |
| [`tools/hyperframes/registry/9x16-editing/showcase-pro/showcase-pro.mp4`](../../tools/hyperframes/registry/9x16-editing/showcase-pro/) | The canonical build-to reel. Open it to calibrate the craft bar. |
| [`tools/hyperframes/registry/blocks/`](../../tools/hyperframes/registry/blocks/) | Reusable blocks (transitions, social UI cards, cinematic + polish effects, charts). Compose from these for bespoke moments. |
| `references/snippets.md` · `references/gold-standards.md` | **⚠️ SUPERSEDED** — the OLD Impact-Score / 7-second / 5–8-pop model. Kept only until a follow-up step deletes them. Do NOT follow them. The render-contract knowledge they once held is salvaged in `RENDER-CONTRACT.md`; the editorial bar is in `registry/9x16-editing/`. |

---

**Version:** 3.0
**Updated:** 2026-06-01
**Status:** Engine canonical (HyperFrames 0.6.56). Compose path = `pipeline-clip-pro/render_clip.sh`
(auto-EDL). Doctrine = density floor 12 / target 20, a motivated move every ~1.5–3s, de-stutter first,
keyword-pops never echo the caption, 2–3 model-written scene-takeovers, glossy stickers, sparse
whoosh-led SFX. v3.0 OVERTURNS the v2.x Impact-Score A/B/C + 7-second / 5–8-pop "less is more" model
(now SUPERSEDED in `references/`), salvages the 0.6.56 native render contract into
`pipeline-clip-pro/RENDER-CONTRACT.md`, and points the doctrine at `registry/9x16-editing/`.
