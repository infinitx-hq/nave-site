# Reference 03 — Frameworks + Slide Structures

> 6 carousel types + 6 narrative frameworks + 7 slide structures.

For each brief, follow 3 steps:

1. **Identify the carousel TYPE** (section 1)
2. **Pick the narrative FRAMEWORK** (section 2)
3. **Apply the slide STRUCTURE** (section 3)

Structures are **templates, not cages**. Adapt slide count (8-12) to content. Respect the narrative logic.

ALWAYS explain to the user why you pick X type and X framework. The user is learning.

---

## 1. The 6 carousel types

### 1.1 EDUCATIONAL / METHOD
Teaches a process, framework, system, or set of rules.
- **When:** You have a validated methodology to share
- **Goal:** Saves + authority
- **Examples:** "5 steps to X", "The 4 rules I apply for Y"
- **Typical slides:** 9-11

### 1.2 CASE STUDY
Tells a real story of a project or client.
- **When:** You have concrete results and permission to share them
- **Goal:** Authority + credibility + leads
- **Examples:** "How we rebranded [X]", "The project that almost failed"
- **Typical slides:** 8-10

### 1.3 LIST / LISTICLE
Numbered list of items (tools, mistakes, tips, resources).
- **When:** Value is in quantity/variety more than depth
- **Goal:** Saves + shares
- **Examples:** "10 X tools", "5 common mistakes in Y"
- **Typical slides:** N+3

### 1.4 STORYTELLING / NARRATIVE
Tells a story with beginning, conflict, resolution.
- **When:** You have an experience with real narrative tension
- **Goal:** Engagement + connection
- **Examples:** "How I lost my best client", "The day I decided X"
- **Typical slides:** 8-10

### 1.5 CONTRARIAN / MYTHBUSTING
Defends unpopular position or breaks common belief.
- **When:** You have data/experience to back the sharp opinion
- **Goal:** Shares (high virality) + authority
- **Examples:** "Why X is overrated", "You don't need Y"
- **Typical slides:** 7-9

### 1.6 ANNOUNCEMENT / LAUNCH
Announces something new (service, product, event).
- **When:** You have something concrete to sell
- **Goal:** Conversion / clicks / DMs
- **Examples:** "I opened X spots for new clients", "New course: [Y]"
- **Typical slides:** 6-8

---

## 2. The 6 narrative frameworks

Each framework is an emotional sequence. Picking framework = picking how the carousel feels.

### Framework 1 — AIDA
**Attention → Interest → Desire → Action**

| Phase | Function | Slides |
|---|---|---|
| Attention | Hook stops scroll | S1 |
| Interest | Info that triggers curiosity | S2-S3 |
| Desire | Show benefit or result | S4-S7 |
| Action | Specific CTA | S8-S10 |

**Best for:** Educational, announcement, list

### Framework 2 — PAS
**Problem → Agitation → Solution**

| Phase | Function | Slides |
|---|---|---|
| Problem | Identify the pain | S1-S2 |
| Agitation | Deepen the pain | S3-S4 |
| Solution | Your proposal | S5-S9 |
| Close | CTA | S10 |

**Best for:** Educational, contrarian, announcement

### Framework 3 — BAB
**Before → After → Bridge**

| Phase | Function | Slides |
|---|---|---|
| Before | How it was | S1-S3 |
| After | How it is now | S4-S6 |
| Bridge | The how (steps) | S7-S9 |
| CTA | Action | S10 |

**Best for:** Case study, transformation

### Framework 4 — Hero's Journey (condensed)
**Call → Conflict → Ally → Transformation**

| Phase | Function | Slides |
|---|---|---|
| Status quo | How everything was | S1-S2 |
| Inciting incident | The change | S3 |
| Crisis | The conflict | S4-S5 |
| Ally/insight | What changed | S6-S7 |
| Transformation | The after | S8-S9 |
| CTA | Lesson/action | S10 |

**Best for:** Storytelling, case study with strong narrative

### Framework 5 — Pure Listicle
**Intro → Item 1 → Item N → Summary → CTA**

**Best for:** List, resources, tools

### Framework 6 — Contrarian / Mythbusting
**Common premise → Why it's false → The truth → Implication**

**Best for:** Contrarian, sharp takes

---

## 3. Slide structures by type

### STRUCTURE A — EDUCATIONAL with NUMBERED LIST

| Slide | Role | Visual type | Notes |
|---|---|---|---|
| 01 | HERO | Text + optional photo | Strong hook |
| 02 | RE-HOOK | Pure dark text | Reinforces pain or curiosity |
| 03 | THESIS | Pure accent text | Absolute manifesto phrase |
| 04 | RULE 01 | Text + ghost number | Body + italic accent |
| 05 | RULE 02 | Same with ghost "02" | |
| 06 | RULE 03 | Same with ghost "03" | |
| 07 | RULE 04 | Same with ghost "04" | |
| 08 | INSIGHT | Pure CREAM text | Display + Serif italic |
| 09 | SUMMARY | Bento grid 2x2 | 4 cards |
| 10 | CTA | Text + big logo | Question + 2 actions |

### STRUCTURE B — EDUCATIONAL with METHOD/PROCESS

| Slide | Role | Visual type |
|---|---|---|
| 01 | HERO | Promise + time |
| 02 | INTRO | "This is what you'll learn" |
| 03 | THESIS | Why this method matters |
| 04 | STEP 01 | Action + ghost number |
| 05 | STEP 02 | Action + ghost number |
| 06 | STEP 03 | Action + ghost number |
| 07 | STEP 04 | Action + ghost number |
| 08 | EXAMPLE | Real case applying method |
| 09 | INSIGHT | Lesson or extra shortcut |
| 10 | CTA | Lead magnet (course/template/guide) |

### STRUCTURE C — CASE STUDY

| Slide | Role | Visual type |
|---|---|---|
| 01 | HERO | Project photo + title |
| 02 | CONTEXT | The client, the problem |
| 03 | CHALLENGE | The hard part |
| 04 | INSIGHT | The 'aha moment' |
| 05 | PROCESS | How we approached it |
| 06 | DECISION | The key decision |
| 07 | RESULT | Photo/data of result |
| 08 | DETAIL | Beautiful detail of the project |
| 09 | LESSON | What I take away |
| 10 | CTA | "Does your brand need this? DM me" |

### STRUCTURE D — LIST / LISTICLE

| Slide | Role |
|---|---|
| 01 | HERO with number in title |
| 02 | INTRO contextual |
| 03-(2+N) | 1 item per slide |
| (3+N) | BONUS item |
| (4+N) | CTA |

### STRUCTURE E — STORYTELLING

| Slide | Role | Visual type |
|---|---|---|
| 01 | HERO HOOK | Evocative photo + short phrase |
| 02 | CONTEXT | How it was before |
| 03 | INCIDENT | What happened |
| 04 | TENSION | The conflict |
| 05 | DECISION | The key moment |
| 06 | INSIGHT | What I understood |
| 07 | RESOLUTION | How it resolved |
| 08 | LESSON | Main idea (cream) |
| 09 | APPLICATION | How to apply it |
| 10 | CTA | Open personal question |

### STRUCTURE F — CONTRARIAN

| Slide | Role | Visual type |
|---|---|---|
| 01 | HERO | "You don't need X" hook |
| 02 | PREMISE | "They told you that..." |
| 03 | THESIS | Your refutation (accent bg) |
| 04 | EVIDENCE 1 | Why the premise fails |
| 05 | EVIDENCE 2 | Another angle |
| 06 | THE TRUTH | Your real proposal |
| 07 | EXAMPLE | Concrete case |
| 08 | INSIGHT | Conceptual close (cream) |
| 09 | CTA | Provocative question |

### STRUCTURE G — ANNOUNCEMENT / LAUNCH

| Slide | Role |
|---|---|
| 01 | HERO with clear announcement |
| 02 | CONTEXT: who it's for |
| 03 | WHAT'S INCLUDED |
| 04 | TESTIMONIAL or previous result |
| 05 | TERMS (price, deadline) |
| 06 | EXPLICIT CTA |
| 07 | "How to apply/buy" |

---

## 4. Decision tree — which structure?

Ask yourself in this order:

1. **Does the carousel announce something?** → STRUCTURE G
2. **Is it a story with conflict?** → STRUCTURE E
3. **Defends unpopular position?** → STRUCTURE F
4. **Real case of a project?** → STRUCTURE C
5. **List of N independent items?** → STRUCTURE D
6. **Teaches step-by-step process?** → STRUCTURE B
7. **Teaches independent rules/principles?** → STRUCTURE A

---

## 5. Slide count ranges

| Type | Ideal | Min | Max |
|---|---|---|---|
| Educational | 9-11 | 7 | 12 |
| Case study | 8-10 | 6 | 11 |
| List | N+3 | N+2 | N+4 |
| Storytelling | 8-10 | 7 | 11 |
| Contrarian | 7-9 | 6 | 10 |
| Announcement | 6-8 | 5 | 9 |

If you go past 12, split into 2 carousels series.

---

## 6. Universal narrative elements

Every carousel needs these 6:

| Element | Function | Typical slide |
|---|---|---|
| Hook | Stop scroll | S1 |
| Setup | Contextualize who/what/why | S2-S3 |
| Thesis | Central proposal | S3 or S4 |
| Evidence | Data, examples, items | S4-S(N-2) |
| Insight | "Aha moment" or lesson | S(N-2) or S(N-1) |
| CTA | Concrete action | S(N) |

If your structure is missing one, the carousel feels incomplete.

---

## 7. Big Idea examples by brand type

### Natural cosmetics — "How to care for your skin"
- A (Educational): "My 5-step skincare routine for sensitive skin"
- B (Contrarian): "You don't need 10 products. 3 done well change everything."
- C (Storytelling): "What happened to my skin when I dropped commercial products"

### Financial coach — "How to organize finances"
- A (Educational): "My 50/30/20 system explained step-by-step"
- B (Contrarian): "Saving doesn't make you rich. Investing doesn't either. Do this."
- C (Case study): "How Marta paid off $30K of debt in 18 months"

### Bakery — "Tips for home baking"
- A (Educational): "5 techniques so your cake doesn't sink"
- B (List): "10 ingredients I ALWAYS keep in my pantry"
- C (Storytelling): "The cake that made me open my bakery"

### SaaS for freelancers — "Productivity"
- A (Educational): "My workflow to manage 5 clients without collapse"
- B (Contrarian): "Tools don't organize you. Processes do."
- C (Case study): "How Lucia went from 80 to 120 invoices/month"

---

## 8. Pre-Phase 6 checklist

Before proposing slide structure, confirm:

- [ ] Clear about the carousel type?
- [ ] Picked the right narrative framework?
- [ ] Structure has the 6 universal elements?
- [ ] Slide count is within ideal range?
- [ ] Visual variation (at least 1 cream or accent slide)?
- [ ] S1 has hook validated against the 5 formulas (in `01-brand-and-voice.md`)?
- [ ] S(N) has specific CTA?
