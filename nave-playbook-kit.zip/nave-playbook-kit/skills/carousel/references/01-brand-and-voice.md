# Reference 01 — Brand Discovery + Voice

Phase 1 of the workflow. Without a clear brand profile + voice, every carousel ends up "pretty but generic" — the worst result possible. This reference is the foundation. Get it right and everything else flows.

The typical user is **intermediate at branding** — knows the basics, rarely has a formal brand book. Your job is to **extract** what they already know but haven't articulated, not to teach them from zero.

---

## 1. The 5 mandatory questions

Non-negotiable. Always ask all 5. Ask them in blocks of 1-2, not all at once — users get overwhelmed.

### Q1 — What does it do?
> "What does your brand do? Tell me in one sentence, like you'd say it to someone at a party."

**Why:** Gives you the base category + signals how clearly the user understands their own business. If they can't do it in one sentence, that's the first job — clarity.

**Red flag:** "Many things, depends on the client" → help them focus before continuing.

### Q2 — Who is it for?
> "Who is it for? Describe your ideal client: rough age, what they do, what problem you solve for them."

**Why:** Defines the carousel's audience. Voice changes drastically depending on whether you're talking to 25-35-year-old freelancers vs 40-55-year-old business owners vs 18-22-year-old students.

**Red flag:** "Everyone" → help them specify. "Everyone" is not an audience.

### Q3 — Promise / transformation
> "What's the promise or transformation you offer? Before your brand, your client is [X]. After, they're [Y]."

**Why:** This is the heart of positioning. Without a clear promise, the carousel is informative but not persuasive.

### Q4 — Differentiator
> "How do you differentiate from your main competitors? What do you do differently from others offering the same?"

**Why:** Gives you the unique angle for the carousel. Without differentiation, the carousel becomes one more in the feed.

**Red flag:** "Quality and service" → everyone says that. Push for a real differentiator.

### Q5 — Personality
> "If your brand were a person, what 3-5 adjectives would describe them? More warm or more cool? More serious or more playful? More sophisticated or more accessible?"

**Why:** Defines the visual + verbal voice. Most subjective question, but most important for the visual system.

---

## 2. Deepening questions (by context)

After the 5, pick 2-3 follow-ups based on the answers:

### If brand is SERVICE
- "Hourly, project-based, or value-based pricing?"
- "How does your sales process work? Closing via DM, email, landing page?"

### If brand is PRODUCT
- "Physical or digital?"
- "Price range? (orientation: <$30 / $30-200 / $200+)"
- "Selling via ecommerce, marketplaces, DM?"

### If brand is PERSONAL BRAND
- "Are you a content creator, consultant, freelancer, or selling digital products?"
- "What authority or credibility have you built in your niche?"

### If brand is NEW (<1 year)
- "Validating or already have clients?"
- "Goals for this carousel: brand awareness, leads, or community-building?"

### If brand is ESTABLISHED (>2 years)
- "Do you have an existing brand book or visual system to respect?"
- "Anything about the current style you want to change or evolve?"

### If they mention "we want to sell more"
- "Is the carousel for direct conversion (lead magnet, offer) or for authority/branding?"

---

## 3. The 12 brand archetypes → typographic kit recommendation

After the 5 questions, identify the **dominant archetype**. Drives the visual system + voice in Phase 2.

| Archetype | Essence | Example brands | Recommended kit |
|---|---|---|---|
| **Innocent** | Purity, simplicity, optimism | Coca-Cola, Dove | Modern Clean / Warmth |
| **Sage** | Knowledge, authority, truth | Google, Harvard, Stanford | Serif Classic / Editorial |
| **Hero** | Courage, achievement, overcoming | Nike, Adidas | Brutalist / Modern Clean |
| **Outlaw** | Rebellion, freedom, breaking rules | Harley-Davidson, Tesla | Brutalist / Y2K |
| **Magician** | Transformation, inspiration | Apple, Disney | Editorial / Y2K |
| **Everyman** | Belonging, connection | Levi's, Budweiser | Playful / Warmth |
| **Lover** | Passion, sensuality, desire | Victoria's Secret, Chanel | Editorial / Serif Classic |
| **Jester** | Fun, lightness, humor | M&M's, Old Spice | Playful / Y2K |
| **Caregiver** | Protection, help, service | Johnson & Johnson, UNICEF | Warmth / Modern Clean |
| **Creator** | Innovation, artistic expression | Lego, Adobe | Playful / Editorial |
| **Ruler** | Leadership, control, power | Mercedes, Rolex, IBM | Corporate Tech / Serif Classic |
| **Explorer** | Discovery, freedom, adventure | The North Face, Jeep | Brutalist / Modern Clean |

### How to identify

Match the user's adjectives from Q5 + general context:

| If user says... | Probably is... |
|---|---|
| Sophisticated, premium, elegant | Lover / Sage / Ruler |
| Close, friendly, accessible | Everyman / Caregiver |
| Expert, technical, trustworthy | Sage / Ruler |
| Disruptive, rebellious, different | Outlaw / Hero |
| Creative, playful, original | Creator / Jester |
| Inspiring, transformative, magical | Magician |
| Caring, warm, safe | Caregiver / Innocent |
| Adventurous, free, exploratory | Explorer |

### How to present

```
From your answers, your brand has a lot of the [ARCHETYPE] archetype.
This means [brief definition + one well-known brand example].

This will guide my visual system proposal. Does that resonate?
```

If it doesn't resonate, ask which one does and adjust. Archetype is a proposal, not an imposition.

---

## 4. Extracting the voice the user doesn't know they have

Many users can't articulate their voice but USE it unconsciously. Techniques to extract it:

### Technique 1: Have them write as they'd speak
> "Imagine a potential client DMs you and asks: 'Why should I hire you instead of someone else?' Write me your exact answer, like you'd send it via DM."

Gives you: real vocabulary, tone, preferred length, formality, emoji use.

### Technique 2: Ask about their references
> "What 3 Instagram accounts do you follow + admire for HOW they communicate (not for the product)?"

Gives you concrete references you can analyze.

### Technique 3: Ask about anti-references
> "What kind of brand communication do you HATE? Anything you'd never say?"

Gives you the auto-blacklist.

### Technique 4: Read how they write to you
Look at HOW the user writes in chat. Formal or casual? Audio messages? Emojis? That tells you a lot about their natural voice.

---

## 5. Voice — the 4 dimensions

Every voice is defined by 4 dimensions. Ask in order, one at a time.

### Dimension 1 — Formality
> "How do you address your client: formal 'you' or casual 'you'?"

**Sub-questions:**
- In your existing DMs and emails, what do you use?
- Is your audience younger (informal) or senior professionals (formal)?

**Implications:**
- **Casual:** carousels feel close, accessible
- **Formal:** B2B serious, traditional sectors, premium consulting

### Dimension 2 — Regional language
> "Does your brand use regional expressions, slang, spanglish, or do you prefer neutral language?"

**Sub-questions:**
- Specific country/region audience or international?
- Words you definitely want to use?
- Words that bother you when used inappropriately?

**Implications:**
- **Regional allowed:** more authentic, connects with local audience
- **Neutral:** broader international reach, sounds more "brand"
- **Mixed:** works for digital creators, doesn't work for everyone

### Dimension 3 — Emojis
> "Do you use emojis in your copy? If yes, which YES and which NO?"

**Sub-questions:**
- How many per post (none, 1-2, multiple)?
- Specific emojis as your signature?
- Banned emojis? (e.g., "the laughing-with-tears one feels cringe to me")

**Implications:**
- **No emojis:** sophisticated/serious brands (editorial, corporate, luxury)
- **1-2 strategic:** professional brands with personality
- **Multiple:** creators, food, lifestyle, youth-oriented
- **Signature emojis:** strong identity (e.g., always 🤍 at end)

### Dimension 4 — Blacklist
> "Are there words or phrases you DON'T want to see in your copy? Anything that feels cringe, too marketing-speak, or just not your brand?"

**Sub-questions if they can't think of any:**
- Do you like "leverage", "unlock", "elevate"?
- Does "in today's world" / "in the digital age" bother you?
- Industry clichés you hate?

**General blacklist (valid for almost all brands):**
- "In today's world" / "In this day and age"
- "Hand-in-hand with"
- "It's important to highlight"
- "Worth mentioning"
- "Without a doubt"
- "In the modern era"
- "The digital age"

**Marketing-speak blacklist:**
- Leverage → use, apply
- Unlock → open, reveal
- Delve → explore, dig into
- Navigate → walk through, explore
- Elevate → raise
- Disruptive → (just describe what's different)
- Game-changer
- Innovative (without specifics)

### Output after the 4 dimensions

```
VOICE OF [BRAND]:

📏 Formality
[Casual / Formal / Regional default]

🌍 Regional
[Allowed / Neutral / Specific region]
Own words: [list]

😊 Emojis
[Frequency] · [Type: minimal, multiple, signature]
Banned: [list]

🚫 Blacklist
[forbidden words/phrases]

✅ Vocabulary
[brand/industry-specific words]
```

---

## 6. The 5 universal hook formulas

These work in ANY voice. Just change the vocabulary.

### Formula 1 — Vulnerable confession
**Structure:** "[Thing I did wrong]. [What I learned after]."

| Brand type | Version |
|---|---|
| Personal brand coach | "Charged half what I was worth. Then I understood this." |
| Food product | "Burned 5 batches before nailing the recipe. Save you the mistakes." |
| Corporate | "Lost $50K on a failed experiment. The 3 lessons." |

### Formula 2 — Sharp contrarian
**Structure:** "You don't need [the common]. You need [the truth]."

| Brand | Version |
|---|---|
| Productivity coach | "You don't need to wake up at 5am. You need 8 hours of sleep." |
| SaaS | "You don't need more tools. You need better processes." |
| Skincare | "You don't need 12 products. You need 3 well-applied." |

### Formula 3 — Concrete numerical promise
**Structure:** "[Verb] in [time]. Without [common expectation]."

| Brand | Version |
|---|---|
| Course | "Learn to edit photos in 1 week. Without boring tutorials." |
| Consulting | "Raised my prices 40% in 30 days. Without losing clients." |
| Product | "Deep clean in 5 minutes. Without chemicals." |

### Formula 4 — Provocative question
**Structure:** "[Question that triggers curiosity or self-criticism]?"

| Brand | Version |
|---|---|
| Personal brand | "Why don't your clients refer you?" |
| Product | "Do you know how much plastic you generated this year?" |
| SaaS | "How much does each minute on manual tasks cost you?" |

### Formula 5 — Pure listicle
**Structure:** "[Number] [things/rules/mistakes/secrets] that [verb]."

| Brand | Version |
|---|---|
| Cosmetics | "5 ingredients I avoid in my products." |
| Consulting | "3 mistakes 9 of 10 entrepreneurs make." |
| Creator | "10 AI tools for designers." |

### Hook rules
- ❌ Never start with greetings ("Hi everyone")
- ❌ Never start with disclaimers ("This is just my experience...")
- ❌ Never use exclamation marks or emojis in the hook
- ✅ Maximum 2 lines or 12 words
- ✅ Critical info in the first 6 words

---

## 7. Caption anatomy

### Validated structure

```
[HOOK punchy — 1-2 lines]
[blank line]
[SETUP personal — 2-3 lines building credibility]
[blank line]
[PUNCHLINE / transition — 1 line]
[blank line]
[BRIDGE to the carousel — 1-2 lines]
[blank line]
[MICRO CTA organic: Save it / Send it ↗]
[blank line]
—
[blank line]
[📝 LEAD MAGNET (if applicable)]
[Drop the word X in comments and I'll DM it.]
[blank line]
—
[blank line]
[CLOSING QUESTION — invites deep comments]
[blank line]
[5 niche hashtags]
```

### Rules
- Total length: 600-1200 chars (~120-220 words)
- Hook visible without "see more" = first 125 chars
- Spacing: double line break between blocks
- Hashtags at end: 5-8, niche-specific (not generic #ai #marketing)

---

## 8. The 3 caption templates

### Template A — Personal / Vulnerable

**When:** Personal lessons, shared mistakes, vulnerability moments

```
[Hook — personal confession]

[Context: who you are, what you were doing]

Spoiler: [vulnerable punchline]

The [N] [rules/things/lessons] in the carousel are what I apply today. [Concrete benefit].

Save it or send it to whoever needs it ↗

—

📝 [Lead magnet if applicable]

—

[Specific question]? [Point X] changed how I [verb].

#[hashtags]
```

**Best for:** personal brands, coaches, creators with own narrative

### Template B — Contrarian / Authority

**When:** Defending unpopular position, mythbusting, sharp takes

```
[Hook — contrarian]

[Credibility: "After months doing X..."]

[Explanation of contrary idea]

The [N] [rules] in the carousel are what I apply daily. [Benefit].

Save it. Send it to [type of person] ↗

—

[📝 Lead magnet if applicable]

—

[Provocative question]? Most [do the common thing].

#[hashtags]
```

**Best for:** authority brands, experts, consultants

### Template C — Educational / Method

**When:** 100% educational carousels, frameworks, systems

```
[Hook — concrete promise]

[Who it's for]

[How you developed it]

In the carousel I drop [structure: the method / the N rules / the framework].

Save if useful. Send to whoever you know needs it ↗

—

📝 [Lead magnet if applicable]

—

What [verb] are you in right now? If [condition], [action].

#[hashtags]
```

**Best for:** educators, courses, generous professional brands

---

## 9. Adapting copy to the user's voice

When writing slide copy AND the caption, apply these transforms:

### If voice = CASUAL + REGIONAL + MIXED EMOJIS
Hook examples: "Burned my plan...", "No way man, this..."
CTA examples: "Send it to your freelancer friend"

### If voice = CASUAL + NEUTRAL + NO EMOJIS
Hook examples: "5 things I learned...", "What nobody tells you about..."
CTA examples: "Save this if it serves you"

### If voice = FORMAL + ENGLISH + NO EMOJIS
Hook examples: "5 strategies every business should know", "The method for..."
CTA examples: "Share this with your team"

---

## 10. Copy by slide type

### Hero S1
- Hero text: 6-12 words MAX
- If photo: high contrast text vs photo
- Optional subtitle: 5-10 words secondary

### Re-hook S2
- Reinforces pain or curiosity from S1
- 4-8 hero words + clarifying subtitle
- Ends with micro-promise ("Let's fix that." / "Let me explain.")

### Thesis S3
- Short, absolute phrase
- Accent background (brand main color) for impact
- 6-10 words

### Rules/Points S4-S7
- Headline: 3-6 manifesto words
- Explanatory body: 2-4 sentences with data
- Italic accent: 1 memorable phrase

### Insight (cream slide breather)
- Display text + italic accent text
- Zero extra UI
- Visual breather

### Summary bento S9
- Header: "The [N] [rules/points]"
- 4 cards: number + short title + mono caption
- Zero extra body

### CTA S10
- Big rhetorical question
- 2 actions: ↓ SAVE + ↗ SEND
- Big logo + credit

---

## 11. Common copy mistakes

1. **Imposing tone X when brand isn't X** — don't use casual Mexican slang for a Madrid executive coaching brand
2. **Generic motivational** — "You can do it! Today's the best day!" → EMPTY. Use data, examples, concrete angles
3. **Too long** — slides with 60+ word paragraphs lose retention. If past 4 sentences, cut
4. **Multiple CTAs in same slide** — "Save + Send + Comment + Follow" → confusing. Max 2 CTAs
5. **Forgetting user's voice for "what's viral"** — authenticity scales better than copying viral formulas

---

## 12. Pre-handoff copy checklist

Before passing copy to Phase 4 (HTML build), verify:

- [ ] No slide uses words from the user's blacklist
- [ ] Formality is consistent across ALL slides
- [ ] Regional level is consistent (not mixing regions)
- [ ] Emojis match user preference
- [ ] Hook S1 stops scroll (test: would you read it?)
- [ ] CTA S10 is clear and specific
- [ ] Caption has all 5 blocks (hook + setup + bridge + CTA + lead magnet + question + hashtags)

---

## 13. Phase 1 output format

Before moving to Phase 2, present this summary block:

```
BRAND PROFILE — [NAME]

📌 Category
[Service/Product/Personal brand] of [what they do]

🎯 Audience
[specific ideal client description]

✨ Promise
Before: [client state]
After: [desired state]

🔥 Differentiator
[what makes them unique]

🎭 Personality (3-5 adjectives)
[adjectives]

⚡ Dominant archetype
[archetype] — [brief why]

📚 References mentioned
[admired accounts/brands]

🚫 Initial blacklist
[what they DON'T want in their brand/copy]

VOICE
- Formality: [casual/formal/regional]
- Regional: [allowed/neutral/specific]
- Emojis: [frequency + type]
- Banned words: [list]

Do you recognize your brand in this? If anything is off, tell me what to adjust.
```

User validates → move to Phase 2.
User corrects → adjust + re-present.

---

## 14. Signals you need more discovery

DO NOT advance to Phase 2 if:

- ❌ User can't explain what they do in 1 clear sentence
- ❌ User says "for everyone" as audience
- ❌ User doesn't know their differentiator
- ❌ Personality adjectives are contradictory without context
- ❌ User is doubting their own brand (deeper problem than a carousel)

In those cases, help the user clarify before continuing. Offer support questions or examples.

---

## 15. Common discovery mistakes

1. **Asking all 5 questions in one message** — users get overwhelmed. Ask in blocks of 1-2
2. **Accepting vague answers** — "Healthy food brand for everyone" is not an answer. Push with support questions
3. **Imposing an archetype that doesn't resonate** — if user says "I don't see myself like that," find another. Archetype belongs to the brand, not to you
4. **Skipping discovery because "you got it"** — NEVER. Even if you understand, the user needs the process to own their system
5. **Being too theoretical** — don't explain all 12 archetypes in depth. Only the relevant one
