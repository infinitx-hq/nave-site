# Reference 04 — HTML Template + Build

> Reusable technical system adaptable to any brand. CSS base + slide snippets + Python build script + Playwright render.

This document contains:
1. **CSS base** with design tokens variables (change 4 colors, everything changes)
2. **HTML snippets** for each slide type (hero photo, hero text, rule, insight, bento, CTA)
3. **Python build script** that generates the complete HTML
4. **Playwright render** to retina PNGs
5. **Kit loading** + palette adaptation + quality checklist

**Embedded base64 fonts live in separate files:** `assets/kits_tipograficos/{kit_id}/fonts_embedded.css`. Load that file dynamically based on the kit chosen by the user in Phase 2.

---

## 1. CSS base — design tokens + components

```css
:root {
  /* COLORS — user configures these in Phase 2 */
  --black:    #0A0A0A;   /* main dark slide background */
  --smoke:    #141414;   /* alternative bg, cards */
  --charcoal: #1F1F1F;   /* separators, depth */
  --steel:    #2A2A2A;   /* ghost number stroke */
  --mid:      #3A3A3A;   /* dividers */
  --ash:      #6B6B6B;   /* secondary text */
  --cream:    #F2EBDD;   /* breather slide bg */
  --paper:    #E8DFC9;   /* warmer cream alternative */
  --white:    #FFFFFF;   /* main text on dark */
  --accent:   #E94822;   /* main accent (brand color) */
  --neon:     #E8FF00;   /* punctual highlight */

  /* TYPOGRAPHY — user configures based on kit */
  --f-display: 'Anton', Impact, 'Arial Narrow', sans-serif;
  --f-serif:   'Instrument Serif', Georgia, serif;
  --f-body:    'Inter', system-ui, -apple-system, sans-serif;
  --f-mono:    'JetBrains Mono', ui-monospace, 'SF Mono', Monaco, monospace;

  /* LAYOUT */
  --safe: 80px;
}

* { margin: 0; padding: 0; box-sizing: border-box; }

body {
  background: #0e0e10;
  font-family: var(--f-body);
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
}

.slide {
  width: 1080px;
  height: 1350px;
  position: relative;
  overflow: hidden;
  background: var(--black);
  color: var(--white);
}

/* ===== UI COMPONENTS ===== */

.ui-top {
  position: absolute;
  top: var(--safe);
  left: var(--safe);
  z-index: 30;
}
.ui-tag {
  font-family: var(--f-mono);
  font-weight: 500;
  font-size: 14px;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: var(--cream);
}
.ui-tag .star { color: var(--neon); }

.slide-num {
  position: absolute;
  bottom: 60px;
  right: 60px;
  z-index: 35;
  font-family: var(--f-mono);
  font-weight: 500;
  font-size: 14px;
  letter-spacing: 0.18em;
  color: var(--ash);
}

.logo-corner {
  position: absolute;
  bottom: 60px;
  left: 60px;
  z-index: 35;
}

/* GHOST NUMBER */
.ghost {
  position: absolute;
  font-family: var(--f-display);
  font-weight: 400;
  line-height: 0.78;
  color: transparent;
  -webkit-text-stroke: 3px var(--steel);
  pointer-events: none;
  user-select: none;
  z-index: 5;
  opacity: 0.85;
}

/* HERO BLOCKS */
.hero {
  font-family: var(--f-display);
  font-weight: 400;
  line-height: 0.92;
  letter-spacing: -0.015em;
  color: var(--white);
  text-transform: uppercase;
  text-align: left;
}
.hero-large { font-size: 220px; }
.hero-medium { font-size: 150px; }
.hero-small { font-size: 110px; }

.italic-accent {
  font-family: var(--f-serif);
  font-style: italic;
  font-weight: 400;
  letter-spacing: -0.025em;
  text-align: left;
  color: var(--accent);
}

.body-text {
  font-family: var(--f-body);
  font-weight: 500;
  font-size: 36px;
  line-height: 1.4;
  color: var(--cream);
}
.body-text strong { font-weight: 700; color: var(--white); }
.body-text .hl {
  background: var(--neon);
  color: var(--black);
  font-weight: 700;
  padding: 2px 8px;
}

/* VIGNETTE for photos */
.vignette {
  position: absolute;
  inset: 0;
  z-index: 10;
  pointer-events: none;
  background:
    linear-gradient(to bottom,
      rgba(0,0,0,0.55) 0%,
      transparent 22%,
      transparent 60%,
      rgba(0,0,0,0.85) 100%),
    radial-gradient(ellipse 80% 60% at 50% 35%,
      transparent 0%,
      rgba(0,0,0,0.5) 90%);
}

/* DOWNLOAD BAR (preview only) */
.dl-bar {
  position: fixed;
  top: 16px; left: 50%;
  transform: translateX(-50%);
  background: rgba(10,10,10,0.95);
  border: 1px solid var(--steel);
  padding: 12px 20px;
  font-family: var(--f-mono);
  font-size: 12px;
  color: var(--cream);
  cursor: pointer;
  z-index: 9999;
  border-radius: 4px;
  letter-spacing: 0.1em;
}
```

---

## 2. Slide snippets

### 2.1 Hero with photo background (S1 type)

```html
<section class="slide" data-slide="01">
  <img src="data:image/jpeg;base64,{IMAGE_BASE64}"
       style="width:100%; height:100%; object-fit:cover; object-position:center 30%;" />
  <div class="vignette"></div>

  <div class="ui-top">
    <span class="ui-tag"><span class="star">*</span> {TAG_TEXT}</span>
  </div>

  <div style="position:absolute; left:80px; right:80px; bottom:220px; z-index:25;">
    <div class="hero hero-large">{TITLE_LINE_1}<br>{TITLE_LINE_2}</div>
    <div style="font-family:var(--f-display); font-weight:400; font-size:58px; line-height:1.05; color:var(--cream); text-transform:uppercase; margin-top:28px; text-align:left;">
      {SUBTITLE} <span style="color:var(--accent);">{ACCENT_WORDS}</span>
    </div>
  </div>

  <div class="logo-corner">{OPTIONAL_LOGO}</div>
  <div class="slide-num">01 / 10</div>
</section>
```

### 2.2 Pure text hero on dark (S2 type)

```html
<section class="slide" data-slide="02">
  <div style="position:absolute; inset:0; display:flex; flex-direction:column; justify-content:center; padding:0 80px; z-index:25;">
    <div class="hero" style="font-size:230px; letter-spacing:-0.015em; line-height:0.92;">{TITLE}</div>
    <div class="hero" style="font-size:78px; color:var(--ash); margin-top:32px; line-height:1.0;">{SUBTITLE}</div>
    <div class="italic-accent" style="font-size:54px; line-height:1.1; margin-top:48px;">
      <span style="display:inline-block; transform:translateY(-4px); margin-right:12px;">→</span>{ITALIC_TEXT}
    </div>
  </div>

  <div class="ghost" style="font-size:1100px; right:-80px; bottom:-200px; opacity:0.7;">02</div>

  <div class="ui-top"><span class="ui-tag"><span class="star">*</span> {TAG}</span></div>
  <div class="slide-num">02 / 10</div>
</section>
```

### 2.3 Thesis with accent background (S3 type)

```html
<section class="slide" data-slide="03" style="background:var(--accent); color:var(--black);">
  <div style="position:absolute; inset:0; display:flex; align-items:center; justify-content:flex-start; padding:0 80px; z-index:25;">
    <div class="hero" style="font-size:180px; line-height:0.92; color:var(--black);">
      {LINE_1}<br>{OPTIONAL_LINE_2}
    </div>
  </div>

  <div class="ui-top">
    <span class="ui-tag" style="color:var(--black);"><span class="star" style="color:var(--black);">*</span> {TAG}</span>
  </div>
  <div class="slide-num" style="color:var(--black); opacity:0.6;">03 / 10</div>
</section>
```

### 2.4 Rule with ghost number (S4-S7 type)

```html
<section class="slide rule" data-slide="04">
  <div class="ghost" style="font-size:1500px; right:-180px; bottom:-420px;">01</div>

  <div style="position:absolute; left:80px; right:80px; top:160px; z-index:25;">
    <div class="hero hero-small" style="max-width:920px;">
      {RULE_TITLE}
    </div>

    <p class="body-text" style="margin-top:48px; max-width:760px;">
      {BODY_DESCRIPTION}
    </p>

    <div class="italic-accent" style="font-size:42px; line-height:1.25; margin-top:32px;">
      {MEMORABLE_ITALIC_PHRASE}
    </div>
  </div>

  <div class="ui-top"><span class="ui-tag"><span class="star">*</span> RULE 01 / 04</span></div>
  <div class="slide-num">04 / 10</div>
</section>
```

### 2.5 Insight cream (S8 type)

```html
<section class="slide" data-slide="08" style="background:var(--cream); color:var(--black);">
  <div style="position:absolute; left:80px; right:80px; top:300px; z-index:25;">
    <div class="hero" style="font-size:150px; line-height:0.95; color:var(--black);">
      {HERO_LINE_BLACK}
    </div>
    <div class="italic-accent" style="font-size:220px; line-height:0.95; margin-top:24px; color:var(--accent);">
      {ITALIC_HERO_ACCENT}
    </div>
  </div>

  <div class="ui-top">
    <span class="ui-tag" style="color:var(--ash);">
      <span class="star" style="color:var(--accent);">*</span> INSIGHT
    </span>
  </div>
  <div class="slide-num" style="color:var(--ash);">08 / 10</div>
</section>
```

### 2.6 Bento grid summary (S9 type)

```html
<section class="slide" data-slide="09">
  <div style="padding:80px; height:100%; display:flex; flex-direction:column;">
    <div class="ui-tag" style="margin-bottom:24px;">
      <span class="star">*</span> {TAG}
    </div>
    <div class="hero hero-small" style="margin-bottom:8px;">{HEADER}</div>
    <div class="italic-accent" style="font-size:42px; line-height:1.25; margin-bottom:48px;">
      {ITALIC_SUBHEADER}
    </div>

    <div style="display:grid; grid-template-columns:1fr 1fr; grid-template-rows:1fr 1fr; gap:16px; flex:1;">
      <div style="background:var(--smoke); padding:48px 40px; border-top:4px solid var(--accent); display:flex; flex-direction:column; justify-content:space-between;">
        <div>
          <div style="font-family:var(--f-display); font-weight:400; font-size:92px; line-height:1; color:var(--accent);">01</div>
          <div style="font-family:var(--f-display); font-weight:400; font-size:44px; line-height:1.05; color:var(--white); text-transform:uppercase; margin-top:24px; text-align:left;">
            {CARD_1_TITLE}
          </div>
        </div>
        <div style="font-family:var(--f-mono); font-weight:500; font-size:14px; color:var(--ash); letter-spacing:0.15em; text-transform:uppercase;">
          {CARD_1_CAPTION}
        </div>
      </div>

      <!-- Cards 2, 3, 4: same structure -->
    </div>
  </div>

  <div class="slide-num">09 / 10</div>
</section>
```

### 2.7 Final CTA (S10 type)

```html
<section class="slide" data-slide="10">
  <div class="ghost" style="font-size:800px; left:-80px; top:-100px; -webkit-text-stroke:2px var(--mid); opacity:0.6;">?</div>

  <div class="ui-top"><span class="ui-tag"><span class="star">*</span> CLOSE</span></div>

  <div style="position:absolute; left:80px; right:80px; top:160px; z-index:25;">
    <div class="hero" style="font-size:220px; line-height:0.92; margin-top:48px;">
      {QUESTION_HERO}
    </div>

    <div style="margin-top:60px; display:flex; flex-direction:column; gap:32px;">
      <div style="display:flex; align-items:flex-start; gap:24px;">
        <div style="font-family:var(--f-display); font-weight:400; font-size:56px; line-height:1; color:var(--accent);">↓</div>
        <div>
          <div style="font-family:var(--f-display); font-weight:400; font-size:70px; line-height:1; color:var(--white); text-transform:uppercase;">
            {ACTION_1}
          </div>
          <div style="font-family:var(--f-body); font-weight:500; font-size:24px; color:var(--cream); margin-top:8px;">
            {ACTION_1_DESCRIPTION}
          </div>
        </div>
      </div>
      <div style="display:flex; align-items:flex-start; gap:24px;">
        <div style="font-family:var(--f-display); font-weight:400; font-size:56px; line-height:1; color:var(--accent);">↗</div>
        <div>
          <div style="font-family:var(--f-display); font-weight:400; font-size:70px; line-height:1; color:var(--white); text-transform:uppercase;">
            {ACTION_2}
          </div>
          <div style="font-family:var(--f-body); font-weight:500; font-size:24px; color:var(--cream); margin-top:8px;">
            {ACTION_2_DESCRIPTION}
          </div>
        </div>
      </div>
    </div>
  </div>

  <div style="position:absolute; bottom:60px; left:60px; right:60px; display:flex; justify-content:space-between; align-items:flex-end; z-index:35;">
    {OPTIONAL_BIG_LOGO}
    <div style="font-family:var(--f-mono); font-weight:500; font-size:14px; color:var(--cream); text-align:right; max-width:280px; letter-spacing:0.15em; line-height:1.5;">
      <span style="color:var(--accent);">→</span> {CREDIT_TEXT}
    </div>
  </div>

  <div class="slide-num">10 / 10</div>
</section>
```

---

## 3. Python build script

```python
import os, base64

OUTPUT_HTML = "output/carousels/{brand-slug}-{topic}/{brand-slug}-{topic}.html"
KIT_ID = "kit_01_editorial"  # Phase 2 — chosen by user

# 1. Load embedded fonts for chosen kit
FONTS_PATH = f'.claude/skills/carousel/assets/kits_tipograficos/{KIT_ID}/fonts_embedded.css'
with open(FONTS_PATH, 'r') as f:
    FONTS_CSS = f.read()

# 2. Base CSS + custom variables
PALETTE = {
    'black': '#0A0A0A',
    'cream': '#F2EBDD',
    'accent': '#E94822',  # brand main color
    'neon': '#E8FF00',
}

CSS_BASE = '''
:root {{
  --black:   {black};
  --cream:   {cream};
  --accent:  {accent};
  --neon:    {neon};
  --smoke:   #141414;
  --charcoal:#1F1F1F;
  --steel:   #2A2A2A;
  --mid:     #3A3A3A;
  --ash:     #6B6B6B;
  --paper:   #E8DFC9;
  --white:   #FFFFFF;
  --safe:    80px;

  /* Fonts per chosen kit */
  --f-display: 'Anton', Impact, sans-serif;
  --f-serif:   'Instrument Serif', Georgia, serif;
  --f-body:    'Inter', system-ui, sans-serif;
  --f-mono:    'JetBrains Mono', monospace;
}}
'''.format(**PALETTE)

# 3. Image to base64 (if any)
def img_to_b64(path):
    with open(path, 'rb') as f:
        return base64.b64encode(f.read()).decode('utf-8')

# 4. Build complete HTML
html = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Carousel — {{brand_name}} — {{topic}}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<style id="embedded-fonts">
{FONTS_CSS}
</style>
<style>
{CSS_BASE}
{CSS_COMPONENTS_FROM_SECTION_1}
</style>
</head>
<body>

<div class="dl-bar" onclick="downloadAll()">⬇ DOWNLOAD ALL 10 SLIDES</div>

<!-- 10 slides here -->

<script>
async function downloadAll() {{
  const slides = document.querySelectorAll('.slide');
  for (let i = 0; i < slides.length; i++) {{
    const canvas = await html2canvas(slides[i], {{scale: 2, useCORS: true}});
    const link = document.createElement('a');
    link.download = `{{brand}}-{{topic}}-slide-${{String(i+1).padStart(2,'0')}}.png`;
    link.href = canvas.toDataURL();
    link.click();
    await new Promise(r => setTimeout(r, 300));
  }}
}}
</script>

</body>
</html>'''

# 5. Save
os.makedirs(os.path.dirname(OUTPUT_HTML), exist_ok=True)
with open(OUTPUT_HTML, 'w') as f:
    f.write(html)
print(f"✓ HTML generated: {len(html)/1024:.0f} KB")
```

---

## 4. Render to PNG with Playwright

```python
from playwright.sync_api import sync_playwright
import os, zipfile

OUTPUT_DIR = 'output/carousels/{brand-slug}-{topic}/slides'
os.makedirs(OUTPUT_DIR, exist_ok=True)

html_path = 'output/carousels/{brand-slug}-{topic}/{brand-slug}-{topic}.html'

with sync_playwright() as p:
    browser = p.chromium.launch(args=['--font-render-hinting=none'])
    context = browser.new_context(
        viewport={'width': 1080, 'height': 1350},
        device_scale_factor=2  # RETINA
    )
    page = context.new_page()
    page.goto(f'file://{os.path.abspath(html_path)}')
    page.wait_for_load_state('networkidle')
    page.evaluate("document.fonts.ready")
    page.wait_for_timeout(3000)
    page.evaluate("document.querySelector('.dl-bar').style.display='none'")

    slides = page.locator('.slide')
    for i in range(slides.count()):
        slide = slides.nth(i)
        slide_num = slide.get_attribute('data-slide')
        slide.screenshot(path=f'{OUTPUT_DIR}/slide-{slide_num}.png')

    browser.close()

# ZIP
zip_path = 'output/carousels/{brand-slug}-{topic}/{brand-slug}-{topic}-10-slides.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for f in sorted(os.listdir(OUTPUT_DIR)):
        zf.write(os.path.join(OUTPUT_DIR, f), arcname=f)
```

---

## 5. Loading the typographic kit

When building the HTML:

### Step 1 — Identify the chosen kit
In Phase 2, user picked a kit (e.g., `kit_07_warmth`).

### Step 2 — Read the kit's fonts file
```python
KIT_ID = 'kit_07_warmth'  # from user
FONTS_PATH = f'.claude/skills/carousel/assets/kits_tipograficos/{KIT_ID}/fonts_embedded.css'

with open(FONTS_PATH, 'r') as f:
    fonts_css = f.read()
```

### Step 3 — Inject in HTML `<head>`
```html
<style id="embedded-fonts">
{fonts_css}
</style>
```

### Step 4 — Configure CSS variables per kit
Example for Warmth:
```css
:root {
  --f-display: 'Fraunces', Georgia, serif;
  --f-body:    'Karla', system-ui, sans-serif;
  --f-mono:    'DM Mono', monospace;
}
```

Each kit has its own font families. See `02-typographic-kits.md` for which variables to set per kit.

---

## 6. Adapting the palette

Each kit's suggested palette is a starting point. If user has own brand colors:

```python
# Brand has corporate blue
PALETTE = {
    'black': '#0F1419',         # adapt to corporate tone if wanted
    'cream': '#F1F5F9',         # keep neutral
    'accent': '#0066FF',        # ← brand color
    'neon': '#00D4FF',          # secondary or highlight
}
```

Apply palette directly to CSS variables, no other changes.

---

## 7. Visual quality checklist

Before delivering HTML, verify:

- [ ] Typefaces from chosen kit (NEVER mix kits without reason)
- [ ] Correct weights per kit metrics (some are single-weight only)
- [ ] `text-align: left` explicit on all heroes
- [ ] Color contrast: 7:1 minimum between bg and main text
- [ ] Safe zones: no critical text within 60px of edge
- [ ] Slide nums present and consistent (`NN / 10`)
- [ ] Logo present in footer (except S3 + S8 which are 'breathers')
- [ ] Mono tag at top
- [ ] Ghost number on numbered slides
- [ ] Vignette applied if photo
- [ ] No elements cut by edges
- [ ] Embedded fonts in base64 (verify HTML > 400KB)

---

## 8. Troubleshooting

| Problem | Cause | Fix |
|---|---|---|
| Text looks "fake bold" | Font weight doesn't exist in kit | Verify available weights in `02-typographic-kits.md` |
| Different fonts in HTML vs PNG | Embedded fonts didn't load | Verify you loaded the correct kit's CSS file |
| Text cut at edges | No safe zone | Apply `padding: var(--safe)` |
| Pixelated image | Missing device_scale_factor | `device_scale_factor=2` in Playwright |
| Download button appears in PNG | Not hidden before capture | `page.evaluate("document.querySelector('.dl-bar').style.display='none'")` |
| Fonts don't appear | Missing `document.fonts.ready` | Add wait + 2500ms timeout |
