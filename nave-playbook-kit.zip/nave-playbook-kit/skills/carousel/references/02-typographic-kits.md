# Reference 02 — Typographic Kits

> 8 pre-curated typographic systems for different brand types.

## Why pre-curated kits

Picking typefaces is the HARDEST thing for intermediate users. There are 1500+ Google Fonts and mixing them wrong ruins any design. So we curated 8 kits that DO work together.

Each kit has:
- **Display** (hero titles) — the "star" font that gives personality
- **Body** (body text) — the readable font for descriptions
- **Mono** (UI/data) — the technical font for editorial details

The 3 fonts in each kit are **already paired and tested**. Don't mix between kits without a very clear reason.

---

## Decision tree — which kit to pick

For each brand, follow this tree based on the archetype identified in `01-brand-and-voice.md`:

| If archetype is... | Recommended kit | Alternative |
|---|---|---|
| Sage | KIT_04 SERIF CLASSIC | KIT_01 EDITORIAL |
| Lover | KIT_01 EDITORIAL | KIT_04 SERIF CLASSIC |
| Magician | KIT_01 EDITORIAL | KIT_08 Y2K |
| Hero | KIT_03 BRUTALIST | KIT_02 MODERN CLEAN |
| Outlaw | KIT_03 BRUTALIST | KIT_08 Y2K |
| Explorer | KIT_03 BRUTALIST | KIT_02 MODERN CLEAN |
| Ruler | KIT_06 CORPORATE TECH | KIT_04 SERIF CLASSIC |
| Innocent | KIT_07 WARMTH | KIT_02 MODERN CLEAN |
| Caregiver | KIT_07 WARMTH | KIT_05 PLAYFUL |
| Everyman | KIT_05 PLAYFUL | KIT_07 WARMTH |
| Jester | KIT_05 PLAYFUL | KIT_08 Y2K |
| Creator | KIT_05 PLAYFUL | KIT_01 EDITORIAL |

When recommending: *"Based on your X archetype, I recommend KIT [N] [NAME] because [1-line why]. As an alternative, KIT [M] [NAME] also works."*

---

## KIT 01 — EDITORIAL

**Philosophy:** Sophisticated. For premium, fashion, lifestyle, branding studios.
**Mood:** Elegant, refined, magazine-style
**Brands that feel like this:** Vogue, Standards Manual, Order, Gentlewoman

### Fonts

| Family | Role | Available weights |
|---|---|---|
| **Anton** | display | 400 normal |
| **Instrument Serif** | serif-italic | 400 italic |
| **Inter** | body | 400, 500, 600, 700 |
| **JetBrains Mono** | mono | 500, 600 |

### Suggested palette

```css
:root {
  --black: #0A0A0A;
  --cream: #F2EBDD;
  --accent: #E94822;
  --neon: #E8FF00;
}
```

### Use when
- Premium or luxury brands
- Branding studios and creative agencies
- Lifestyle, fashion, hospitality
- You want a 'fashion magazine' feel

### Technical setup

Embedded fonts CSS at `assets/kits_tipograficos/kit_01_editorial/fonts_embedded.css`. Load it:

1. Open the file, copy ALL contents
2. Paste inside `<style id="embedded-fonts">...</style>` at top of `<head>`
3. Define CSS variables:

```css
:root {
  --f-display: 'Anton', sans-serif;
  --f-serif: 'Instrument Serif', serif;
  --f-body: 'Inter', system-ui, sans-serif;
  --f-mono: 'JetBrains Mono', monospace;
}
```

---

## KIT 02 — MODERN CLEAN

**Philosophy:** Minimalist contemporary. For SaaS, agencies, professionals.
**Mood:** Clean, neutral, professional without being corporate
**Brands that feel like this:** Linear, Notion, Vercel, Stripe

### Fonts

| Family | Role | Weights |
|---|---|---|
| **Space Grotesk** | display | 500, 600, 700 |
| **Inter** | body | 400, 500, 600, 700 |
| **IBM Plex Mono** | mono | 400, 500 |

### Palette

```css
:root {
  --black: #111111;
  --cream: #F5F5F0;
  --accent: #5B5BFF;
  --neon: #C5FF45;
}
```

### Use when
- SaaS, digital products, tech
- Modern agencies and consultancies
- Professional brands wanting to avoid corporate feel
- Visual cleanliness matters more than personality

### Variables
```css
:root {
  --f-display: 'Space Grotesk', sans-serif;
  --f-body: 'Inter', system-ui, sans-serif;
  --f-mono: 'IBM Plex Mono', monospace;
}
```

---

## KIT 03 — BRUTALIST

**Philosophy:** Raw, rebellious. For alternative brands, music, underground design.
**Mood:** Industrial, anti-establishment, raw
**Brands that feel like this:** KANYE merch, Berghain, brutalist websites

### Fonts

| Family | Role | Weights |
|---|---|---|
| **Archivo** | display | 800, 900 |
| **Archivo** | body | 400, 500, 600 |
| **Space Mono** | mono | 400, 700 |

### Palette

```css
:root {
  --black: #000000;
  --cream: #EFEFEF;
  --accent: #FF3B00;
  --neon: #00FF00;
}
```

### Use when
- Alternative, music, underground art
- Disruptive youth products
- You want impact and to break conventions
- Streetwear, alternative gaming, counterculture events

### Variables
```css
:root {
  --f-display: 'Archivo', sans-serif;
  --f-body: 'Archivo', system-ui, sans-serif;
  --f-mono: 'Space Mono', monospace;
}
```

---

## KIT 04 — SERIF CLASSIC

**Philosophy:** Timeless, literary. For educational brands, books, intellectual consulting.
**Mood:** Sophisticated-classic, hardcover-book, authority
**Brands that feel like this:** NY Times, Harvard, The Atlantic, editorial publishing

### Fonts

| Family | Role | Weights |
|---|---|---|
| **Playfair Display** | display | 400, 700, 900 |
| **EB Garamond** | body | 400, 500, 600, 700 |
| **Courier Prime** | mono | 400, 700 |

### Palette

```css
:root {
  --black: #1A1411;
  --cream: #F5EFE3;
  --accent: #8B1A1A;
  --neon: #D4A82B;
}
```

### Use when
- Educational and editorial brands
- Intellectual consulting, academia
- Brands with historical or intellectual authority
- 'Hardcover book' or 'NY Times' feel

### Variables
```css
:root {
  --f-display: 'Playfair Display', serif;
  --f-body: 'EB Garamond', system-ui, serif;
  --f-mono: 'Courier Prime', monospace;
}
```

---

## KIT 05 — PLAYFUL

**Philosophy:** Fun, joyful. For creators, food, kids, fun DTC brands.
**Mood:** Friendly, accessible, with personality
**Brands that feel like this:** Glossier, Liquid Death, Oatly, Aesop

### Fonts

| Family | Role | Weights |
|---|---|---|
| **Syne** | display | 500, 600, 700, 800 |
| **Manrope** | body | 400, 500, 600, 700 |
| **DM Mono** | mono | 400, 500 |

### Palette

```css
:root {
  --black: #1F1A2E;
  --cream: #FFF4E0;
  --accent: #FF6B9D;
  --neon: #FFE45E;
}
```

### Use when
- Products for young adults (25-40)
- DTC brands with personality
- Food, joyful wellness, fun digital products
- Fun without losing professionalism

### Variables
```css
:root {
  --f-display: 'Syne', sans-serif;
  --f-body: 'Manrope', system-ui, sans-serif;
  --f-mono: 'DM Mono', monospace;
}
```

---

## KIT 06 — CORPORATE TECH

**Philosophy:** Trustworthy, technical. For fintech, B2B SaaS, tech consultancies.
**Mood:** Trustworthy, solid, technically competent
**Brands that feel like this:** IBM, Salesforce, Rippling, modern enterprise

### Fonts

| Family | Role | Weights |
|---|---|---|
| **Red Hat Display** | display | 500, 600, 700, 900 |
| **Red Hat Display** | body | 400, 500 |
| **Red Hat Mono** | mono | 400, 500 |

### Palette

```css
:root {
  --black: #0F1419;
  --cream: #F1F5F9;
  --accent: #0066FF;
  --neon: #00D4FF;
}
```

### Use when
- B2B SaaS, fintech, enterprise software
- Tech consultancies, integrators
- Brands needing to convey technical solidity
- Trust matters more than differentiation

### Variables
```css
:root {
  --f-display: 'Red Hat Display', sans-serif;
  --f-body: 'Red Hat Display', system-ui, sans-serif;
  --f-mono: 'Red Hat Mono', monospace;
}
```

---

## KIT 07 — WARMTH

**Philosophy:** Warm, human. For wellness, therapy, conscious brands.
**Mood:** Welcoming, earthy, calming
**Brands that feel like this:** Bookshop.org, slow living, wellness brands

### Fonts

| Family | Role | Weights |
|---|---|---|
| **Fraunces** | display | 400, 600, 700, 900 |
| **Karla** | body | 400, 500, 600, 700 |
| **DM Mono** | mono | 400, 500 |

### Palette

```css
:root {
  --black: #2A1F18;
  --cream: #F5EAD7;
  --accent: #C77D2C;
  --neon: #9CB071;
}
```

### Use when
- Wellness, therapy, coaching, conscious brands
- Artisanal products and slow living
- Warm feminine brands (without falling into 'feminine' cliché)
- You want to evoke calm and closeness

### Variables
```css
:root {
  --f-display: 'Fraunces', serif;
  --f-body: 'Karla', system-ui, sans-serif;
  --f-mono: 'DM Mono', monospace;
}
```

---

## KIT 08 — Y2K NEO-RETRO

**Philosophy:** Nostalgic, hyper-modern. For creative brands, music, youth fashion.
**Mood:** Retro-futurist, glitchy, gen-z
**Brands that feel like this:** Studio FX Brasil, Frank Ocean Blonded, gaming aesthetics

### Fonts

| Family | Role | Weights |
|---|---|---|
| **Major Mono Display** | display | 400 |
| **Work Sans** | body | 400, 500, 600, 700 |
| **Space Mono** | mono | 400, 700 |

### Palette

```css
:root {
  --black: #0D0D1A;
  --cream: #F0E8FF;
  --accent: #FF00AA;
  --neon: #00FFAA;
}
```

### Use when
- Creative brands, music, youth fashion
- Digital products with gen-z audience
- Events, festivals, gaming
- 'Retro-futurist nostalgic' feel

### Variables
```css
:root {
  --f-display: 'Major Mono Display', monospace;
  --f-body: 'Work Sans', system-ui, sans-serif;
  --f-mono: 'Space Mono', monospace;
}
```

---

## Adapting the palette

Suggested palettes are starting points. Adapt to user's actual brand:

### If user already has brand colors
1. Replace `--accent` with the brand's main color
2. Keep `--black` and `--cream` similar (functional, not brand)
3. Adjust `--neon` only if user has a brand secondary color

### If user wants "warmer"
- Black: add brown tone (e.g., `#1A1411` instead of `#0A0A0A`)
- Cream: more yellow (e.g., `#F5EAD7` instead of `#F2EBDD`)

### If user wants "cooler"
- Black: add blue tone (e.g., `#0A0F1A`)
- Cream: more neutral white (e.g., `#F5F5F0`)

### If user wants "more feminine"
- Accent: pink, coral, mauve
- Consider less extreme contrast

### If user wants "more serious"
- Reduce accent saturation
- Burgundy instead of red
- Forest green instead of lime

### RULE: Never apply palette without preview proposal

Before applying, show:

```
ADJUSTED PALETTE:
- Main background: [hex] [visible color: ⬛]
- Breather background: [hex] [visible color: 🟦]
- Accent: [hex] [visible color: 🟧]
- Highlight: [hex] [visible color: 🟨]

Like it, or adjust any color?
```

---

## Don't mix kits

**Valid exception:** Only if user has clear reason, e.g., "I want Editorial body but Brutalist display."

**Why almost always a bad idea:** Each kit's typefaces were chosen as a pair by their metrics (x-height, weight, contrast). Mixing across kits without criteria can break visual harmony.

**If user insists:** Warn them (1 line: "heads up, this mix may not work visually"), do it, and show preview before committing.
