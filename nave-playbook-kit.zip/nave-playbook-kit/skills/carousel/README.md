# Carousel Skill

> Brand-led Instagram carousel builder. Discovers your brand once, ships polished carousels every time after.

---

## What this ships

For each carousel run:
- **Standalone HTML** with base64-embedded fonts (no internet needed at view time)
- **10 retina 2x PNGs** (1080×1350 source, 2160×2700 final)
- **ZIP** of the 10 PNGs ready to drag into Instagram
- **Caption** with hook + setup + bridge + CTA + hashtags + lead magnet block
- **Saved brand profile** so the next carousel takes 30-40 min instead of 50-65

---

## Quick start

In Claude Code:

```
"Make me a carousel for [brand] about [topic]"
```

Or invoke explicitly:

```
"Use the carousel skill to make me a carousel about X"
```

The skill walks 5 phases — Discover → Plan → Copy → Build → Ship.

For your second carousel and beyond:

```
@reuse my-brand-slug
```

Skips brand discovery, jumps straight to brief + big idea.

---

## The 8 typographic kits

| Kit | Mood | For |
|---|---|---|
| 01 EDITORIAL | Sophisticated, magazine | Premium, fashion, lifestyle, branding studios |
| 02 MODERN CLEAN | Minimalist contemporary | SaaS, agencies, professionals |
| 03 BRUTALIST | Raw, rebellious | Music, underground art, streetwear |
| 04 SERIF CLASSIC | Timeless, literary | Educational, intellectual consulting, editorial |
| 05 PLAYFUL | Fun, joyful | DTC fun, food, joyful wellness |
| 06 CORPORATE TECH | Trustworthy, technical | B2B SaaS, fintech, enterprise |
| 07 WARMTH | Warm, human | Wellness, therapy, conscious brands |
| 08 Y2K NEO-RETRO | Retro-futurist, gen-z | Music, youth fashion, gaming |

The skill recommends a kit based on your brand archetype + always offers 1-2 alternatives. You pick.

---

## Conversation shortcuts

| Shortcut | What it does |
|---|---|
| `@reuse {brand-slug}` | Skip Phase 1, use saved brand profile |
| `@brief` | "Here's my brief, run Phase 2" |
| `@bigidea A` | Pick Big Idea proposal A |
| `@copy` | Generate full copy now |
| `@build` | Render HTML + PNGs now |
| `@express` | Fast mode (~25-35 min total) |
| `@iterate "[changes]"` | Apply changes to delivered output |
| `@beginner` | Explain everything slowly |
| `@technical` | Advanced detail |

---

## Generating missing kit fonts (one-time)

The skill ships with `kit_08_y2k` pre-embedded. To activate the other 7 kits:

```bash
cd .claude/skills/carousel/assets
pip install requests   # if not installed
python generate_kit_fonts.py all
```

Downloads fonts from Google Fonts and base64-embeds them. Total size after generation: ~2 MB across 8 kits.

Or ask Claude in chat: *"Generate embedded fonts for kit_07_warmth using Google Fonts."* — Claude can do it via Code Execution.

---

## Folder layout

```
.claude/skills/carousel/
├── SKILL.md                              ← Main skill file (Claude reads this first)
├── README.md                             ← This file
├── references/
│   ├── 01-brand-and-voice.md             ← Brand discovery + 12 archetypes + voice + 5 hooks + 3 caption templates
│   ├── 02-typographic-kits.md            ← 8 kits + decision tree + palette adaptation
│   ├── 03-frameworks-structures.md       ← 6 carousel types + 6 narrative frameworks + 7 slide structures
│   └── 04-html-template.md               ← CSS + slide snippets + Python build script + Playwright render
└── assets/
    ├── generate_kit_fonts.py             ← Script to generate the 7 missing kits
    └── kits_tipograficos/
        └── kit_08_y2k/
            └── fonts_embedded.css        ← ✅ Ships ready
```

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Claude proposes typefaces outside the 8 kits | Remind: *"use only the 8 kits from references/02"* |
| HTML weighs <100KB | Embedded fonts didn't load — verify the chosen kit's `fonts_embedded.css` exists |
| PNGs come out pixelated | Playwright `device_scale_factor` must be 2 |
| Some words missing from copy | Validate against your blacklist — re-state your blacklist explicitly |
| Claude imposes a tone that's not yours | Be explicit in Phase 1: formality + region + emoji policy |
| `kit_X/fonts_embedded.css not found` | Run `python assets/generate_kit_fonts.py kit_X` |
| Caption uses "innovate" / "leverage" / "elevate" | Add to your blacklist — re-run with explicit blacklist |
| Claude skips brand discovery | You probably said `@express` — explicitly request phase-by-phase |

---

## Output structure

Each carousel run produces:

```
output/carousels/{brand-slug}-{topic-slug}/
├── {slug}.html                         ← open in browser, click ⬇ to download PNGs
├── slides/                             ← 10 retina 2x PNGs
├── {slug}-10-slides.zip                ← ready to drag into Instagram
├── preview-montage.png                 ← 2x5 grid validation
└── caption.md                          ← copy-paste ready
```

Plus, persisted across runs:

```
output/brand-profiles/
└── {brand-slug}.json                   ← reuse via @reuse
```

---

## Use cases

| Situation | Approach |
|---|---|
| First carousel ever | Full 5-phase walk (~50-65 min) |
| Second + carousel for same brand | `@reuse {brand-slug}` (~30-40 min) |
| Special-event variant (different palette, same brand) | `@reuse` + override palette in Phase 2 |
| Plan a content month (5 carousels) | Phase 1 once → Phase 2 quick brief × 5 → batch produce |
| Re-skin an old carousel | Skip Phases 1-3, only redo Phase 4 (build) with new palette |

---

## Limits

| Does | Doesn't |
|---|---|
| Brand-led carousel design | Reels / short video |
| 8-12 slide systems | Photorealistic AI images |
| Standalone offline HTML | Logo design |
| Caption + hashtag generation | Direct Instagram upload (manual) |
| Brand profile reuse | Auto-track metrics |

For things outside the scope, the skill redirects to a sibling skill or different tool.
