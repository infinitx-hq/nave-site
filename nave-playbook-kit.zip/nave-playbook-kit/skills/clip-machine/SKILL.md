---
name: clip-machine
description: "Full clip extraction pipeline — download source video, transcribe with word-level timing, identify the strongest moments, cut precise clips, and reframe to vertical format. Produces platform-ready shorts from long-form content. Use when the creator gives a video URL or file and wants clips pulled from it."
argument-hint: [video_file_path]
allowed-tools:
  - Bash(python:*)
  - Bash(ffmpeg:*)
  - Bash(ffprobe:*)
  - Bash(pip:*)
  - Bash(curl:*)
  - Bash(jq:*)
  - Bash(bash:*)
  - Read
  - Write
metadata:
  category: video-production
  version: 2.0
  phase: 1
---

# Clip Machine

Full clip pipeline: select the best moments from long-form video, reframe 16:9 to 9:16 with face-tracking, and output platform-ready shorts.

## What's Inside

| Component | Location | Purpose |
|-----------|----------|---------|
| **SKILL.md** (this file) | `skills/clip-machine/` | How to run the pipeline |
| **Face-tracking engine** | `skills/clip-machine/clip_extractor/` | Python reframe engine (MediaPipe BlazeFace) |
| **Video download** | `skills/video-download/SKILL.md` | yt-dlp + YouTube cookies; fall back to creator upload if blocked |
| **Config** | `skills/clip-machine/clip_extractor/config.yaml` | Tuning parameters |

### Related skills + agents (the pipeline is RUN BY HAND — invoke each in order)

There is **no clip-machine workflow** — you drive the process by invoking these skills and agents
yourself, in sequence, per clip. The `clip-editor` agent owns the whole Edit stage (steps 7-9).

| Step | Skill / agent | Role |
|------|---------------|------|
| **video-download** | `skills/video-download/SKILL.md` | Download source (yt-dlp + cookies; creator-upload fallback) |
| **extracting-transcripts** | `skills/extracting-transcripts/SKILL.md` | Word-level timestamps (AAI Universal-3 Pro + custom-vocab) |
| **clip-selection** | `skills/clip-selection/SKILL.md` | Rank transcript → best clip moments |
| **clip-research-brief** | `skills/clip-research-brief/SKILL.md` | Per-clip research/edit brief (tool glossary, hook, scenes) |
| **clip-extractor** | `skills/clip-extractor/SKILL.md` | Classify per-segment + reframe 16:9 → 9:16 (Mode A/B) |
| **clip-hook-first** | `skills/clip-hook-first/SKILL.md` | Restructure: pull the hook to the front (re-transcribe after) |
| **creative-director** | `skills/creative-director/SKILL.md` | Editorial brief + the 2-3 scene-takeover archetypes |
| **clip-editor** (agent) | `agents/clip-editor.md` | Owns the EDIT: brand-resolve + assemble EDL + render + QA |
| **clip-edit-logos** | `skills/clip-edit-logos/SKILL.md` | Fetch clean tool logos for callouts (the asset-fetcher capability) |
| **hyperframes-edit** | `skills/hyperframes-edit/SKILL.md` | The auto-EDL editor doctrine (pipeline-clip-pro) the clip-editor runs (FAST/DRAFT path) |
| **hyperframes-clip-edit** ⭐ | `skills/hyperframes-clip-edit/PROCESS.md` | **PREMIUM DEFAULT** (SEAS ≥80 / hook-grade): a hand-authored Hyperframes composition + per-event audio mix, built by its own 4 agents. Replaces the auto-EDL for premium clips (Enrique-approved on the comment-to-DM set, 2026-06). |

The auto-EDL specialists — `clip-editor` (orchestrator), `scene-director`, `move-designer`,
`sound-designer`, `asset-fetcher` — are standalone agents in `.claude/agents/`. The clip-editor
coordinates the other three when you hand it a reframed clip; or invoke each directly for one layer.

**⭐ PREMIUM-QUALITY GATE (the followed way — 2026-06).** At the EDIT stage, read the clip's SEAS `score`
(from `clip-selection`). If **≥ 80 (hook-grade)** — the default for keeper clips — edit it with
**`hyperframes-clip-edit`** (`skills/hyperframes-clip-edit/PROCESS.md`), NOT the auto-EDL. That skill's own
loop (scene-planner → composition-author → sound-designer → critic) hand-authors a Hyperframes composition:
frame-0 cover (the auto-grabbed poster), one deliberate overlay per beat, the REAL screen shown crisp (never
blurred/recreated), clean cover + outro (no transition music), word-synced captions, −14 LUFS. The auto-EDL
path above (clip-editor + EDL specialists + pipeline-clip-pro) is the **fast/draft** path for lower-scored
clips. Read `skills/hyperframes-clip-edit/PROCESS.md` first — it is the canonical end-to-end doc.

## Full Pipeline (run by hand, skill-by-skill)

```
SOURCE (url|file)  [you decide: which clips · hook on/off · scope]
  → video-download                 (yt-dlp → source.mp4 + source.metadata.json)
  → extracting-transcripts         (AAI Universal-3 Pro + CREATOR custom_spelling + keyterms_prompt
                                     — word_boost 400s; see transcription-config.md SOT)
  → concept + brand-profile        (deep-read transcript + <scope>/content-production/brand-profile.md
                                     → concept brief that biases selection toward the brand)
  → clip-selection                 (rank clips with anchor-fuzzy matching → clip_definitions.json;
                                     NO layout guess here — clip-extractor classifies per-segment)
  → clip-research-brief            (per clip → tool glossary + hook + scene ideas; fixes tool spelling)
  → clip-extractor CLASSIFY+reframe(DETERMINISTIC per-segment source-type map → clip-NN-source-map.json;
                                     pass-through ONLY if every segment is graphic/screen-share;
                                     talking-head segments ALWAYS reframe → emit clip-NN-reframe.json
                                     = clipLayout, segments[sourceType], openingThumbnail, captionBand,
                                     burnedInCaptionsDetected, tailTrim. [senses pre/post REMOVED])
  → re-transcribe BODY             (AAI on the reframed body → clip-NN-reframed.json PLANNING wordmap)
  → creative-director              (per clip → editorial brief: HOOK-conditional hookIntro vs
                                     coldOpenHook, coverCard, popOuts, scene-takeovers, captionBand)
  → clip-hook-first + re-tx FINAL  (if HOOK on: prepend hookIntro → clip-NN-final.mp4; re-transcribe it
                                     → clip-NN-final.json AUTHORITATIVE caption wordmap matching the cut)
  → clip-editor (agent)            (RESOLVE BRAND from scope brand-profile → assemble EDL → run the
                                     pipeline-clip-pro chain: de-stutter → gen_edl density-floor →
                                     build.mjs token+native-SFX → hyperframes render 0.6.56 → QA vs
                                     showcase-pro. Cover in-comp frame 0, NO ffmpeg mux.)
  → schedule (STAGE-AND-WAIT)      (write per-clip scheduler-contract README + order; NOT posted —
                                     awaits operator go, then content-scheduler / social-media-publishing)
```

### Per-clip contract (what each step reads/writes — all paths relative to the piece dir)

> v3 design: [`REDESIGN-v3-SPEC.md`](REDESIGN-v3-SPEC.md). **video-senses (pre + post) is REMOVED** —
> its two real catches are migrated into Reframe (`clip-NN-reframe.json.burnedInCaptionsDetected` =
> caption-truth; `.tailTrim` = lead/tail bleed). Layout is decided per-segment by the deterministic
> `clip_extractor classify`, not a senses pre-scan.

| Step | Reads | Writes | SOT doc |
|---|---|---|---|
| download | URL/file | `source/source.mp4`, `source/source.metadata.json` | `video-download/SKILL.md` |
| transcribe | `source.mp4` + `<scope>/memory/custom-vocab.json` | `transcript/{json,.srt,.txt}` (**`keyterms_prompt`**, not word_boost) | `transcription-config.md` |
| concept | `transcript.txt`, brand-profile.md | `clips/concept-brief.md` | (LLM) |
| select | `transcript.json`, `concept-brief.md` | `clips/clip_definitions.json` | `clip-selection/SKILL.md` |
| research-brief | clip range + transcript | `clips/clip-NN-brief.json` (tool glossary, hook, scenes) | `clip-research-brief/SKILL.md` |
| classify + reframe | `source.mp4`, clip ranges | `clips/clip-NN-source-map.json`, reframed assets, **`clips/clip-NN-reframe.json`** | `clip-extractor/SKILL.md` + REDESIGN-v3-SPEC §A/§B |
| re-transcribe BODY | reframed body | `clips/clip-NN-reframed.json` (PLANNING wordmap) | `transcription-config.md` |
| creative-director | reframe.json + body wordmap + brand-profile + treatment-library | `clips/editorial-briefs/clip-NN.json` (hookIntro/coldOpenHook, coverCard, popOuts, scene-takeovers) | `creative-director/SKILL.md` |
| hook-first + re-tx FINAL | hookIntro + reframed deliverable | `clips/clip-NN/clip-NN-final.mp4`, **`clips/clip-NN-final.json`** (AUTHORITATIVE caption wordmap) | `clip-hook-first/SKILL.md` |
| **edit (clip-editor agent)** | brief + reframe.json + final.mp4 + final.json + scope brand-profile + global SFX | `clips/clip-NN-edit/work/edl.json`, `clips/clip-NN-edit/clip-NN-edited.mp4` | `clip-editor` agent + `hyperframes-edit/SKILL.md` |
| schedule (STAGE-AND-WAIT) | rendered clips | per-clip sibling piece `README.md` (`stage:ready` + `keeper_path` + `platform_drafts.*` + `order`/`slot_offset`) — **NOT posted; awaits operator go** | `content-scheduler.md` |

### Why custom-vocab transcription matters (read before invoking)

Raw AAI mis-spells branded tools — *Hicksfield* for **Higgsfield**, *Cernio/Sernio* for **Zernio**, *CDNs/CDance* for **Seedance**, *Hyper frames* / inconsistent for **Hyperframes**, *11 labs* for **ElevenLabs**. Without `custom_spelling` + `keyterms_prompt` (the vocab file's `word_boost` list is passed as `keyterms_prompt` — bare `word_boost` 400s on universal-3-pro; loaded from `data/tenants/<slug>/memory/custom-vocab.json`), EVERY clip's captions, metadata, and posted text say the WRONG tool name across every platform. Fix it at transcription time, not post-hoc. See `extracting-transcripts/SKILL.md § Custom vocabulary` for the contract.

### One-shot reframe (just want a 9:16 from a range, no edit)

```
VIDEO URL → video-download → transcript → clip-selection → clip-extractor reframe
```

The Python `clip_extractor` package below is Mode B. Mode A (raw ffmpeg dual-extraction, frame-locked) lives in the `clip-extractor` skill and is the default for split compositions. **Default to Mode A** unless source is a full-frame talking head with motion exceeding a static crop window.

## Reframe quick-reference (the per-clip core)

| Phase | Command | Duration |
|-------|---------|----------|
| **0 · Context** | `ffprobe` source, confirm deps, read config | Instant |
| **1 · Extract** *(optional)* | `python -m clip_extractor reframe --start S --end E` | <10s |
| **2 · Reframe** | detect → smooth → crop_path.json → render | 1–3× realtime |
| **3 · Output** | Report face %, confidence, path. Hand the reframed clip to the **clip-editor** agent. | Instant |

For batch runs on long podcasts, go straight to the "Batch Mode & Long Sources — Read First" section below.

## Reframe Engine

Local Python pipeline with intelligent layout detection and face-tracking reframe. CapCut-level auto-reframe quality, fully local, zero cost per clip.

### MediaPipe authority model (phantom-face rejection)

BlazeFace (the primary face detector) occasionally false-positives on torso / shoulder regions during the unstable-exposure window of a clip (first 1-2 seconds). Previously those phantoms poisoned the Kalman / deadzone initial state and the crop chased them to the bottom of the frame. The 9x16 single-person path now rejects phantoms through three layered gates:

1. **MouthLandmarker validation** — before a bbox enters smoothing, MediaPipe FaceLandmarker is consulted. If the bbox is ≥ `crop.mouth_centering.validation_threshold_pct` of frame width (default 0.15) but MediaPipe returns no lip landmarks, the bbox is rejected as a phantom.
2. **Anatomical sanity gate** — any bbox whose center y exceeds `detection.face.anatomy_y_max` (default 0.80) is rejected outright. Real talking-head faces virtually never land there.
3. **Startup median correction** — after the main loop, the first `smoothing.startup.window_keyframes` (default 7) keyframes are compared against their own median crop_y. Outliers beyond `smoothing.startup.tolerance_pct` (default 15% of source height) are snapped to the median.

All thresholds live in `config.yaml` with rationale next to each. The split-screen path already had this redundancy (per-frame DNN + per-speaker Kalman + median mouth sampling) — these gates bring the 9x16 single-person path to parity.

## Layout Modes

The reframer auto-detects the appropriate layout based on video content:

| Mode | Trigger | Top Half | Bottom Half | Use Case |
|------|---------|----------|-------------|----------|
| **9x16 face-track** | Face detection ≥ 15% | — (single crop) | — (single crop) | Talking head, vlog, direct-to-camera |
| **1x1 face-track** | `--format 1x1` | — (square crop) | — (square crop) | Instagram feed, LinkedIn |
| **Split: multi-face** | `--format split` | Full 16:9 source | Side-by-side face close-ups | Zoom calls, interviews, podcasts |
| **Split: dynamic podcast** | `--format split` + mixed layouts | Layout-aware per-segment | Layout-aware per-segment | Podcasts, interviews with camera switching |
| **Split: screen-share** | Auto (face < 15%, webcam found) | Full screen share | Webcam face enlarged | Tutorials, demos, screen recordings |

### Auto-Detection Flow

```
reframe --format 9x16
  → analyze (face detection, pose, saliency)
  → face_detected_pct ≥ 15%? → standard 9x16 face-track render
  → face_detected_pct < 15%? → scan 4 corners for webcam overlay
      → webcam found? → split-screen render (screen-share mode)
      → no webcam?   → fallback to standard render (pose-guided)
```

### Screen-Share Split Layout (Auto-Detected)

For screen recordings with a small webcam overlay (OBS, Zoom share, etc.):

```
┌─────────────────┐
│                  │
│  Full screen     │  ← Top 50%: entire 16:9 frame (screen content)
│  share content   │
│                  │
├─────────────────┤
│                  │
│   Face enlarged  │  ← Bottom 50%: webcam face cropped and enlarged
│   from webcam    │
│                  │
└─────────────────┘
     1080x1920
```

**How it works:**
1. Standard analysis detects very low face % (webcam face is tiny in the full frame)
2. Corner scanner (`_find_webcam_overlay`) crops each corner region, upscales, runs DNN face detection
3. The corner with consistent face detections = webcam overlay position
4. Split renderer uses the detected position for the bottom-half face crop
5. MediaPipe face landmarker fine-tunes vertical centering

**Config:** `screenshare` section in `config.yaml`

### Dynamic Podcast Layout Detection (Phase 6)

For podcasts and interviews where the source camera **switches between gallery view and close-up**, the reframer auto-detects layout changes and renders each segment appropriately.

**How it works:**
1. During `analyze()`, face data (`all_faces`) is stored per keyframe via OpenCV DNN
2. `layout_detector.py` classifies each keyframe by **face size** (primary) + **spatial spread** (secondary):
   - `SPLIT_SCREEN`: 2+ faces, median face width < 0.06, horizontal spread > 0.15
   - `CLOSE_UP`: faces with median width > 0.04, horizontal spread < 0.12
3. Majority-vote smoothing (15-keyframe window) eliminates single-frame noise
4. Short segments (< 1.0s) are merged into neighbors
5. **Zero extra video scan** — reuses existing detection data

**Rendering per segment:**
- **Split-screen segments**: Per-frame DNN face detection, per-speaker Kalman smoothing, smart cropping (each speaker fills their half, no overlap), mouth-centered vertically
- **Close-up segments**: Standard 9:16 face-tracking crop from keyframes
- **Transitions**: 5-frame alpha crossfade between layout modes

**Anti-jitter measures:**
- Kalman filter: `process_noise=0.001`, `measurement_noise=0.15` (trusts predictions 150x more than raw detections)
- 1.2% deadzone: ignores face movements smaller than 1.2% of frame width
- Speaker identity tracking: nearest-neighbor matching prevents speaker swaps

**Config:** `split_screen.dynamic_layout` section in `config.yaml`

```yaml
dynamic_layout:
  enabled: true
  face_size_threshold: 0.06      # Faces below this = gallery/split
  spatial_spread_threshold: 0.15  # Min H-distance between faces for split
  min_segment_duration: 1.0      # Merge segments shorter than this (seconds)
  smoothing_window: 15           # Majority vote window (keyframes)
  crossfade_frames: 5            # Transition crossfade duration
  mouth_centering: true          # Use MediaPipe mouth landmarks
```

## Source scene-type → layout treatment (READ FIRST)

A long-form source — podcast, interview, lecture, vlog, demo — is **not one scene**. It's a sequence of scene-types, each with a canonical short-form layout treatment. The reframer's job is to classify per-segment and dispatch the right layout. Forcing a single `--format 9x16` over the whole source produces visible quality regressions on every scene-type that isn't single-speaker close-up.

This matrix is the policy. The dynamic-layout detector implements it (or aims to); the rest of the document tunes the implementation. **When a clip looks wrong, find the scene-type below and verify the layout matches.**

> ### ⛔ FIRST gate: is this a RAW source or a FINISHED edit?
>
> This engine's face-track reframe is for **raw / lightly-edited talking-head sources**. If the
> source is a **finished, graphics-dense edit** — full-screen graphic cards, split panels with
> on-screen labels, screen-share + webcam, **burned-in captions** — face-tracking is the WRONG
> tool: it crops to the face and throws away the graphics that carry the message, and fragments
> the existing captions. (Verified 2026-05-28 on a finished YouTube edit: clip-2's "Four
> Specialists" graphic was destroyed by the crop.)
>
> **For a finished/graphics source, do NOT reframe here.** Rebuild the moment as a portrait
> HyperFrames composition (`hyperframes-edit` § Native render contract), re-laying the graphic
> vertically with fresh captions. To preserve a finished 16:9 master intact, use the **native
> letterbox-self-blur = two HyperFrames video tracks** (a blurred `object-fit:cover` copy under a
> sharp `object-fit:contain` copy, same dense-keyframe source) — CSS only, NOT an ffmpeg `gblur`
> pre-pass. Face-track only what's genuinely raw talking-head.

### The 10 source scene-types and their canonical treatments

| Scene-type | Detection signal | Canonical 9:16 layout | Notes |
|---|---|---|---|
| **single-speaker close-up** | 1 face, ≥15% frame width, stable position | `9x16` face-track | Default for talking-head; existing Kalman + deadzone handles head-bob jitter |
| **two-speaker wide-shot** | 2 faces visible together, similar size, > 50% segment duration | `letterbox-self-blur` | Original 16:9 centered as sharp band; blurred + dimmed self fills top+bottom. Preserves conversational composition, no face-cropping |
| **two-speaker gallery/stack** | 2 faces in fixed separate boxes (Riverside / Zoom) | `split` (vertical-stack) | Each face fills its half; per-speaker Kalman; speaker-id tracking prevents swaps |
| **speaker-switch within shot** | Face center swings > 30% frame width in ≤10 keyframes WITHOUT a scene cut | `letterbox-self-blur` (for the segment) | Position discontinuity is NOT detection noise — Kalman makes it worse. Don't chase, letterbox |
| **reaction shot** | 1 face full-frame during other speaker's narration | `9x16` face-track on the reactor | Common in 2-speaker podcasts; track the visible face, not the speaker |
| **screen-share / demo** | Face count < 15%, webcam overlay detected in a corner | `split` (screen-on-top + webcam-on-bottom) | Auto-detected today; existing implementation works |
| **B-roll / cutaway** | No face for >2s, source archetype is podcast/talking-head | `letterbox-self-blur` OR `9x16` center-crop on action | Preserves cinematographer composition; choose by salience map (faces present in B-roll → 9x16, none → letterbox) |
| **walking / movement shot** | 1 face but cx variance > 20% across segment | `letterbox-self-blur` OR widen face-track padding | Subject moving in frame — tight crop chases the walk; letterbox holds composition |
| **title-card / brand graphic** | Static frame, very low motion, no face, has on-screen text | `pass-through` (scale-to-fit, letterbox) | Don't reframe; preserve the design as authored |
| **audience / wide environment** | 3+ small faces, low individual face % each | `letterbox-self-blur` | Crowds, panels, live events — face-tracking on a tiny face produces tiny crops |

### Layout decisions are per-segment, not per-clip

A 60s podcast clip might contain four of these scene-types in sequence. The dynamic-layout detector (`Phase 6` above) classifies each segment and dispatches accordingly, with crossfades on layout switches. Forcing one `--format` for the whole clip is a fallback for short clips with one scene-type only.

### Detection noise vs. layout signal — the distinction that matters

The `smoothing.kalman.measurement_noise`, `deadzone.threshold_pct`, and `smoothing.rate_limit.max_velocity_px_per_frame` knobs handle one thing: **face-detection noise on a stable single-speaker shot** (head bobs, mic obscuring chin, side-profile confidence dips). Defaults handle this well; tune only if you see jitter on a clip that's clearly `single-speaker close-up` per the matrix above.

Everything else in the matrix is a **layout signal** — the truth-position genuinely changes between frames because the source camera moved, cut, or holds a wider composition than face-tracking can serve. Tuning smoothing on a layout-signal jitter just makes the chase slower; it never removes it. The fix is the row's canonical layout, not a config knob.

### Until `letterbox-self-blur` ships natively

Three rows above call for `letterbox-self-blur`. clip-machine doesn't support it yet (`--format` is `9x16 | 1x1 | split`). See `.agents/plans/pending/clip-machine-letterbox-self-blur-layout.md` for the implementation plan. Workarounds today:

1. **Use `--format split`** if the segment is two-speaker gallery or screen-share — the existing path covers those.
2. **Skip clip-machine for two-speaker-wide / speaker-switch / walking / B-roll segments** and let `hyperframes-edit` handle the layout in the Hyperframes composition itself (CSS positioning + the registry blocks).
3. **Per-clip layout override** in `clip_definitions.json` — for clips that are uniformly one scene-type, set `layout: split` (closest existing fallback) so the batch doesn't auto-9x16 a wide shot.

## Platform compatibility — Windows (READ if on Windows)

The `clip_extractor` Python engine was validated on macOS (M3) + your host (Linux). On Windows it
hits three failures with known workarounds (full detail in [[clip_extractor_windows_gotchas]]):

1. **`batch` multiprocessing crashes** — `ProcessPoolExecutor` (spawn) can't pickle the worker
   (`AttributeError: Can't get attribute '_reframe_one_clip'`). **Do NOT use `batch` on Windows.**
   Run one `reframe --start S --end E` per clip instead — no pool, fully reliable.
2. **`UnicodeEncodeError` on `≥`** — the engine prints `face ≥ 8%`; Windows cp1252 stdout can't
   encode it and crashes *after* analysis, before render. **Always set `PYTHONUTF8=1
   PYTHONIOENCODING=utf-8`** in the environment before invoking.
3. **libx264 pipe encode dies at frame 0** — `Generic error in an external library` / `frame= 0`.
   **Force NVENC** (GPU): copy `config.yaml`, set `use_nvenc: "force"`, pass `--config that.yaml`.
   `_detect_nvenc()` returns false even with an NVIDIA GPU present, so `auto` wrongly picks libx264.
   NVENC render is clean + faster. (`split_renderer`'s blur-fill path also `MemoryError`s on long
   clips — not yet fixed; prefer the finished-source → HyperFrames rebuild path above for
   screen-share/graphic clips rather than the split renderer.)

Canonical Windows single-clip invocation:

```bash
cd .claude/skills/clip-machine          # parent of the clip_extractor package (NOT inside it)
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8
python -m clip_extractor reframe --video SRC.mp4 --start 0.0 --end 64.9 \
  --output OUTDIR/ --format 9x16 --config nvenc-config.yaml
```

> A proper fix (Windows-aware NVENC auto-detect, UTF-8 stdout wrapper, serial-batch fallback,
> per-frame blur-fill free) is the real TODO — until then, the above three workarounds are required.

## Batch Mode & Long Sources — Read First

**`--format split` on long sources is the #1 undocumented hang in this pipeline.** Read this before you invoke the batch command on anything longer than 30 minutes.

### Render time — what to expect

| Source length | Format | CPU render | NVENC render |
|---|---|---|---|
| 45-180s clip | `9x16` | 1–2× realtime | 5–10× faster than CPU |
| 45-180s clip | `split` | 2–3× `9x16` render time | 5–10× faster than CPU |
| 45-180s clip | `1x1` | ~same as `9x16` | 5–10× faster than CPU |

Per-clip numbers are independent of source length — the reframer operates on the clip, not the full source. The analyze pass that runs before rendering scales with clip duration only.

### Format choice — one decision

**Default: `--format 9x16`.** The reframer's dynamic layout detector auto-detects camera switches (gallery → close-up → split → screen-share) and renders each segment appropriately, all while staying inside a `9x16` output frame. This handles 95% of podcast and interview content cleanly.

**Only force `--format split`** when all three hold:
- Source has 2+ speakers in fixed separate boxes for the full runtime (Riverside/Zoom gallery-first)
- Layout never switches mid-source (verified visually)
- Source is under 60 minutes

If ANY one fails — stay on `9x16`. Split on mixed-layout or long-source content is the common hang.

### Early-abort signals

Kill a stuck batch and retry with `--format 9x16` when you see:

- Analyze progress stalled at same percentage for > 5 minutes (normal progress is 1-5% per minute on CPU)
- Single clip render taking > 20× realtime (normal is 1-3×)
- Memory pressure (OOM kills) — cap batch parallelism at 3 concurrent renders
- Face detection < 10% on what should be a talking-head clip — see the diagnostic order below before retrying

### Troubleshooting low face detection

**The batch auto-handles the most common cause — don't manually intervene.** At batch start, `python -m clip_extractor batch` probes the source codec. For codecs OpenCV decodes poorly (currently just AV1), the batch transparently transcodes the whole source to H.264, runs against that, and cleans up at the end. You'll see `[clip:progress] {"stage":"transcode_start"}` / `transcode_done` events in your Bash tool card when this is firing. **H.264 / H.265 / VP9 skip this step.**

If a clip still has low face-%, walk this in order — the first hit usually explains everything:

1. **Did the auto-transcode fire for AV1 source?** If you see `probe_ok` with codec `av1` but no `transcode_start` — that's a bug, report it. If transcode DID fire, you're already on H.264; don't re-transcode.
2. **Does the clip actually contain faces?** Sample 5 frames with `ffmpeg -i clip.mp4 -vf "fps=0.2,scale=320:-1" -frames:v 5 /tmp/f-%02d.png` and eyeball. Screen shares, b-roll, and title cards have zero faces by design — not a bug.
3. **Too-strict confidence threshold?** Config default `detection.face.min_confidence: 0.5`. Side-profile and motion-blur faces score 0.3-0.4. Lower to 0.35 and re-analyze a single clip before batching.

New silent-empty-frame codec symptoms: add to `PROBLEMATIC_CODECS` in `__main__.py` — don't ship a one-off workaround.

### Recommended batch pattern for long sources

```bash
# Step 1: analyze-only pass first (inspect before committing to full render)
cd skills/clip-machine && python -m clip_extractor analyze \
  --video "source/original.mp4" \
  --clips "clips/clip_definitions.json" \
  --output "clips/crop_paths/"

# Step 2: review crop_path.json files, spot-check layout_segments on one or two clips

# Step 3: batch render
cd skills/clip-machine && python -m clip_extractor batch \
  --video "source/original.mp4" \
  --clips "clips/clip_definitions.json" \
  --output "clips/reframed/" \
  --format 9x16 \
  --workers 3
```

**Workers = parallel reframe processes.** Default 2. Formula: `(available_cores / 5)`, capped at 4. Set `--workers 1` to diagnose a single bad clip. Env override: `CLIP_EXTRACTOR_WORKERS=N`.

**Use `--workers` for parallelism, not sub-agents.** Batch is CPU-bound; the pool inside `batch` honors the worker cap.

**One clip failing ≠ batch failing.** Clips are independent. Retry a single failed clip with `--format 9x16 --use_nvenc disable`.

**Double-check clip 1 before batching the rest.** Render the first clip alone and watch the first ~10 seconds — especially for jitter on talking-head content. Same config produces the same behavior on every clip; if clip 1 wobbles, so will clip 2–10. Tune `deadzone.threshold_pct`, `smoothing.kalman.measurement_noise`, or `smoothing.rate_limit.max_velocity_px_per_frame` in `clip_extractor/config.yaml` before burning render time on the whole set.

### Progress events — watch the batch instead of guessing

The batch command emits structured `[clip:progress] {json}` lines to stdout, flushed per event, with the same shape as kino's render events:

| stage | When | Key fields |
|---|---|---|
| `batch_start` | batch spawn | `total`, `workers`, `format` |
| `clip_start` | a clip begins (serial mode only) | `clip_id`, `title`, `current`, `total` |
| `clip_done` | a clip finishes successfully | `clip_id`, `title`, `output`, `duration_sec`, `current`, `total` |
| `clip_error` | a clip failed | `clip_id`, `title`, `error`, `current`, `total` |
| `batch_done` | the whole batch is finished | `ok`, `failed`, `wall_sec` |

These stream live into your Bash tool card — the creator sees `[5/10] clip-05-cue-environment-not-yourself` land the moment that clip finishes. Before this, the batch was silent for 30+ minutes and the creator couldn't tell running from hung. If you're in a batch that's NOT emitting progress, something's wrong — check that you're using the real command (`python -m clip_extractor batch`) and not a wrapper that swallows stdout.

### Session-state recovery — when retries stop helping

If you see **MediaPipe thread exhaustion**, **libx264 "Could not open encoder"**, or **analyze hanging** on a clip that rendered fine earlier in the same session, the venv at `/tmp/clip-venv/` has accumulated resource debt — leaked MediaPipe threads, defunct FFmpeg children, exhausted file descriptors from prior runs. Three retries without cleanup won't resolve it; the process is already saturated.

**Nuke and recreate before retrying:**

```bash
rm -rf /tmp/clip-venv && \
  python3 -m venv /tmp/clip-venv --system-site-packages && \
  source /tmp/clip-venv/bin/activate && \
  pip install --quiet mediapipe opencv-contrib-python-headless pyyaml numpy filterpy scipy rapidfuzz
```

Then retry. The ~40-second pip-install cost is worth it vs. two more failed renders. This is a reactive recovery; the hygiene fixes in `__main__.py` + `pipeline.py` (try/finally on all detectors) mean it shouldn't normally be needed — but Python + MediaPipe + FFmpeg can still pathologically accumulate state across dozens of renders in one long session.

### Nix dynamic-library recipe (your host container only)

On Nix-based containers (your host production), the Python subprocess needs a specific `LD_LIBRARY_PATH` to resolve MediaPipe + OpenCV + ffmpeg native dependencies. Set it **on the subprocess only** — setting it on the parent shell corrupts the Nix python loader.

```bash
export LD_LIBRARY_PATH="/nix/store/{zlib}/lib:/nix/store/{gcc-14-20241116-lib}/lib:/nix/store/{libxcb}/lib:/nix/store/{libglvnd}/lib:/nix/store/{glib}/lib"
python -m clip_extractor reframe ...
```

Use the specific nix-store path hashes present in the container (discover via `ls /nix/store | grep zlib` etc.). **Must use `gcc-14-20241116-lib`, NOT `gcc-13-lib`** — ffmpeg 7.1's `libzimg.so.2` + `libsrt.so.1.5` require `CXXABI_1.3.15`, only present in gcc-14. Pulling gcc-13 fails every batch extract with `"version CXXABI_1.3.15 not found"`.

---

## Architecture

```
Input: 16:9 video (full source or pre-cut clip)
  → [Face Detection] MediaPipe BlazeFace per sampled frame
  → [Temporal Smoothing] EMA/Kalman to prevent jitter
  → [Deadzone] Suppress micro-movements
  → [Layout Detection] Auto-detect: face-track vs screen-share split
  → [crop_path.json] Inspectable intermediate (user can edit before render)
  → [Render] Face-track crop OR split-screen layout → 1080x1920 output
Output: 9:16 portrait clip with appropriate layout
```

**Python package:** `skills/clip-machine/clip_extractor/`
**Config:** `skills/clip-machine/clip_extractor/config.yaml` (all thresholds tunable)

## Video Ingest: YouTube vs Local

**If the input is a YouTube URL**, delegate to the `video-download` skill — it owns the yt-dlp + cookies path and the fallback-to-creator-upload flow. Do NOT download directly from this skill; `video-download` is the single entry point for all video acquisition in the agent's pipeline.

```bash
# Invoke via the video-download skill (yt-dlp + cookies, creator-upload fallback)
# No Apify. YouTube from cloud IPs only works with authenticated cookies;
# when cookies expire the fallback is always "ask the creator to drop the .mp4."
```

**If the input is a local video file** (already on disk, e.g. uploaded via chat attachment), skip the download step entirely — pass the file path directly to the reframe pipeline.

## Prerequisites

```bash
# Install dependencies (one-time)
cd skills/clip-machine/clip_extractor && pip install -r requirements.txt

# Verify
python -c "import mediapipe; print('MediaPipe:', mediapipe.__version__)"
ffmpeg -version | head -1
```

**RULE:** If deps are not installed, install them before proceeding.

## Reframe engine — internal phases

The `clip_extractor` reframe pass runs these phases internally (this is the engine, not a workflow):

| Phase | Name | What Happens |
|-------|------|-------------|
| 0 | CONTEXT | Check deps, identify source video, read config |
| 1 | EXTRACTION | FFmpeg stream-copy cut (if timestamps provided) or use pre-cut clip |
| 2 | REFRAME | Python engine: detect → smooth → deadzone → crop_path.json → render |
| 3 | OUTPUT | Report stats, generate metadata, hand off to the `clip-editor` agent |
| 4 | EVOLVE | Check for patterns and evolution opportunities |

### Phase 0: CONTEXT

1. Confirm video file exists and get metadata:
```bash
ffprobe -v quiet -print_format json -show_format -show_streams -select_streams v:0 "VIDEO_PATH"
```

2. Check dependencies are installed:
```bash
python -c "import mediapipe, cv2, numpy, yaml; print('All deps OK')"
```

3. Read config if custom path provided, otherwise use defaults from `skills/clip-machine/clip_extractor/config.yaml`.

### Phase 1: EXTRACTION (Optional)

If user provides start/end timestamps, extract the clip first:
```bash
python -m clip_extractor reframe --video "SOURCE.mp4" --start 120.5 --end 196.5 --output "clips/clip-01/" --format 9x16
```

If user provides a pre-cut clip, skip extraction — pass directly to reframe:
```bash
python -m clip_extractor reframe --video "CLIP.mp4" --output "clips/clip-01/" --format 9x16
```

### Phase 2: REFRAME

The engine runs automatically within the CLI command. The pipeline:

1. **Detect faces** — MediaPipe BlazeFace on every Nth frame (adaptive: 3rd for <5min, 6th for 5-30min, 10th for 30min+)
2. **Smooth positions** — EMA (alpha=0.12) prevents jittery crop movement
3. **Apply deadzone** — Don't move crop unless face shifts >5% of frame width
4. **Compute crop** — Center 9:16 window on smoothed face position, clamp to frame boundaries
5. **Write crop_path.json** — Inspectable intermediate with per-keyframe coordinates
6. **Render** — Frame-by-frame OpenCV→FFmpeg pipe with NVENC auto-detect

**Review crop_path.json before rendering** (analyze-only mode):
```bash
python -m clip_extractor analyze --video "CLIP.mp4" --output "crop_path.json"
# Review, then render:
python -m clip_extractor render --video "CLIP.mp4" --crop-path "crop_path.json" --output "reframed-9x16.mp4"
```

### Phase 3: OUTPUT

After reframe completes, report to user:
- Face detection percentage (should be >90% for talking head videos)
- Average confidence score
- Output file location and size
- **Next step:** Invoke `hyperframes-edit` for captions, overlays, and editorial polish. It authors the Hyperframes composition (single `index.html` + `DESIGN.md` HARD-GATE).

### Phase 4: EVOLVE

Standard evolution check.

## CLI Commands

```bash
# Full pipeline (most common)
python -m clip_extractor reframe --video FILE --output DIR [--start SEC --end SEC] [--format 9x16|1x1|split]

# Analyze only (inspect crop_path.json first)
python -m clip_extractor analyze --video FILE [--output FILE]

# Render from edited crop_path.json
python -m clip_extractor render --video FILE --crop-path FILE --output FILE

# Batch (multiple clips from definitions file)
python -m clip_extractor batch --video FILE --clips FILE --output DIR [--format 9x16|1x1|split] [--workers N]
```

**IMPORTANT:** The Python package is at `skills/clip-machine/clip_extractor/`. The internal module name is `clip_extractor`.
Run from `skills/clip-machine/clip_extractor/`: `cd skills/clip-machine/clip_extractor`

## Batch Mode

Create a `clip_definitions.json`:
```json
[
  {"id": 1, "title": "hook-moment", "start": 45.2, "end": 121.1},
  {"id": 2, "title": "key-insight", "start": 340.0, "end": 418.5, "layout": "split"}
]
```

```bash
python -m clip_extractor batch --video "source.mp4" --clips "clip_definitions.json" --output "clips/"
```

### Per-clip layout override

`layout` is optional per clip. When set, it overrides batch `--format` for that clip only. Allowed values match `--format`: `9x16` | `1x1` | `split`. Omit the field to inherit the batch default — single-archetype sources (one talking head throughout) need no overrides.

When to set it:
- **Mixed-archetype source** (two-shot podcast with screen-share segments, gallery + close-up cuts) — `clip-selection` writes `layout` per clip based on the archetype of that clip's frames.
- **Manual override** when the auto-detector picks wrong on a specific clip and you don't want to re-render the whole batch with a different `--format`.

A bad layout value fails the batch loudly at start (`batch_invalid_layout` progress event, exit 2) — not silently mid-render. The `batch_start` event includes `layout_mix` (a count per layout) so the creator sees the mix before any frames render.

## Output Structure

**Single-clip `reframe`** writes everything into one directory:
```
output_dir/
  raw.mp4              # Landscape extract (if start/end provided)
  crop_path.json       # Inspectable crop coordinates
  reframed-9x16.mp4    # Final portrait output
```

**Batch** (`python -m clip_extractor batch`) writes the **final reframed mp4 flat** at depth 1 with a clip-prefixed name, plus a sidecar manifest declaring layout choices, and keeps intermediates nested per clip:
```
output_dir/
  clip-01-{title}-reframed-9x16.mp4         # ← final, depth 1 — visible to pipeline scanner
  clip-01-{title}-reframed-9x16.manifest.json  # ← layout manifest (producer-consumer contract with hyperframes-edit)
  clip-02-{title}-reframed-9x16.mp4
  clip-02-{title}-reframed-9x16.manifest.json
  ...
  clip-01-{title}/
    raw.mp4           # ← intermediates stay nested
    crop_path.json
```

### Layout manifest contract (consumed by `hyperframes-edit` Phase 0.5)

The reframer KNOWS which layout it picked. The downstream editing skill should not have to re-derive it from pixels. Emit a sidecar manifest per clip declaring the producer's choices:

```json
{
  "version": 1,
  "source_clip": "clip-01-{title}.mp4",
  "reframed_clip": "clip-01-{title}-reframed-9x16.mp4",
  "format": "9x16",
  "layout_mode": "face-track",
  "layout_segments": [
    { "start_sec": 0.0, "end_sec": 21.4, "layout": "talking-head", "confidence": 0.94 },
    { "start_sec": 21.4, "end_sec": 38.9, "layout": "split-screen-ui-top", "confidence": 0.88 }
  ],
  "face_detected_pct": 0.96,
  "renderer_version": "2.0",
  "generated_at": "2026-05-02T20:54:00Z"
}
```

**Vocabulary** for `layout_mode` (the reframer's overall decision): `face-track` | `split-multi-face` | `split-dynamic-podcast` | `split-screen-ui-top` | `split-screen-ui-bottom` | `1x1-face-track`.

**Vocabulary** for per-segment `layout` (the classification per time window): `talking-head` | `split-screen-ui-top` | `split-screen-ui-bottom` | `stacked` | `b-roll` | `unknown`. This matches `skills/hyperframes-edit/SKILL.md` Phase 0.5 vocabulary so the consumer can read it directly.

This is the canonical layout the `scaffold-clip-pieces` + `hyperframes-edit` skills consume (their scanner stops at depth 1). Don't flatten manually downstream — if a future change ever lands the final mp4 anywhere other than depth 1, that's a contract drift bug, fix at the producer. See `.claude/rules/cross-skill-output-contracts.md`.

## Workflow variable contracts (for orchestrators)

When you chain the reframe step into the next step by hand, downstream reads specific variable names. Declare these explicitly — don't force the next step to infer from filepaths:

**`analyze_crops` step emits:**
- `crop_paths` → directory path `pipeline/04-production/{slug}/clips/crop_paths/`
- Contents: one file per input clip, named `{clip-title}-crop_path.json`. Each file conforms to `CropKeyframe` schema (face detection %, per-keyframe coordinates, layout_type, mouth_y when mouth-centering is active).

**`render_clips` step (batch) emits:**
- `rendered_clips` → JSON array of absolute file paths, one per input clip
- Shape: `["pipeline/04-production/{slug}/clips/reframed/{clip-title}-reframed-9x16.mp4", ...]`
- Directory: all rendered files live under `pipeline/04-production/{slug}/clips/reframed/`.

**`render_clips` reads optional per-clip `layout`** from the input `clip_definitions.json`. When present, it overrides batch-level `--format` for that one clip. Allowed values: `9x16` | `1x1` | `split`. The `batch_start` progress event reports `layout_mix` (counts per layout) so the orchestrator can verify the mix before any frames render.

**If you add a new phase that downstream skills depend on**, add its variable contract here in the same commit as the code. The alternative (downstream skills inferring from filesystem globs) is the same "silent integration breakage" pattern Agent C flagged — don't leave contracts implicit.

## Config Tuning

**Where to write tuning:** `{workspace}/.skill-config/clip-machine.yaml` — NOT the skill's own `config.yaml`. The skill's config lives in `/app/skills/` (junction-pointed from the workspace) which your host rebuilds fresh on every deploy — any edit there vanishes on the next push. The `.skill-config/` directory lives on the workspace volume and persists. The loader deep-merges `.skill-config/clip-machine.yaml` on top of the baked defaults, so only specify the keys you want to override.

Example — persist aggressive mouth-centering for a gesture-heavy talker:
```yaml
# /data/workspaces/{partnerId}/.skill-config/clip-machine.yaml
crop:
  face_position:
    y_target: 0.50
  vertical_crop_ratio: 0.70
  mouth_centering:
    ema_alpha: 0.40
smoothing:
  kalman:
    measurement_noise: 0.25
```

Defaults are in `skills/clip-machine/clip_extractor/config.yaml` (read-only reference). To change the default for ALL creators, commit the change to the repo. To tune ONE creator, write to their `.skill-config/clip-machine.yaml`.

| Parameter | Default | Effect |
|-----------|---------|--------|
| `detection.face.min_confidence` | 0.5 | Lower = detect more faces (incl. side profiles) |
| `smoothing.ema.alpha` | 0.12 | Lower = smoother (more lag). Try 0.08 for slow speakers |
| `deadzone.threshold_pct` | 0.05 | Lower = more responsive. Try 0.03 for animated speakers |
| `output.crf` | 18 | Lower = higher quality, bigger file. 18-23 recommended |
| `output.use_nvenc` | auto | "force" for GPU, "disable" for CPU-only |
| `split_screen.dynamic_layout.face_size_threshold` | 0.06 | Lower = more frames classified as split-screen |
| `split_screen.dynamic_layout.smoothing_window` | 15 | Higher = more stable segment boundaries |
| `split_screen.dynamic_layout.crossfade_frames` | 5 | Frames for layout transition crossfade |

## Non-Negotiable Rules

1. **NEVER render without crop_path.json** -- always generate and inspect first
2. **NEVER re-encode during extraction** -- use `ffmpeg -c copy` for stream copy
3. **ALWAYS check face detection %** -- below 80% means detection config needs tuning
4. **NEVER produce black bars** -- boundary clamping is always on
5. **ALWAYS use NVENC when available** -- 5-10x faster than libx264
6. **NEVER extract clips from raw/uncut footage.** Cut first, clip second. ALWAYS. Raw footage has retakes, dead air, and false starts that will end up in your clips.
7. **YouTube URL must exist BEFORE clip production begins.** Clips reference "full video" in their end-card CTA. No URL = no CTA = broken clip.
8. **Clip end-card: each clip ends with YouTube thumbnail as CTA.** This drives traffic back to the long-form content. Every clip is a funnel.
9. **Raw FFmpeg timestamp cuts are NOT acceptable as final output.** Face-tracking reframe is REQUIRED. A landscape crop slapped into a 9:16 frame is not a clip -- it's a crop.
10. **Check `crop_path.json` `layout_segments` for dynamic transitions.** If the source has layout changes (split-screen to close-up), verify the segments render correctly with crossfades.
11. **Reframe and batch renders MUST use `Bash(run_in_background: true)`.** Foreground Bash blocks the turn for 1-5 min of silence — the creator sees a spinner, concludes the agent hung, and loses trust. Background Bash lets `the background-task tailer` parse `[clip:progress]` markers live and stream them into the creator's tool card.
12. **NEVER pipe render stdout through `grep`, `head`, or other filters.** `[clip:progress] {json}` markers must reach the server tailer intact. For a post-render summary, read the output file or run `ffprobe` after the background task finishes — don't filter stdout mid-run.

## Integration

- **Upstream:** video-download (gets the file) → extracting-transcripts (gets word timing) → clip-selection (picks moments)
- **Downstream:** `hyperframes-edit` for caption-first editing — Hyperframes composition (single `index.html` + `DESIGN.md` HARD-GATE)
- **Terminal:** publish skill for social distribution

## References

- `skills/clip-machine/clip_extractor/config.yaml` — All tunable parameters
- `skills/clip-machine/clip_extractor/requirements.txt` — Python dependencies
- `skills/clip-selection/SKILL.md` — Clip selection skill (upstream)
- `skills/extracting-transcripts/SKILL.md` — Transcript extraction skill (upstream)
- `skills/hyperframes-edit/SKILL.md` — Hyperframes-native authoring (downstream)

## Evolution Check (End of Every Invocation)

1. Did face detection fail on a video type not yet encountered? → Note the type and config adjustment
2. Was the default config inadequate? → Document recommended config per video type
3. Did the user manually edit crop_path.json? → Analyze what they changed as a pattern
4. Did rendering fail or produce artifacts? → Document the fix

**Version:** 2.0
**Status:** Phase 6 — Dynamic Podcast Layout Detection

---

## Confidence — score before you ship

Self-score 0–100 against the creator's brand foundation. In your Claude Code project that foundation is the active scope's **`content-production/brand-profile.md`** (tenant/company/client/project) — NOT the legacy Remotion `pipeline/08-ecosystem/reference/` tree (VOICE/PILLARS/ICP/QUALITY-FILTER), which does not exist here. Read the brand-profile's voice/alignment/ICP/pillars sections and score as the creator's harshest critic — what would an expert reviewer who knows this brand cold cut or flag? Below 95 → iterate 2–3 focused passes, name what changed. Don't ship weak work under the creator's name.
