"""Detect layout type per frame and group into segments for dynamic podcast reframing.

Classifies each analyzed frame as SPLIT_SCREEN (gallery/Zoom: 2+ small faces far apart)
or CLOSE_UP (studio: 1-2 large faces near center) based on face size and spatial spread.
Groups consecutive same-type frames into LayoutSegments.

Uses the `all_faces` DNN detection data already stored in CropKeyframe during analyze() —
no extra video scan required.
"""

import json
from collections import Counter
from dataclasses import dataclass
from enum import Enum

from ..crop.crop_path_io import CropKeyframe


class LayoutType(Enum):
    SPLIT_SCREEN = "split_screen"
    CLOSE_UP = "close_up"


@dataclass
class LayoutSegment:
    layout: LayoutType
    start_frame: int
    end_frame: int
    start_sec: float
    end_sec: float


def classify_frame(
    faces: list[dict],
    face_size_threshold: float = 0.06,
    spatial_spread_threshold: float = 0.15,
) -> LayoutType | None:
    """Classify a single frame's layout based on detected faces.

    Args:
        faces: List of face dicts with keys "x", "y", "w", "h", "conf".
        face_size_threshold: Faces below this normalized width = gallery/split.
        spatial_spread_threshold: Min horizontal distance between faces for split.

    Returns:
        LayoutType or None if insufficient data.
    """
    if not faces or len(faces) < 2:
        return None  # Can't classify with fewer than 2 faces

    # Filter low-confidence detections
    good_faces = [f for f in faces if f.get("conf", 0) > 0.3]
    if len(good_faces) < 2:
        return None

    # Primary signal: median face width
    widths = sorted([f["w"] for f in good_faces])
    median_width = widths[len(widths) // 2]

    # Secondary signal: max horizontal distance between face centers
    xs = [f["x"] for f in good_faces]
    max_h_distance = max(xs) - min(xs)

    # Classification
    if median_width < face_size_threshold and max_h_distance > spatial_spread_threshold:
        return LayoutType.SPLIT_SCREEN
    elif median_width >= face_size_threshold * 0.67 and max_h_distance < spatial_spread_threshold * 0.8:
        return LayoutType.CLOSE_UP
    else:
        # Scoring tiebreak: weight face size more heavily
        split_score = (1.0 if median_width < face_size_threshold else 0.0) * 0.5 + \
                      (1.0 if max_h_distance > spatial_spread_threshold else 0.0) * 0.3 + \
                      (1.0 if len(good_faces) >= 2 else 0.0) * 0.2
        return LayoutType.SPLIT_SCREEN if split_score > 0.5 else LayoutType.CLOSE_UP


def _majority_vote_smooth(
    classifications: list[LayoutType | None],
    window: int = 15,
) -> list[LayoutType | None]:
    """Apply majority-vote smoothing to eliminate single-frame classification noise."""
    n = len(classifications)
    smoothed = list(classifications)
    half = window // 2

    for i in range(n):
        start = max(0, i - half)
        end = min(n, i + half + 1)
        votes = [c for c in classifications[start:end] if c is not None]
        if votes:
            counter = Counter(votes)
            smoothed[i] = counter.most_common(1)[0][0]

    return smoothed


def detect_segments(
    keyframes: list[CropKeyframe],
    fps: float,
    config: dict | None = None,
) -> list[LayoutSegment]:
    """Detect layout segments from analyzed keyframes.

    Args:
        keyframes: List of CropKeyframe from analyze().
        fps: Source video FPS.
        config: Optional dynamic_layout config dict.

    Returns:
        List of LayoutSegment sorted by start_frame.
    """
    if config is None:
        config = {}

    face_size_threshold = config.get("face_size_threshold", 0.06)
    spatial_spread_threshold = config.get("spatial_spread_threshold", 0.15)
    min_segment_duration = config.get("min_segment_duration", 1.0)
    smoothing_window = config.get("smoothing_window", 15)

    # Step 1: Classify each keyframe
    classifications: list[LayoutType | None] = []
    for kf in keyframes:
        if not kf.all_faces:
            classifications.append(None)
            continue
        try:
            faces = json.loads(kf.all_faces)
        except (json.JSONDecodeError, TypeError):
            classifications.append(None)
            continue

        layout = classify_frame(faces, face_size_threshold, spatial_spread_threshold)
        classifications.append(layout)

    # Step 2: Majority-vote smoothing
    smoothed = _majority_vote_smooth(classifications, smoothing_window)

    # Step 3: Group consecutive same-type frames into segments
    raw_segments: list[LayoutSegment] = []
    current_layout = None
    seg_start_idx = 0

    for i, layout in enumerate(smoothed):
        if layout is None:
            continue

        if current_layout is None:
            current_layout = layout
            seg_start_idx = i

        if layout != current_layout:
            # Close current segment
            raw_segments.append(LayoutSegment(
                layout=current_layout,
                start_frame=keyframes[seg_start_idx].frame,
                end_frame=keyframes[i - 1].frame,
                start_sec=keyframes[seg_start_idx].time_sec,
                end_sec=keyframes[i - 1].time_sec,
            ))
            current_layout = layout
            seg_start_idx = i

    # Close final segment
    if current_layout is not None and keyframes:
        raw_segments.append(LayoutSegment(
            layout=current_layout,
            start_frame=keyframes[seg_start_idx].frame,
            end_frame=keyframes[-1].frame,
            start_sec=keyframes[seg_start_idx].time_sec,
            end_sec=keyframes[-1].time_sec,
        ))

    if not raw_segments:
        return []

    # Step 4: Merge short segments into neighbors
    min_frames = int(min_segment_duration * fps)
    merged: list[LayoutSegment] = [raw_segments[0]]

    for seg in raw_segments[1:]:
        duration_frames = seg.end_frame - seg.start_frame
        if duration_frames < min_frames:
            # Merge into previous segment
            merged[-1] = LayoutSegment(
                layout=merged[-1].layout,
                start_frame=merged[-1].start_frame,
                end_frame=seg.end_frame,
                start_sec=merged[-1].start_sec,
                end_sec=seg.end_sec,
            )
        else:
            merged.append(seg)

    return merged


# ── Shot-adaptive reframing (Phase 8) ──────────────────────────────────
# Complementary to LayoutType (which answers "is this a single-speaker
# or split-screen frame?"). ShotType answers "how zoomed in is the face?"
# — a dimension orthogonal to layout. A close-up shot can be a single
# face-fill OR a tight pair in split-screen; the two classifications
# don't overlap.
#
# The shot-type vocabulary maps each keyframe to a named preset so the
# reframer can dispatch different behaviors per segment:
#
#   wide-far         — face < 10% frame width. Aggressive mouth tracking,
#                      tight crop, phantom rejection at full strength.
#   wide-standard    — face 10-20%. Current default behavior.
#   medium           — face 20-30%. Lighter correction, y_target shifts
#                      toward geometric center.
#   close-up         — face 30-45%. Mouth-centering OFF. HOLD the shot.
#                      Editorial logic: a human editor doesn't chase a
#                      big face around — they let the frame be.
#   tight-close-up   — face > 45%. Near pass-through. All smoothing
#                      dialed down; any micro-tracking feels AI-processed.
#
# Classification is per-keyframe (by face_bbox_width_norm), then smoothed
# with a majority-vote window (same pattern as LayoutType) and merged
# across short segments. Keyframes inherit their segment's shot_type
# label so downstream dispatch can look up the right preset without
# re-running classification.

SHOT_TYPE_ORDER = ["wide-far", "wide-standard", "medium", "close-up", "tight-close-up"]


def classify_frame_shot(
    face_width_norm: float | None,
    presets_config: dict,
) -> str | None:
    """Classify a single keyframe's shot type by face width.

    Args:
        face_width_norm: bbox.width normalized to frame width (0-1), or
            None when no face was detected this keyframe.
        presets_config: `crop.shot_presets` dict. Each preset must have
            a `max_face_width` field (the upper bound for that bucket).
            Shot types are tested in SHOT_TYPE_ORDER; the first one
            whose `max_face_width` exceeds `face_width_norm` wins.

    Returns:
        The shot-type name, or None when no detection.
    """
    if face_width_norm is None:
        return None
    for shot_type in SHOT_TYPE_ORDER:
        preset = presets_config.get(shot_type, {})
        max_width = preset.get("max_face_width", 1.0)
        if face_width_norm < max_width:
            return shot_type
    return SHOT_TYPE_ORDER[-1]


def _majority_vote_shots(
    classifications: list[str | None],
    window: int = 15,
) -> list[str | None]:
    """Majority-vote smoothing for shot-type classifications.

    Same pattern as _majority_vote_smooth but for string labels.
    Eliminates single-keyframe noise (one bad face detection flipping
    the shot type for a single frame).
    """
    n = len(classifications)
    smoothed = list(classifications)
    half = window // 2
    for i in range(n):
        start = max(0, i - half)
        end = min(n, i + half + 1)
        votes = [c for c in classifications[start:end] if c is not None]
        if votes:
            counter = Counter(votes)
            smoothed[i] = counter.most_common(1)[0][0]
    return smoothed


def classify_shot_segments(
    keyframes: list[CropKeyframe],
    fps: float,
    presets_config: dict | None = None,
    adaptive_config: dict | None = None,
) -> list[dict]:
    """Segment a clip by shot type (wide/medium/close-up) based on face width.

    Operates on already-analyzed keyframes (they must carry
    `face_bbox_width_norm`). Returns a list of shot segments and — as a
    side effect — sets `kf.shot_type` on each keyframe so downstream
    code can look up the label without re-scanning.

    Args:
        keyframes: keyframes from the analyze pass.
        fps: source FPS, for duration-based merging.
        presets_config: `crop.shot_presets` dict from config.yaml.
        adaptive_config: `crop.shot_adaptive` dict
            (smoothing_window, min_segment_duration).

    Returns:
        list[dict] — one dict per segment, each with:
            start_frame, end_frame, start_sec, end_sec, shot_type,
            face_width_median.
    """
    if not keyframes:
        return []
    presets_config = presets_config or {}
    adaptive_config = adaptive_config or {}
    smoothing_window = adaptive_config.get("smoothing_window", 15)
    min_segment_duration = adaptive_config.get("min_segment_duration", 1.5)

    # Step 1: classify each keyframe
    raw = [classify_frame_shot(kf.face_bbox_width_norm, presets_config) for kf in keyframes]

    # Step 2: majority-vote smoothing
    smoothed = _majority_vote_shots(raw, smoothing_window)

    # Step 3: write back onto each keyframe — downstream reads
    # kf.shot_type instead of re-classifying.
    for kf, label in zip(keyframes, smoothed):
        if label is not None:
            kf.shot_type = label

    # Step 4: group consecutive same-type keyframes into raw segments
    raw_segments: list[dict] = []
    current_type: str | None = None
    seg_start_idx = 0
    seg_widths: list[float] = []

    for i, (kf, label) in enumerate(zip(keyframes, smoothed)):
        if label is None:
            continue
        if current_type is None:
            current_type = label
            seg_start_idx = i
            seg_widths = []
        if label != current_type:
            # close current
            median_w = sorted(seg_widths)[len(seg_widths) // 2] if seg_widths else 0.0
            raw_segments.append({
                "start_frame": keyframes[seg_start_idx].frame,
                "end_frame": keyframes[i - 1].frame,
                "start_sec": keyframes[seg_start_idx].time_sec,
                "end_sec": keyframes[i - 1].time_sec,
                "shot_type": current_type,
                "face_width_median": round(median_w, 4),
            })
            current_type = label
            seg_start_idx = i
            seg_widths = []
        if kf.face_bbox_width_norm is not None:
            seg_widths.append(kf.face_bbox_width_norm)

    # Close final segment
    if current_type is not None and keyframes:
        median_w = sorted(seg_widths)[len(seg_widths) // 2] if seg_widths else 0.0
        raw_segments.append({
            "start_frame": keyframes[seg_start_idx].frame,
            "end_frame": keyframes[-1].frame,
            "start_sec": keyframes[seg_start_idx].time_sec,
            "end_sec": keyframes[-1].time_sec,
            "shot_type": current_type,
            "face_width_median": round(median_w, 4),
        })

    if not raw_segments:
        return []

    # Step 5: merge segments shorter than min duration into the previous one.
    # Short segments are usually detection noise — a single bad face width
    # reading that flips the shot-type for half a second. Not worth a
    # preset change + crossfade.
    min_frames = int(min_segment_duration * fps)
    merged: list[dict] = [raw_segments[0]]
    for seg in raw_segments[1:]:
        duration_frames = seg["end_frame"] - seg["start_frame"]
        if duration_frames < min_frames:
            # Extend the previous segment to cover this one; keep its shot_type.
            merged[-1] = {
                **merged[-1],
                "end_frame": seg["end_frame"],
                "end_sec": seg["end_sec"],
            }
        else:
            merged.append(seg)

    # Step 6: split segments at scene-cut boundaries. Face-width
    # classification alone misses speaker switches in two-shot interview
    # content where both speakers are framed at similar face widths —
    # whole clip classifies as one segment even though the camera cuts
    # between speakers. Splitting on scene_change gives each camera-cut
    # sub-segment its own boundary (same shot_type label preserved) so
    # the pipeline's scene-change smoother reset produces a clean
    # zero-frame cut AND downstream renderers see the boundary for
    # crossfade work. Keyframes retain kf.scene_change=True populated
    # by scene_detector during the analyze loop.
    scene_cut_split: list[dict] = []
    for seg in merged:
        cut_frames = [
            kf.frame for kf in keyframes
            if seg["start_frame"] < kf.frame <= seg["end_frame"]
            and kf.scene_change
        ]
        if not cut_frames:
            scene_cut_split.append(seg)
            continue
        # Split at each cut: close the prior piece just before the cut,
        # open a new piece at the cut. All sub-pieces keep the same
        # shot_type + face_width_median (face-width classification
        # didn't change across the cut, only the camera angle did).
        current_start_frame = seg["start_frame"]
        current_start_sec = seg["start_sec"]
        for cut_frame in cut_frames:
            cut_time_sec = round(cut_frame / fps, 3)
            scene_cut_split.append({
                **seg,
                "start_frame": current_start_frame,
                "start_sec": current_start_sec,
                "end_frame": cut_frame - 1,
                "end_sec": round((cut_frame - 1) / fps, 3),
            })
            current_start_frame = cut_frame
            current_start_sec = cut_time_sec
        # Close the final sub-piece
        scene_cut_split.append({
            **seg,
            "start_frame": current_start_frame,
            "start_sec": current_start_sec,
        })

    return scene_cut_split
