# Clip Machine Tools

Python face-tracking reframe engine. Takes 16:9 video, outputs 9:16 portrait clips with intelligent layout detection.

## How to Run

```bash
# Full pipeline (single clip)
cd skills/clip-machine/clip_extractor
python -m clip_extractor reframe --video FILE --output DIR

# Analyze only (inspect crop path)
python -m clip_extractor analyze --video FILE

# Batch mode (multiple clips from definitions file)
python -m clip_extractor batch --video FILE --clips definitions.json --output DIR
```

## What Each Folder Does

| Folder | Purpose |
|--------|---------|
| `core/` | Pipeline orchestration -- runs the full reframe flow |
| `crop/` | Crop calculation + rendering -- computes where to cut the frame |
| `detection/` | Face, pose, and layout detection -- finds faces and determines layout mode |
| `models/` | Pre-trained ML models (BlazeFace, YuNet, pose) -- don't modify these |
| `selection/` | SRT parsing + timestamp resolution -- maps transcript words to video timestamps |
| `tracking/` | Kalman smoothing + deadzone -- prevents jittery camera movement |
| `utils/` | Frame reading, scene detection, video info helpers |

## Key Files

- `config.yaml` -- all tunable parameters (detection sensitivity, smoothing, quality)
- `__main__.py` -- CLI entry point
- `yt-download.sh` -- YouTube video downloader via Apify (cloud-safe, no yt-dlp)
- `gdrive-download.sh` -- Google Drive file downloader (curl-only, handles large file confirmation)
- `requirements.txt` -- Python dependencies

## Layout Modes (auto-detected)

1. **9:16 face-track** -- single face talking head
2. **1:1 square** -- Instagram/LinkedIn format
3. **Split: multi-face** -- interviews, podcasts (faces side by side)
4. **Split: screen-share** -- tutorials with webcam overlay
5. **Split: dynamic podcast** -- auto-detects layout changes per segment
