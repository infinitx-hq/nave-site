"""Compute crop window from face center position and configuration."""

from dataclasses import dataclass


@dataclass
class CropWindow:
    """Pixel-level crop coordinates for FFmpeg."""

    x: int       # Left edge of crop
    y: int       # Top edge of crop
    width: int   # Crop width in pixels
    height: int  # Crop height in pixels


class CropCalculator:
    """Converts normalized face center position to pixel crop window.

    For 9:16 output from 16:9 source:
    - Crop width = source_height * (9/16) ≈ 607px from 1080p
    - Crop height is slightly less than source_height (default 92%) to
      create a vertical sliding window — previously the crop was full
      source height with y=0 fixed, which meant face y-position was
      completely ignored. With vertical_crop_ratio < 1.0, the crop can
      slide up or down by (1 - ratio) * source_h so the face lands at
      `y_target` of the output height regardless of where it is in the
      source frame. Default y_target = 0.38 places the face in the
      upper-middle per the rule of thirds.
    - Horizontal position follows face x center (unchanged).

    For 1:1 output:
    - Crop is square with side = source height
    - Same vertical logic as 9:16 when vertical_crop_ratio < 1.0.

    Why this matters: before 2026-04-20, the 9x16 face-track path ignored
    face_y entirely (y=0 hardcoded), and that produced the "vertical head
    bob" creators reported on long-form podcast content — the speaker's
    mouth drifted up and down in the output frame as they leaned or
    gestured, because the crop couldn't follow vertically. This
    calculator now consumes face_y_norm (or mouth_y_norm when the
    MouthLandmarker is active); the renderer reads crop_y from the
    CropKeyframe instead of hardcoding 0.
    """

    def __init__(
        self,
        source_w: int,
        source_h: int,
        output_format: str = "9x16",
        vertical_crop_ratio: float = 0.92,
        y_target: float = 0.38,
    ):
        self.source_w = source_w
        self.source_h = source_h
        self.vertical_crop_ratio = max(0.5, min(1.0, vertical_crop_ratio))
        self.y_target = max(0.0, min(1.0, y_target))

        if output_format == "9x16":
            self.aspect = 9 / 16
        elif output_format == "1x1":
            self.aspect = 1.0
        else:
            raise ValueError(f"Unsupported format: {output_format}. Use '9x16' or '1x1'.")

        # Crop height — slightly less than source height to create the
        # vertical sliding window. vertical_crop_ratio=1.0 disables
        # vertical positioning (legacy behavior); <1.0 enables it.
        self.crop_h = int(source_h * self.vertical_crop_ratio)
        self.crop_w = int(self.crop_h * self.aspect)

        # If the computed crop width exceeds source width, clamp both
        # dimensions proportionally so we never crop outside the frame.
        if self.crop_w > source_w:
            self.crop_w = source_w
            self.crop_h = int(source_w / self.aspect)

        # Max vertical sliding range — distance the crop can move up/down.
        # 0 when vertical_crop_ratio == 1.0 (legacy; crop fills full height).
        self.max_y_offset = source_h - self.crop_h

    def compute(
        self,
        face_x_norm: float,
        face_y_norm: float = 0.5,
        y_target_override: float | None = None,
    ) -> CropWindow:
        """Compute crop window centered on face position.

        Args:
            face_x_norm: Normalized face x center (0=left, 1=right).
            face_y_norm: Normalized face y center (0=top, 1=bottom).
                When the MouthLandmarker is active upstream, callers pass
                the mouth y position here so the crop places the mouth
                at y_target instead of the bbox center.
            y_target_override: Optional per-call y_target (0.0-1.0). When
                set, it replaces `self.y_target` for this compute() only.
                Used by shot-adaptive reframing — close-up segments want
                y_target≈0.50 (centered, "held" feel) while wide segments
                want y_target≈0.38 (upper-third, active tracking). Leaves
                `self.y_target` untouched so downstream calls keep their
                original config unless explicitly overridden.

        Returns:
            CropWindow with pixel coordinates clamped to frame boundaries.
        """
        y_t = max(0.0, min(1.0, y_target_override)) if y_target_override is not None else self.y_target

        # Convert normalized face position to pixels
        face_x_px = face_x_norm * self.source_w
        face_y_px = face_y_norm * self.source_h

        # Horizontal: center crop on face x (unchanged behavior).
        crop_x = int(face_x_px - self.crop_w / 2)
        crop_x = max(0, min(crop_x, self.source_w - self.crop_w))

        # Vertical: place face_y at y_target of the crop height.
        # face_y_px is in source pixels; we want the crop's top edge such
        # that (face_y_px - crop_y) / crop_h == y_target, i.e.
        # crop_y = face_y_px - y_target * crop_h. Clamp to frame.
        if self.max_y_offset > 0:
            crop_y = int(face_y_px - y_t * self.crop_h)
            crop_y = max(0, min(crop_y, self.max_y_offset))
        else:
            # Legacy mode (vertical_crop_ratio=1.0) — crop fills full height.
            crop_y = 0

        return CropWindow(
            x=crop_x,
            y=crop_y,
            width=self.crop_w,
            height=self.crop_h,
        )

    @property
    def output_dimensions(self) -> tuple[int, int]:
        """Final output dimensions after scaling."""
        if self.aspect == 9 / 16:
            return 1080, 1920
        elif self.aspect == 1.0:
            return 1080, 1080
        return self.crop_w, self.crop_h
