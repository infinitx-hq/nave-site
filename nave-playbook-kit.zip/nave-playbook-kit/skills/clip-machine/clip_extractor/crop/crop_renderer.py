"""FFmpeg-based crop rendering with dynamic per-frame positions.

Uses a frame-by-frame Python pipeline: OpenCV reads → crop → FFmpeg pipe encodes.
More reliable than FFmpeg sendcmd for dynamic crops, with full per-frame control.
"""

import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import cv2
import numpy as np

from .crop_path_io import CropPath


_NVENC_CACHE: bool | None = None


class _FrameProgress:
    """Per-renderer throttled progress emitter.

    Emits structured `[clip:progress] {json}` events at 1% step OR 15s
    since last emit — whichever fires first. parsed by the runner
    the background-task tailer and broadcast to the agent's the tool card
    as live progress. See split_renderer._FrameProgress for the
    companion class + full rationale.
    """

    def __init__(
        self,
        total: int,
        layout: str = "render",
        min_pct_step: float = 1.0,
        max_interval_sec: float = 15.0,
    ):
        self.total = max(1, total)
        self.layout = layout
        self.min_pct_step = min_pct_step
        self.max_interval_sec = max_interval_sec
        self._last_pct = -1.0
        self._last_time = time.time()

    def tick(self, frame_idx: int) -> None:
        pct = frame_idx / self.total * 100.0
        now = time.time()
        final = frame_idx >= self.total
        if (
            pct - self._last_pct >= self.min_pct_step
            or now - self._last_time >= self.max_interval_sec
            or final
        ):
            self._last_pct = pct
            self._last_time = now
            event = {
                "stage": "render",
                "layout": self.layout,
                "detail": f"Frame {frame_idx}/{self.total}",
                "pct": int(pct),
                "at": int(now * 1000),
            }
            print(f"[clip:progress] {json.dumps(event)}", flush=True)
            print(
                f"  Rendering {self.layout}: {int(pct)}% "
                f"({frame_idx}/{self.total} frames)",
                flush=True,
            )


def _detect_nvenc() -> bool:
    """Probe whether NVIDIA NVENC is actually usable — not just listed.

    Two-step check:
      1. Grep ``ffmpeg -encoders`` for ``h264_nvenc``. Cheap negative — if
         the encoder isn't compiled in, no point probing further.
      2. Run a one-frame trial encode against a synthetic lavfi source. A
         listed encoder can still fail at runtime when the driver is an
         incompatible version, the GPU has hit its concurrent-session limit
         (consumer GPUs cap at 2–3), ffmpeg is running inside WSL without
         GPU passthrough, or another process is holding the encoder.

    The old implementation only ran step 1, so on machines where NVENC was
    listed but unusable it silently reported "NVENC available" and the
    real render failed mid-batch with a cryptic ffmpeg error. Step 2 is
    the fix.

    Result is cached per-process — the probe costs ~200 ms and the answer
    doesn't change during a single batch run.
    """
    global _NVENC_CACHE
    if _NVENC_CACHE is not None:
        return _NVENC_CACHE

    try:
        listed = subprocess.run(
            ["ffmpeg", "-hide_banner", "-encoders"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        if "h264_nvenc" not in listed.stdout:
            _NVENC_CACHE = False
            return False

        # Trial encode: 1 frame from a 128x128 synthetic source piped to
        # null. Exit 0 = NVENC actually works. Any non-zero exit or
        # exception means fall back to libx264.
        probe = subprocess.run(
            [
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                "-f", "lavfi", "-i", "nullsrc=s=128x128:d=0.04",
                "-c:v", "h264_nvenc",
                "-frames:v", "1",
                "-f", "null", "-",
            ],
            capture_output=True,
            timeout=15,
            check=False,
        )
        _NVENC_CACHE = probe.returncode == 0
        return _NVENC_CACHE
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        _NVENC_CACHE = False
        return False


def _build_ffmpeg_cmd(
    output_path: str,
    width: int,
    height: int,
    fps: float,
    audio_source: str,
    config: dict,
) -> list[str]:
    """Build the FFmpeg command for piped encoding."""
    use_nvenc = config.get("use_nvenc", "auto")
    has_nvenc = _detect_nvenc() if use_nvenc == "auto" else use_nvenc == "force"

    cmd = [
        "ffmpeg", "-y",
        "-f", "rawvideo",
        "-pix_fmt", "bgr24",
        "-s", f"{width}x{height}",
        "-r", str(fps),
        "-i", "pipe:0",          # Video from stdin
        "-i", audio_source,       # Audio from original file
        "-map", "0:v:0",
        "-map", "1:a:0?",        # ? = don't fail if no audio
    ]

    if has_nvenc:
        cmd.extend([
            "-c:v", "h264_nvenc",
            "-preset", config.get("nvenc_preset", "p4"),
            "-rc", "vbr",
            "-b:v", "8M",
            "-maxrate", "12M",
            "-pix_fmt", "yuv420p",
        ])
    else:
        cmd.extend([
            "-c:v", "libx264",
            "-preset", config.get("preset", "medium"),
            "-crf", str(config.get("crf", 18)),
            "-pix_fmt", "yuv420p",
        ])

    cmd.extend([
        "-c:a", "copy",
        "-movflags", "+faststart",
        output_path,
    ])

    return cmd


def _interpolate_crop_axis(
    crop_path: CropPath,
    frame_idx: int,
    axis: str = "x",
) -> int:
    """Get interpolated crop coordinate for any frame index.

    Linear interpolation between keyframes for smooth motion along the
    given axis ("x" or "y"). Works for any attribute named crop_{axis}
    on the keyframe dataclass.
    """
    attr = f"crop_{axis}"
    keyframes = crop_path.keyframes
    if not keyframes:
        return 0

    if frame_idx <= keyframes[0].frame:
        return getattr(keyframes[0], attr)

    if frame_idx >= keyframes[-1].frame:
        return getattr(keyframes[-1], attr)

    for i in range(len(keyframes) - 1):
        if keyframes[i].frame <= frame_idx < keyframes[i + 1].frame:
            kf_a = keyframes[i]
            kf_b = keyframes[i + 1]
            t = (frame_idx - kf_a.frame) / (kf_b.frame - kf_a.frame)
            a = getattr(kf_a, attr)
            b = getattr(kf_b, attr)
            return int(a + t * (b - a))

    return getattr(keyframes[-1], attr)


def _interpolate_crop_x(crop_path: CropPath, frame_idx: int) -> int:
    """Backward-compat shim — delegates to the new _interpolate_crop_axis."""
    return _interpolate_crop_axis(crop_path, frame_idx, axis="x")


def render_with_crop_path(
    video_path: str,
    crop_path: CropPath,
    output_path: str,
    config: dict,
) -> None:
    """Render the final cropped video using the computed crop path.

    Reads frames with OpenCV, applies per-frame crop, pipes to FFmpeg for encoding.
    This approach gives full control over every frame's crop position.

    Args:
        video_path: Path to the input video.
        crop_path: CropPath object with keyframes.
        output_path: Path for the output video.
        config: Output config section from config.yaml.
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")

    fps = crop_path.source_fps
    crop_w = crop_path.output_crop_w
    crop_h = crop_path.output_crop_h
    total = crop_path.source_total_frames

    # Determine output dimensions
    if config.get("scale_output", True):
        if crop_path.output_format == "9x16":
            out_w, out_h = 1080, 1920
        elif crop_path.output_format == "1x1":
            out_w, out_h = 1080, 1080
        else:
            out_w, out_h = crop_w, crop_h
    else:
        out_w, out_h = crop_w, crop_h

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    ffmpeg_cmd = _build_ffmpeg_cmd(
        output_path=output_path,
        width=out_w,
        height=out_h,
        fps=fps,
        audio_source=video_path,
        config=config,
    )

    # Write stderr to a temp file to avoid pipe deadlock
    stderr_file = tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False)

    proc = subprocess.Popen(
        ffmpeg_cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=stderr_file,
    )

    try:
        progress = _FrameProgress(total, layout="face-track")
        frame_idx = 0
        while frame_idx < total:
            ret, frame = cap.read()
            if not ret:
                break

            # Get interpolated crop position for this frame.
            # crop_y was previously hardcoded to 0, which meant the 9x16
            # path ignored face_y entirely. Now the CropCalculator sets
            # a non-zero crop_y based on face_y (or mouth_y when the
            # MouthLandmarker is active), and the renderer reads it back
            # from the keyframe — same interpolation pattern as crop_x.
            # Closes the "silent data contract violation" Agent B flagged.
            crop_x = _interpolate_crop_axis(crop_path, frame_idx, axis="x")
            crop_y = _interpolate_crop_axis(crop_path, frame_idx, axis="y")

            # Apply crop
            cropped = frame[crop_y:crop_y + crop_h, crop_x:crop_x + crop_w]

            # Scale to output dimensions
            if (out_w, out_h) != (crop_w, crop_h):
                cropped = cv2.resize(cropped, (out_w, out_h), interpolation=cv2.INTER_LANCZOS4)

            # Write to FFmpeg pipe
            proc.stdin.write(cropped.tobytes())

            frame_idx += 1
            progress.tick(frame_idx)

    finally:
        cap.release()
        if proc.stdin:
            proc.stdin.close()
        proc.wait()
        stderr_file.close()

        if proc.returncode != 0:
            with open(stderr_file.name, "r") as f:
                stderr_content = f.read()
            os.unlink(stderr_file.name)
            raise RuntimeError(f"FFmpeg failed (code {proc.returncode}): {stderr_content[-500:]}")

        os.unlink(stderr_file.name)

    print(f"  Render complete: {output_path}")
