"""Fuzzy-match Claude's anchor words to exact SRT timestamps.

Three-tier resolution strategy:
1. Exact substring match in transcript text near estimated time
2. Fuzzy sliding window match using rapidfuzz
3. Fallback to Claude's estimated timestamp

All searches constrained to ±search_window around the estimated time
to prevent false matches on common phrases.
"""

import re
from dataclasses import dataclass
from typing import Optional

from rapidfuzz import fuzz

from .srt_parser import Transcript, TranscriptWord


@dataclass
class AnchorMatch:
    """Result of matching an anchor phrase to transcript timestamps."""

    phrase: str
    matched_words: list[TranscriptWord]
    start_sec: float
    end_sec: float
    confidence: float
    match_method: str  # "exact", "fuzzy", "fallback"


@dataclass
class ResolvedClip:
    """A fully resolved clip with validated timestamps."""

    id: int
    title: str
    start_sec: float
    end_sec: float
    duration_sec: float
    transcript_text: str
    start_anchor: AnchorMatch
    end_anchor: AnchorMatch
    resolution_confidence: float
    warning: str = ""


def _normalize(text: str) -> str:
    """Normalize text for matching: lowercase, collapse whitespace, strip punctuation."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text


# Sentence-ending punctuation on a word — used by the end-boundary
# extender. Same regex shape as srt_parser._SENTENCE_ENDINGS but kept
# local so the two modules can evolve independently if needed.
_SENTENCE_END_RE = re.compile(r"[.!?]$")


def _extend_end_to_boundary(
    end_anchor: "AnchorMatch",
    transcript: "Transcript",
    lookahead_sec: float = 2.0,
    pause_threshold_sec: float = 0.6,
) -> tuple[float, str]:
    """Extend the anchor's end_sec forward to the nearest thought boundary.

    Operationalizes the "Let the thought finish" principle from the
    selection framework. Even when the LLM picks slightly-too-early end
    words, this auto-corrects to the next natural break:

      1. A word ending in sentence punctuation (.!?), OR
      2. A gap ≥ pause_threshold_sec between consecutive words (a real
         breath in the speaker's audio, not a sentence-internal beat)

    whichever lands first within `lookahead_sec` of the original end.
    Conservative by design: if no boundary is found in the window, returns
    the original end. The resolver corrects small slips, not bad picks.

    Returns:
        (extended_end_sec, reason) where reason is one of
        "sentence_end", "pause", "already_at_end", "no_boundary_in_window",
        or "no_anchor". The reason is recorded in the resolved clip's
        warning field when extension fires, so creators can audit.
    """
    if not end_anchor.matched_words:
        return end_anchor.end_sec, "no_anchor"

    last_matched = end_anchor.matched_words[-1]
    original_end = end_anchor.end_sec

    # Already lands on a sentence end — no extension needed. The LLM
    # picked clean; don't overshoot into the next sentence.
    if _SENTENCE_END_RE.search(last_matched.word):
        return original_end, "already_at_end"

    # No more words after the anchor (clip is at end of source).
    if last_matched.index + 1 >= len(transcript.words):
        return original_end, "no_boundary_in_window"

    window_end = original_end + lookahead_sec
    prev = last_matched

    for word in transcript.words[last_matched.index + 1:]:
        if word.start_sec > window_end:
            break  # past the lookahead horizon — stop searching

        # Pause check fires FIRST: a real breath between words is the
        # strongest signal of a thought boundary, even when the prior
        # word doesn't have terminal punctuation. Cut at the end of
        # `prev` (last word before the breath), not the start of `word`.
        gap = word.start_sec - prev.end_sec
        if gap >= pause_threshold_sec:
            return prev.end_sec, "pause"

        if _SENTENCE_END_RE.search(word.word):
            return word.end_sec, "sentence_end"

        prev = word

    return original_end, "no_boundary_in_window"


def _build_sliding_windows(
    words: list[TranscriptWord],
    window_size: int,
) -> list[tuple[str, list[TranscriptWord]]]:
    """Build all possible sliding windows of N words from word list."""
    windows = []
    for i in range(len(words) - window_size + 1):
        window_words = words[i:i + window_size]
        text = " ".join(w.word for w in window_words)
        windows.append((_normalize(text), window_words))
    return windows


def resolve_anchor(
    transcript: Transcript,
    anchor_phrase: str,
    estimated_time: float,
    search_window: float = 15.0,
    fuzzy_threshold: float = 75.0,
) -> AnchorMatch:
    """Resolve an anchor phrase to exact transcript timestamps.

    Three-tier matching:
    1. Exact: normalized anchor appears as substring in nearby text
    2. Fuzzy: sliding window with rapidfuzz ratio >= threshold
    3. Fallback: use estimated timestamp, low confidence

    Args:
        transcript: Parsed transcript.
        anchor_phrase: 5-8 words from Claude (verbatim from transcript).
        estimated_time: Claude's estimated timestamp in seconds.
        search_window: Search ±N seconds around estimated time.
        fuzzy_threshold: Minimum rapidfuzz ratio for fuzzy match (0-100).

    Returns:
        AnchorMatch with resolved timestamps and confidence.
    """
    # Get words within search window
    window_start = max(0, estimated_time - search_window)
    window_end = estimated_time + search_window
    nearby_words = transcript.words_between(window_start, window_end)

    if not nearby_words:
        # No words in range — pure fallback
        return AnchorMatch(
            phrase=anchor_phrase,
            matched_words=[],
            start_sec=estimated_time,
            end_sec=estimated_time,
            confidence=0.1,
            match_method="fallback",
        )

    anchor_normalized = _normalize(anchor_phrase)
    anchor_word_count = len(anchor_normalized.split())

    # Tier 1: Exact substring match
    for window_size in [anchor_word_count, anchor_word_count + 1, anchor_word_count - 1]:
        if window_size < 1 or window_size > len(nearby_words):
            continue
        windows = _build_sliding_windows(nearby_words, window_size)
        for window_text, window_words in windows:
            if anchor_normalized in window_text or window_text in anchor_normalized:
                return AnchorMatch(
                    phrase=anchor_phrase,
                    matched_words=window_words,
                    start_sec=window_words[0].start_sec,
                    end_sec=window_words[-1].end_sec,
                    confidence=1.0,
                    match_method="exact",
                )

    # Tier 2: Fuzzy match with rapidfuzz
    best_score = 0.0
    best_match: Optional[tuple[str, list[TranscriptWord]]] = None

    for window_size in [anchor_word_count, anchor_word_count + 1, anchor_word_count - 1]:
        if window_size < 1 or window_size > len(nearby_words):
            continue
        windows = _build_sliding_windows(nearby_words, window_size)
        for window_text, window_words in windows:
            score = fuzz.ratio(anchor_normalized, window_text)
            if score > best_score:
                best_score = score
                best_match = (window_text, window_words)

    if best_match and best_score >= fuzzy_threshold:
        _, matched_words = best_match
        return AnchorMatch(
            phrase=anchor_phrase,
            matched_words=matched_words,
            start_sec=matched_words[0].start_sec,
            end_sec=matched_words[-1].end_sec,
            confidence=round(best_score / 100, 3),
            match_method="fuzzy",
        )

    # Tier 3: Fallback to estimated time
    # Find the nearest word to the estimated time
    nearest = min(nearby_words, key=lambda w: abs(w.start_sec - estimated_time))
    return AnchorMatch(
        phrase=anchor_phrase,
        matched_words=[nearest],
        start_sec=nearest.start_sec,
        end_sec=nearest.end_sec,
        confidence=0.3,
        match_method="fallback",
    )


def resolve_all_clips(
    transcript: Transcript,
    clips_data: list[dict],
    search_window: float = 15.0,
    fuzzy_threshold: float = 75.0,
    padding: float = 1.0,
    min_duration: float = 30.0,
    max_duration: float = 120.0,
    end_extension_enabled: bool = True,
    end_extension_lookahead_sec: float = 2.0,
    end_extension_pause_threshold_sec: float = 0.6,
) -> list[ResolvedClip]:
    """Resolve all clip selections from Claude to exact timestamps.

    Each clip_data dict should contain:
        - id: int
        - title: str (kebab-case)
        - srt_start_words: str (5-8 word anchor)
        - srt_end_words: str (5-8 word anchor)
        - time_start_estimate: float (seconds)
        - time_end_estimate: float (seconds)

    Args:
        transcript: Parsed transcript.
        clips_data: List of clip selection dicts from Claude.
        search_window: ±N seconds search range for anchors.
        fuzzy_threshold: Minimum fuzzy match score (0-100).
        padding: Seconds of breathing room at boundaries.
        min_duration: Minimum clip duration in seconds.
        max_duration: Maximum clip duration in seconds.

    Returns:
        List of ResolvedClip objects, sorted by start time.
    """
    resolved: list[ResolvedClip] = []

    for clip in clips_data:
        clip_id = clip["id"]
        title = clip["title"]

        # Resolve start anchor
        start_anchor = resolve_anchor(
            transcript=transcript,
            anchor_phrase=clip["srt_start_words"],
            estimated_time=clip["time_start_estimate"],
            search_window=search_window,
            fuzzy_threshold=fuzzy_threshold,
        )

        # Resolve end anchor
        end_anchor = resolve_anchor(
            transcript=transcript,
            anchor_phrase=clip["srt_end_words"],
            estimated_time=clip["time_end_estimate"],
            search_window=search_window,
            fuzzy_threshold=fuzzy_threshold,
        )

        # Operationalize "Let the thought finish" — extend end_sec to the
        # nearest sentence-end or ≥pause_threshold gap within lookahead.
        # See selection-framework.md "Core Principle". This is a safety
        # net; if the LLM's pick is already clean, it's a no-op.
        extension_reason = "disabled"
        anchor_end = end_anchor.end_sec
        if end_extension_enabled:
            anchor_end, extension_reason = _extend_end_to_boundary(
                end_anchor=end_anchor,
                transcript=transcript,
                lookahead_sec=end_extension_lookahead_sec,
                pause_threshold_sec=end_extension_pause_threshold_sec,
            )

        # Apply padding
        start_sec = max(0, start_anchor.start_sec - padding)
        end_sec = min(transcript.duration_sec, anchor_end + padding)
        duration = round(end_sec - start_sec, 1)

        # Validation warnings
        warnings = []
        if start_anchor.match_method == "fallback":
            warnings.append(f"start anchor fell back to estimate ({start_anchor.confidence:.0%})")
        if end_anchor.match_method == "fallback":
            warnings.append(f"end anchor fell back to estimate ({end_anchor.confidence:.0%})")
        if extension_reason in ("sentence_end", "pause"):
            extended_by = round(anchor_end - end_anchor.end_sec, 2)
            warnings.append(f"end extended +{extended_by}s to {extension_reason}")
        if duration < min_duration:
            warnings.append(f"duration {duration}s below minimum {min_duration}s")
        if duration > max_duration:
            warnings.append(f"duration {duration}s above maximum {max_duration}s")
        if start_sec >= end_sec:
            warnings.append("start >= end (invalid range)")

        # Combined confidence
        resolution_confidence = round(
            (start_anchor.confidence + end_anchor.confidence) / 2, 3
        )

        # Extract transcript text for this clip
        text = transcript.text_between(start_anchor.start_sec, end_anchor.end_sec)

        resolved.append(ResolvedClip(
            id=clip_id,
            title=title,
            start_sec=round(start_sec, 3),
            end_sec=round(end_sec, 3),
            duration_sec=duration,
            transcript_text=text,
            start_anchor=start_anchor,
            end_anchor=end_anchor,
            resolution_confidence=resolution_confidence,
            warning="; ".join(warnings) if warnings else "",
        ))

    # Sort by start time
    resolved.sort(key=lambda c: c.start_sec)

    # Check for overlaps
    for i in range(1, len(resolved)):
        prev = resolved[i - 1]
        curr = resolved[i]
        if curr.start_sec < prev.end_sec:
            overlap = round(prev.end_sec - curr.start_sec, 1)
            if curr.warning:
                curr.warning += f"; overlaps with clip {prev.id} by {overlap}s"
            else:
                curr.warning = f"overlaps with clip {prev.id} by {overlap}s"

    return resolved
