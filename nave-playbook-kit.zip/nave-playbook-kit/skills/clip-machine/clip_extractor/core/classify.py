"""Deterministic per-SEGMENT source-type classifier (clip-machine v3 §B).

This is the fix for the over-pass-through bug. The engine already detects
per-frame layout / multi-face / shot-width / scene cuts inside `analyze()` and
`layout_detector`, but that machinery was stranded behind the `--format split`
branch in `pipeline.reframe()`, so the default reframe path never saw it and the
upstream LLM gate collapsed whole clips to pass-through.

`build_source_map()` lifts that detection out: it runs the SAME `analyze()`
(multi-face mode so `all_faces` is populated), then derives a per-segment
source-type map by classifying every keyframe into one of five `sourceType`
values and grouping consecutive same-type keyframes into segments:

  full-screen-graphic   facePct < ~15%, no webcam-corner face, ~no faces
  screen-share-1-face   facePct low BUT a webcam-corner face IS detected
  meeting-multi-face    2+ good faces with spatial spread (SPLIT_SCREEN class)
  talking-head          1-2 good faces, large/centered (CLOSE_UP class), healthy facePct
  b-roll                no faces for a sustained span but motion present (not a static graphic)

It does NOT invent new heuristics — it maps the existing
`layout_detector.classify_frame` classes + face-% + corner-webcam scan onto the
five v3 types. Boundaries come from the keyframe grouping plus scene cuts already
recorded on each keyframe (`kf.scene_change`).
"""

from __future__ import annotations

import json
from collections import Counter

from ..detection.layout_detector import classify_frame, LayoutType


# Mirror pipeline._SCREENSHARE_FACE_PCT_THRESHOLD — a clip with face_pct below
# this is a screen-share / graphic candidate (the webcam-corner scan decides
# which). Kept local so classify doesn't import the pipeline screenshare const
# and create a cycle.
SCREENSHARE_FACE_PCT_THRESHOLD = 15.0

# Per-keyframe face-confidence floor for "this keyframe really has a face".
# Matches the spirit of classify_frame's conf>0.3 good-face filter.
_GOOD_FACE_CONF = 0.3

VALID_SOURCE_TYPES = (
    "talking-head",
    "screen-share-1-face",
    "meeting-multi-face",
    "full-screen-graphic",
    "b-roll",
)


def _parse_faces(all_faces_json: str) -> list[dict]:
    if not all_faces_json:
        return []
    try:
        faces = json.loads(all_faces_json)
    except (json.JSONDecodeError, TypeError):
        return []
    return faces if isinstance(faces, list) else []


def _good_faces(faces: list[dict]) -> list[dict]:
    return [f for f in faces if f.get("conf", 0) > _GOOD_FACE_CONF]


def _classify_keyframe(
    kf,
    layout_cfg: dict,
    webcam_corner: dict | None,
    motion_present: bool,
) -> str:
    """Map a single keyframe to one of the 5 v3 sourceTypes.

    Uses the SAME signals the engine already produces:
      - kf.all_faces (multi-face DNN data, populated in split-mode analyze)
      - kf.face_detected / kf.face_confidence (primary face track)
      - layout_detector.classify_frame (SPLIT_SCREEN vs CLOSE_UP)
      - the clip-level webcam-corner scan result
      - whether the clip shows motion (distinguishes b-roll from a static graphic)
    """
    faces = _parse_faces(kf.all_faces)
    good = _good_faces(faces)
    face_count = len(good)
    face_size_threshold = layout_cfg.get("face_size_threshold", 0.06)

    primary_face = bool(kf.face_detected and kf.face_confidence >= _GOOD_FACE_CONF)

    # 2+ good faces with spatial spread → meeting / gallery. classify_frame
    # owns the size+spread thresholds (face_size_threshold / spatial_spread).
    if face_count >= 2:
        layout = classify_frame(
            faces,
            face_size_threshold=face_size_threshold,
            spatial_spread_threshold=layout_cfg.get("spatial_spread_threshold", 0.15),
        )
        if layout == LayoutType.SPLIT_SCREEN:
            return "meeting-multi-face"
        # CLOSE_UP with 2 faces = tight two-shot, still a talking-head treatment.
        return "talking-head"

    # 1 good face. Disambiguate a real talking-head from a screen-share
    # webcam PiP. The split-mode DNN pass (2x upscale) detects the tiny
    # corner webcam on a full-screen-graphic clip as a lone face every frame
    # (clip-02 in the test set: 671/671, median width 0.024), which would
    # mislabel a graphic as talking-head. The reliable signal is SIZE, not
    # position (the upscale+rescale smears a 2.4%-wide face's center toward
    # frame middle, so a corner test is unreliable). A lone face below the
    # gallery face-size floor cannot be a talking head — a real talking-head
    # face is ≥15% frame width (config validation_threshold_pct). Such a
    # tiny lone face, on a clip where the primary MediaPipe track found
    # ~nothing and the corner scan confirmed a PiP, is the webcam →
    # screen-share-1-face; with no corner PiP it's a graphic/b-roll.
    if face_count == 1:
        is_small = good[0].get("w", 1.0) < face_size_threshold
        if is_small and not primary_face:
            if webcam_corner is not None:
                return "screen-share-1-face"
            return "b-roll" if motion_present else "full-screen-graphic"
        return "talking-head"

    if primary_face:
        return "talking-head"

    # No faces this keyframe. Either screen-share-with-corner-webcam,
    # full-screen graphic, or b-roll — disambiguated by the clip-level
    # corner-webcam scan + whether there's motion in the clip.
    if webcam_corner is not None:
        return "screen-share-1-face"
    if motion_present:
        return "b-roll"
    return "full-screen-graphic"


def _smooth(labels: list[str], window: int = 9) -> list[str]:
    """Majority-vote smoothing — same pattern as layout_detector, kills
    single-keyframe classification flicker."""
    n = len(labels)
    out = list(labels)
    half = window // 2
    for i in range(n):
        votes = labels[max(0, i - half): min(n, i + half + 1)]
        if votes:
            out[i] = Counter(votes).most_common(1)[0][0]
    return out


def _reason_for(source_type: str, face_pct: float, face_count: int, webcam_corner: dict | None) -> str:
    if source_type == "meeting-multi-face":
        return f"{face_count} good faces with spatial spread (SPLIT_SCREEN class)"
    if source_type == "talking-head":
        return f"1-2 large/centered faces (CLOSE_UP class), facePct {face_pct:.0f}%"
    if source_type == "screen-share-1-face":
        corner = (webcam_corner or {}).get("corner", "corner")
        return f"low facePct ({face_pct:.0f}%) but webcam face found in {corner}"
    if source_type == "b-roll":
        return f"no sustained face (facePct {face_pct:.0f}%) but motion present"
    return f"facePct {face_pct:.0f}% < {SCREENSHARE_FACE_PCT_THRESHOLD:.0f}%, no webcam corner, ~no faces"


def build_source_map(
    crop_path,
    info,
    config: dict,
    webcam_corner: dict | None,
    *,
    clip_id: str | None = None,
    smoothing_window: int = 9,
    min_segment_sec: float = 1.0,
) -> dict:
    """Derive the per-segment source-map dict from an analyze() result.

    Args:
        crop_path: CropPath returned by analyze() (split mode → all_faces set).
        info: VideoInfo for the analyzed clip.
        config: full loaded config dict.
        webcam_corner: result of pipeline._find_webcam_overlay (or None).
        clip_id: optional clip id string to stamp into the map.
        smoothing_window: majority-vote window for keyframe-label smoothing.
        min_segment_sec: merge segments shorter than this into the previous one.

    Returns:
        dict matching the v3 source-map.json contract.
    """
    keyframes = crop_path.keyframes
    fps = crop_path.source_fps or info.fps
    face_pct = crop_path.detection_stats.face_detected_pct

    layout_cfg = config.get("split_screen", {}).get("dynamic_layout", {})

    # Motion signal: any scene cut in the clip means the source isn't a single
    # static graphic — used to separate b-roll from full-screen-graphic when
    # there are no faces. (Scene detection is on by default in config.yaml.)
    motion_present = any(getattr(kf, "scene_change", False) for kf in keyframes)

    # 1) Per-keyframe classification.
    raw_labels = [
        _classify_keyframe(kf, layout_cfg, webcam_corner, motion_present)
        for kf in keyframes
    ]

    # 2) Smooth out single-keyframe flicker.
    labels = _smooth(raw_labels, smoothing_window) if raw_labels else []

    # 3) Group consecutive same-label keyframes into raw segments, splitting
    #    on scene cuts so a camera cut always starts a new segment boundary.
    raw_segments: list[dict] = []
    if keyframes:
        seg_start = 0
        for i in range(1, len(keyframes) + 1):
            cut = i < len(keyframes) and getattr(keyframes[i], "scene_change", False)
            boundary = (
                i == len(keyframes)
                or labels[i] != labels[seg_start]
                or cut
            )
            if boundary:
                raw_segments.append({
                    "start_idx": seg_start,
                    "end_idx": i - 1,
                    "label": labels[seg_start],
                    "transition": "cut" if (i < len(keyframes) and cut) else None,
                })
                seg_start = i

    # 4) Merge segments shorter than min_segment_sec into the previous one
    #    (carry the previous segment's label — short blips are usually noise).
    min_frames = int(min_segment_sec * fps)
    merged: list[dict] = []
    for seg in raw_segments:
        dur_frames = keyframes[seg["end_idx"]].frame - keyframes[seg["start_idx"]].frame
        if merged and dur_frames < min_frames:
            merged[-1]["end_idx"] = seg["end_idx"]
        else:
            merged.append(seg)

    # 5) Emit the contract segments with per-segment stats.
    out_segments: list[dict] = []
    for seg in merged:
        s, e = seg["start_idx"], seg["end_idx"]
        span = keyframes[s:e + 1]
        from_frame = keyframes[s].frame
        to_frame = keyframes[e].frame
        source_type = seg["label"]

        detected = [kf for kf in span if kf.face_detected and kf.face_confidence >= _GOOD_FACE_CONF]
        seg_face_pct = round(100.0 * len(detected) / len(span), 1) if span else 0.0
        # faceCount = typical good-face count across the span (mode of per-frame counts)
        per_frame_counts = [len(_good_faces(_parse_faces(kf.all_faces))) for kf in span]
        if any(per_frame_counts):
            face_count = Counter(c for c in per_frame_counts if c > 0).most_common(1)[0][0]
        else:
            face_count = 1 if detected else 0

        # Confidence = stability of the label across the span (fraction of
        # keyframes whose raw label matched the final segment label).
        raw_span = raw_labels[s:e + 1]
        confidence = round(sum(1 for r in raw_span if r == source_type) / len(raw_span), 2) if raw_span else 0.0

        wc = webcam_corner if source_type == "screen-share-1-face" else None

        out_segments.append({
            "from": from_frame,
            "to": to_frame,
            "sourceType": source_type,
            "facePct": round(seg_face_pct / 100.0, 3),
            "faceCount": face_count,
            "webcamCorner": (wc.get("corner") if wc else None),
            # The deterministic engine only records hard cuts (scene_change);
            # crossfades are an editor decision made downstream. Every segment
            # boundary is therefore a "cut".
            "transition": "cut",
            "confidence": confidence,
            "reason": _reason_for(source_type, seg_face_pct, face_count, wc),
        })

    source_map = {
        "clipId": clip_id,
        "totalFrames": crop_path.source_total_frames,
        "fps": round(fps, 3),
        "source": {
            "start": None,  # filled by caller (clip offset within full source)
            "end": None,
            "width": info.width,
            "height": info.height,
            "codec": info.codec,
        },
        "faceDetectedPct": face_pct,
        "segments": out_segments,
    }
    return source_map
