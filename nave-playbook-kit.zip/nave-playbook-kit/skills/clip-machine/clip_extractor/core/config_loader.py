"""Load and validate YAML configuration with sensible defaults."""

import os
from pathlib import Path
from typing import Any

import yaml


DEFAULTS = {
    "detection": {
        "face": {
            "enabled": True,
            # See config.yaml for rationale on the three defaults below —
            # tightened 2026-04-21 to close the phantom-detection hole
            # documented in reference/skill-upgrade-phantom-detection.md.
            "min_confidence": 0.60,
            "model_selection": 1,
            "prefer_largest": False,
            "anatomy_y_max": 0.70,
            "dnn_blob_size": 900,
        },
        "pose": {
            "enabled": False,
            "min_confidence": 0.5,
            "body_margin_pct": 0.15,
            "landmark_weights": {"nose": 0.4, "left_shoulder": 0.3, "right_shoulder": 0.3},
        },
        "saliency": {
            "enabled": False,
            "threshold": 0.4,
            "min_area_pct": 0.02,
        },
    },
    "fusion": {
        "face_weight": 0.6,
        "pose_weight": 0.25,
        "saliency_weight": 0.15,
    },
    "sampling": {
        "auto": True,
        "frame_rate": 6,
        "interpolation": "cubic",
    },
    "smoothing": {
        # Tuned 2026-04-22 for talking-head podcast/interview content —
        # see config.yaml comments on each field for the per-change
        # rationale. Summary: Kalman trusts detections ~2.5× faster,
        # rate_limit effectively uncapped (Kalman handles smoothing;
        # rate_limit only gates catastrophic jumps), startup-guard
        # tighter so the clip opens on the speaker in ~300ms.
        "method": "ema",
        "ema": {"alpha": 0.08},
        "kalman": {"process_noise": 0.008, "measurement_noise": 0.06},
        "rate_limit": {"enabled": True, "max_velocity_px_per_frame": 240},
        "startup": {
            "enabled": True,
            "window_keyframes": 3,
            "tolerance_pct": 0.08,
            "min_confident": 2,
        },
    },
    "scene_detection": {
        # Default ON (2026-04-22): needed to trigger smoother/deadzone/
        # velocity_limiter reset on camera cuts (zero-frame speaker-
        # switch snaps under v5 tuning). Also feeds classify_shot_segments
        # which splits shot_segments on scene_change boundaries.
        "enabled": True,
        "threshold": 0.15,
        "min_interval": 30,
    },
    "deadzone": {
        "enabled": True,
        "threshold_pct": 0.10,
        "vertical_threshold_pct": 0.10,
    },
    "crop": {
        "default_format": "9x16",
        "face_position": {"x_target": 0.5, "y_target": 0.38},
        "padding": {"top_pct": 0.15, "bottom_pct": 0.45},
        "boundary_clamp": True,
        "vertical_crop_ratio": 0.92,
        "mouth_centering": {
            "enabled": True,
            # DO NOT change min_face_size_pct without also adjusting
            # validation_threshold_pct — the phantom-rejection in
            # pipeline.py couples these two gates.
            "min_face_size_pct": 0.08,
            "ema_alpha": 0.10,
            "validation_threshold_pct": 0.15,
        },
        # Phase 8: shot-adaptive reframing. See config.yaml for the full
        # rationale + preset vocabulary. Classification always runs
        # (data-only — labels land in crop_path.json); dispatch is
        # guarded by shot_adaptive.enabled.
        "shot_adaptive": {
            "enabled": True,
            "smoothing_window": 9,
            "min_segment_duration": 0.8,
            "crossfade_frames": 2,
        },
        "shot_presets": {
            "wide-far": {
                "max_face_width": 0.10,
                "mouth_centering_enabled": True,
                "y_target": 0.38,
                "deadzone_threshold_pct": 0.08,
                "measurement_noise": 0.10,
            },
            "wide-standard": {
                "max_face_width": 0.20,
                "mouth_centering_enabled": True,
                "y_target": 0.38,
                "deadzone_threshold_pct": 0.10,
                "measurement_noise": 0.15,
            },
            "medium": {
                "max_face_width": 0.30,
                "mouth_centering_enabled": True,
                "y_target": 0.42,
                "deadzone_threshold_pct": 0.12,
                "measurement_noise": 0.20,
            },
            "close-up": {
                "max_face_width": 0.45,
                "mouth_centering_enabled": False,
                "y_target": 0.50,
                "deadzone_threshold_pct": 0.20,
                "measurement_noise": 0.40,
            },
            "tight-close-up": {
                "max_face_width": 1.0,
                "mouth_centering_enabled": False,
                "y_target": 0.50,
                "deadzone_threshold_pct": 0.30,
                "measurement_noise": 0.60,
            },
        },
    },
    "output": {
        "codec": "h264",
        "preset": "medium",
        "crf": 18,
        "use_nvenc": "auto",
        "nvenc_preset": "p4",
        "scale_output": True,
        "generate_debug": False,
    },
    "speakers": {
        "mode": "primary",
        "max_faces": 3,
        "switch_threshold": 0.3,
    },
    "split_screen": {
        "top_ratio": 0.5,
        "face_padding_pct": 1.0,
        "merged_padding_pct": 0.8,
        "min_face_size_pct": 0.0005,
        "merge_distance": 0.20,
        "background": "black",
    },
    "selection": {
        "clip_count": 7,
        "min_duration": 45,
        "max_duration": 90,
        "padding": 1.0,
        "anchor": {
            "search_window_sec": 15.0,
            "min_confidence": 0.5,
            "fuzzy_threshold": 75,
        },
        "scoring": {
            "min_total_score": 50,
        },
    },
}


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base, preferring override values."""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config(config_path: str | None = None) -> dict[str, Any]:
    """Load config from YAML file, merged with defaults.

    Resolution order (each layer overrides the previous):
    1. Built-in DEFAULTS (in this file)
    2. config.yaml from the skill package directory (repo defaults)
    3. User-specified config file (if `config_path` given)
    4. Partner skill override: `{RAY_SKILL_OVERRIDES_DIR}/clip-machine.yaml`
       if that env var is set and the file exists. This is the
       persistence layer that survives container redeploys — the skill
       code + its own config.yaml are baked into the image and reset on
       every deploy, but partner overrides live on the your host volume
       at `/data/workspaces/{partnerId}/.skill-config/` and persist.

    Why the override layer matters: creators and the agent tune per-clip
    parameters (y_target, vertical_crop_ratio, ema_alpha, deadzone
    thresholds, etc.) across iterations. Writing those to the skill's
    own config.yaml works in-session but the edits get wiped on the
    next deploy. Writing to the partner overrides file keeps the
    tuning durable. SKILL.md documents this convention.
    """
    config = DEFAULTS.copy()

    if config_path is None:
        # Look for config.yaml next to this package
        package_dir = Path(__file__).parent.parent
        config_path = str(package_dir / "config.yaml")

    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            user_config = yaml.safe_load(f) or {}
        config = _deep_merge(config, user_config)

    # Partner overrides layer — highest precedence. Silently skipped if
    # the env var is absent (local dev, direct CLI invocation) or the
    # file doesn't exist (partner hasn't tuned anything yet).
    overrides_dir = os.environ.get("RAY_SKILL_OVERRIDES_DIR")
    if overrides_dir:
        override_path = os.path.join(overrides_dir, "clip-machine.yaml")
        if os.path.exists(override_path):
            try:
                with open(override_path, "r") as f:
                    partner_override = yaml.safe_load(f) or {}
                config = _deep_merge(config, partner_override)
            except Exception as err:
                # Bad YAML shouldn't crash the whole render — log and
                # fall through to unmerged config. Creator will still
                # get a working (though un-tuned) render.
                print(f"[clip-extractor] Partner override load failed ({override_path}): {err}", flush=True)

    return config


def get_sample_rate(config: dict, duration_seconds: float) -> int:
    """Determine frame sampling rate based on video duration.

    Shorter videos get more samples (higher quality).
    Longer videos sample less frequently (performance).
    """
    if not config["sampling"]["auto"]:
        return config["sampling"]["frame_rate"]

    if duration_seconds < 300:       # < 5 min
        return 3                     # every 3rd frame (10fps equiv at 30fps)
    elif duration_seconds < 1800:    # < 30 min
        return 6                     # every 6th frame (5fps equiv)
    else:                            # 30+ min
        return 10                    # every 10th frame (3fps equiv)
