# Clip Machine — end-to-end test runbook

The clip machine runs BY HAND via skills + the `clip-editor` agent (no workflow). This is the
validation pass to run inside your Claude Code project runtime before relying on it. Scope examples use the
`your-project` tenant; substitute any scope.

## One-time setup (skip what's already done)

Venvs + node_modules are gitignored — rebuild them on the host:

```bash
# 1. editor venv (python 3.9–3.12; Pillow + numpy)
cd tools/hyperframes/templates/pipeline-clip-pro
python3.12 -m venv .venv && .venv/bin/pip install -r requirements.txt

# 2. hyperframes (pinned 0.6.56)
cd tools/hyperframes && npm install        # must resolve 0.6.56

# 3. reframe-engine venv (mediapipe + the 7 bundled models)
cd .claude/skills/clip-machine
python3.12 -m venv clip_extractor/.venv && clip_extractor/.venv/bin/pip install -r clip_extractor/requirements.txt
```

Then set a real brand color so you can SEE the tailoring (every tenant is `[TBD]` today → renders
neutral `#E0E0E0` + a WARN). In `data/tenants/<scope>/content-production/brand-profile.md`:

```
## Brand Colors
accent: #5DA3E8

## Handle
@enriquemarq-0
```

## The copy-paste prompt

> **Test the clip machine end-to-end on ONE clip, then report what broke.**
>
> The clip machine is run by hand via skills + the `clip-editor` agent (no workflow). Doctrine:
> `.claude/skills/clip-machine/SKILL.md`. Scope = the `your-project` tenant. Do the one-time
> setup above if not done.
>
> Run ONE clip through the manual pipeline (use a short YouTube video or a local mp4; cap to 1 clip,
> hook on):
> `video-download` → `extracting-transcripts` → `clip-selection` (pick 1) → `clip-research-brief` →
> `clip-extractor` (classify + reframe) → `creative-director` → `clip-hook-first` → then hand the
> reframed clip to the **`clip-editor` agent** to brand-resolve + render via the pipeline-clip-pro chain.
>
> Verify the output: ffprobe shows 1080×1920 @30fps + a non-empty audio stream; sample 3 frames and
> LOOK at them — video renders (not black), the caption is on and uses the resolved brand accent
> (`#5DA3E8`), the cover banner is at frame 0, the whoosh SFX is audible at a scene/whip beat, no
> sticker covers the face.
>
> Report: which step (if any) errored, the exact error, and whether the final clip hit the bar vs
> `tools/hyperframes/registry/9x16-editing/showcase-pro/`. Don't fix silently — surface
> every break.

## Fastest sub-test (skip the pipeline, just the editor)

If you already have a clean reframed 9:16 mp4 + its caption wordmap, skip straight to the editor:
invoke the **`clip-editor` agent** with the reframed clip + the scope. It resolves the brand from the
scope `brand-profile.md`, stages inputs, and runs:

```bash
export HF_PYBIN=tools/hyperframes/templates/pipeline-clip-pro/.venv/bin/python \
       BRAND_COLOR=#5DA3E8 CTA_HANDLE=@enriquemarq-0 PROFILE_NAME=Enrique PYTHONUTF8=1
bash tools/hyperframes/templates/pipeline-clip-pro/render_clip.sh \
     <workdir> <reframed.mp4> <words.js> <clip.json> - <out.mp4>
```

## Known-good reference

The editor was smoke-tested clean on hyperframes 0.6.56 (brand color flows through every comp,
native-`<audio>` SFX audible, hermetic GSAP/fonts, not black). The full manual pipeline has NOT yet
been run end-to-end in your Claude Code project runtime — that is what this runbook validates.
