# Clip-Machine v3 — Redesign Spec (the phase-contract source of truth)

> **2026-06-02:** the `clip-machine.js` Workflow and the `clip-machine-run` trigger skill were
> REMOVED. The clip machine is now run BY HAND, skill-by-skill + the `clip-editor` agent (see
> `clip-machine/SKILL.md`). The **phase→phase file contracts below are still authoritative** — they
> describe what each manual step reads/writes. Ignore mentions of "the workflow" / "workflow args" /
> "the inputs gate (§D)"; you supply those inputs yourself when you invoke each step.

**Principle:** every phase→phase handoff is an explicit file contract. No implicit/in-memory handoffs.
No miscommunication.

This supersedes the older v2.1 phase model.

---

## The 7-phase chain (was 5)

| # | Phase | Skill / script | Reads | Writes (CONTRACT) |
|---|---|---|---|---|
| 0 | **Inputs gate** (NEW) | `clip-machine-run` trigger skill | operator answers | workflow args `{source, maxClips, hook}` + resolved `pieceDir`,`tenant` |
| 1 | **Ingest** | video-download → extracting-transcripts | source URL/file | `source/source.mp4`+`.metadata.json`; `transcript/{json,srt,txt}` — **NO moments.json (senses removed)** |
| 2 | **Analysis & Selection** (rename of Brief) | concept (LLM) → clip-selection | transcript, brand-profile, **custom-vocab** | `clips/concept-brief.md`; `clips/clip_definitions.json` (+ **authoritative `burnedInCaptionsDetected` per clip**, + tool-name↔transcript spelling map) |
| 3 | **Reframe** (CORE) | `clip_extractor classify` (NEW, deterministic) → per-clip reframe agent | `source.mp4`, clip ranges | `clips/clip-NN-source-map.json` (per-segment classify); `clips/clip-NN/*` reframed assets; **`clips/clip-NN-reframe.json` (unified metadata contract — see §A)** |
| 4 | **Hook** (NEW, optional default-on) | creative-director (span pick) → reframe (cut hook) | `transcript`, `concept-brief`, source | `clips/clip-NN/clip-NN-hook.mp4` (cut+reframed intro), `hookIntro` in brief |
| 5 | **Edit** | creative-director → hyperframes-edit | `clip-NN-reframe.json`, `clip-NN-body.json` (planning wordmap), brand-profile, reference-composition preset, example library | `clips/editorial-briefs/clip-NN.json`; `clips/clip-NN-edit/index.html`; `clips/clip-NN/clip-NN-final.mp4` (hook+body composed render) |
| 6 | **Re-transcribe FINAL** | extracting-transcripts | `clip-NN-final.mp4` (hook-prepended) | `clips/clip-NN-final.json` (**authoritative** caption wordmap) → captions applied/verified, final render |
| 7 | **Schedule / Post** (replaces Manifest) | content-scheduler (via social-media-publishing) | final clips + scores | per-clip piece `README.md` (`stage: ready`, `keeper_path`, `platforms`, **`platform_drafts.*`, `voice_score`**, `order`, `scheduled_for`) → scheduler dispatched |

**Removed:** video-senses (pre + post). **Demoted:** per-clip confidence scores (kept as a soft signal, NOT a gate).

---

## §A — The Reframe → Edit metadata contract (`clip-NN-reframe.json`)

THE fix for "no miscommunication" + "reframe must pass an analysis to editing." One file per clip, the
editor READS it (not prompt-interpolated in-memory). Replaces the colliding `layouts.json`/`manifest.json`.

```jsonc
{
  "clipId": "01",
  "totalFrames": 1940, "fps": 30,
  "source": { "start": 0.35, "end": 65.0, "width": 1920, "height": 1080, "codec": "h264" },
  "mode": "reframed | raw-for-hyperframes",
  "clipLayout": "single-head | split-2 | split-3 | split-2-bottom | pass-through | letterbox-self-blur",
  "segments": [                          // per-SEGMENT (a clip is rarely one scene-type)
    { "from": 0, "to": 450,
      "sourceType": "talking-head | screen-share-1-face | meeting-multi-face | full-screen-graphic | b-roll",
      "layout": "single-head | split-2 | split-3 | split-2-bottom | pass-through",
      "facePct": 0.94, "faceCount": 1, "webcamCorner": null,
      "transition": "cut | crossfade", "confidence": 0.91, "reason": "..." }
  ],
  "openingThumbnail": "clips/clip-01/first-frame.png",  // IG poster/cover frame the editor holds
  "captionBand": {                       // explicit geometry per layout (editor positions captions deterministically)
    "single-head": { "topPct": 0.62, "bottomPct": 0.88 },
    "split-2":     { "topPct": 0.47, "bottomPct": 0.53 }
  },
  "burnedInCaptionsDetected": false,     // AUTHORITATIVE (decided in Analysis P2; reframe confirms) — was senses' job
  "tailTrim": { "headSec": 0.0, "tailSec": 2.1 },  // migrated from senses post (lead/tail bleed)
  "orig16x9_path": "...", "facecrop_path": "...", "frame_parity_ok": true, "crop": "W:H:X:Y",
  "rendererVersion": "3.0", "generatedAt": "<stamped after run>"
}
```

---

## §B — Reframe: the deterministic classifier (fixes the over-pass-through)

ROOT CAUSE of "we're not reframing": the FIRST gate is a **binary, whole-clip, LLM-eyeball** decision, and
the engine's real per-segment detector (`layout_detector.detect_segments`, `classify_frame`,
`_find_webcam_overlay`) is **gated behind `--format split`** so the default path never runs it.

**Fix:**
1. **NEW `python -m clip_extractor classify --video CLIP --output source-map.json`** — lift `detect_segments`
   out of the split-only branch; run the existing MediaPipe/face-% machinery for ALL formats. Emit per-segment
   `{from,to,sourceType,facePct,faceCount,webcamCorner,confidence}`.
2. **FIRST gate becomes per-SEGMENT + evidence-bound:** `pass-through` allowed for a segment ONLY if it's
   `full-screen-graphic` (confidence ≥ T, facePct < 15%). A clip is whole-clip pass-through **only if EVERY
   segment is full-screen-graphic** (= operator's "unless genuinely full-screen-graphic throughout"). Burned-in
   captions ALONE never trigger pass-through. Talking-head segments always reframe.
3. **LLM = confirmation, not origination:** the agent reads `source-map.json`, Reads frames only at low-confidence
   boundaries, vetoes obvious misses, renders. Determinism owns *what* the source is.
4. **Layouts:** single-head ✅, split-2 ✅ exist; **split-3 (3-up geometry) + split-2-bottom are MISSING** — must
   be built in `split_renderer.py` + `config.yaml`.

---

## §C — Hook (`hookIntro`) vs coldOpenHook — mutually exclusive

| | `hookIntro` (NEW) | `coldOpenHook` (existing) |
|---|---|---|
| What | a 6–15s INTRO sentence that **tells the clip's story + intrigues**, **prepended as new front footage** (span may be OUTSIDE the clip body range) | re-orders the single best phrase ALREADY in the clip to the front (in-clip, no length change) |
| Changes length? | YES → triggers the re-transcribe (P6) | NO |
| Naming | brief key `hookIntro` (camelCase, parallel to `coverCard`/`coldOpenHook`); workflow arg `hook` (bool, default true) | unchanged |

**Rule:** when `hook` is ON (default), `hookIntro` is the front beat and **`coldOpenHook` is suppressed** (else the
money line plays 3×: cover → hook → coldOpen → body). When `hook` OFF → today's `coldOpenHook` behavior.
Front order (hook ON): frame-0 flash (under cover) → coverCard (~1s) → hookIntro → body → endCard.
Disk: `clip-NN-hook.mp4` (cut+reframed hook), `clip-NN-final.mp4` (hook+body), `clip-NN-final.json` (final wordmap).

---

## §D — Inputs gate (`clip-machine-run` trigger skill)

Workflow scripts can't prompt mid-run, so a thin trigger skill asks 3 questions then invokes the workflow:
1. **Video source** (URL or local path) → `url`|`file`
2. **How many clips?** → `maxClips` (6–15; "just 1 to validate" → `limit:1`)
3. **Hook on/off?** → `hook` (bool, default true)

Resolves `pieceDir` (`data/tenants/<tenant>/content-production/in-production/<date>-<slug>/`) + `tenant` (from
`your .env`) so the human never hand-types a timestamped path. Workflow stays arg-driven + tenant-agnostic.

---

## §E — Edit: close the brain↔builder gap

The briefs (creative-director) already spec coverCard / coldOpenHook / captionBand / layout — but the v8
template can't render them. Required builds:
> **SUPERSEDED 2026-06-01:** the v8 `pipeline-clip` template was replaced wholesale by the auto-EDL `pipeline-clip-pro` editor (the coverCard banner is now in-comp at frame 0 in `index.tmpl` #yt-intro). This section is kept for design-history context only.

1. **Extend the v8 pipeline-clip template** (`templates/pipeline-clip/`): add a **coverCard opening-banner comp at
   frame 0** (token-driven `{{COVER_TITLE/SUB/THUMB/HOLD}}`); add **`<img class="thumb">` to the CTA**; add
   **`{{CAPTION_BAND}}` token** so `build.mjs` injects layout-aware caption geometry (kills the hardcoded
   `bottom:320px` + hardcoded `HIDE_DURING`); add reusable terminal-card / brand-card / content-media pop-up slots.
2. **Opening IG banner default:** when source is YouTube → `coverCard` uses the **video's yt-dlp thumbnail +
   channel handle** at frame 0 (today yt-thumbnail is only used on the END card). Wire the fetch to feed the opener.
3. **Creative-director example library** (`creative-director/references/treatment-library.md`): a curated catalog
   of high-quality pop-up/feature/transition exemplars (from snippets.md + the 45 `registry/blocks/`), each with
   "use when" — the selection menu the brain currently lacks. Add a transition vocabulary (curtain/whip-pan/light-leak)
   as selectable brief fields. Fix CD's stale M3 `.tsx` reference → your project snippets.
4. **Brand-profile scope-aware:** `engine.config.json` + `build.mjs` resolve a profile by scope
   (tenant/company/client/project) so client work (a client) carries its own color/handle. Normalize all orange to
   `#FF7614` (kill `#F97316` drift in README + captions.tmpl).

---

## §F — Schedule/Post terminal (replaces the scores manifest)

Reuse the proven **content-scheduler** (hourly, quality-gated, idempotent) — do NOT reimplement Zernio in the
workflow. The terminal's job = emit the scheduler-readable contract + compute order:
- Per clip (confidence ≥ floor) write piece `README.md`: `stage: ready`, `format: short-form-video`,
  `keeper_path: clips/clip-NN-final.mp4`, `platforms`, **`platform_drafts.*` (per-platform caption) + `voice_score ≥ 70`**
  — **REQUIRED or the scheduler silently HOLDS every piece.** ← single biggest integration risk.
- Compute `order` (rank by total_score or narrative) + staggered `scheduled_for` (one per posting window;
  never batch-fire multi-platform — Zernio rule). Then invoke content-scheduler (don't wait the hourly cadence).
- Reconcile floors: clip-machine self-score 95 (render/brand confidence) gates `stage: ready`; scheduler
  quality-gate 85 (6-question publish gate) is a separate downstream gate. Clips 85–94 → `building`/held, not auto-posted.

---

## §G — Senses removal: migrate the 2 load-bearing catches (DO NOT skip)

Removing senses deletes the net that caught real defects in the test run. Migrate both or quality regresses:
- **Caption-truth** (senses found clip-02's claimed "burned-in caption" didn't exist) → decided AUTHORITATIVELY
  in **Analysis (P2)** as `burnedInCaptionsDetected`, carried in `clip-NN-reframe.json`. Reframe confirms, never re-asserts.
- **Lead/tail bleed trim** (senses found tail bleed) → `tailTrim` computed in **Reframe (P3)** from the cut boundaries.

---

## Staged build plan (ship incrementally, each independently testable)

1. **Reframe classifier + per-segment gate** (§B) + the unified `clip-NN-reframe.json` contract (§A) + migrate
   senses caption-truth/tail-trim (§G). ← biggest output-quality win; fixes "we're not reframing."
2. **Template extension** (§E.1–2): cover banner + CTA thumbnail + caption-band token + YT-thumb opener. ← unblocks the briefs that already exist.
3. **Hook phase** (§C) + re-transcribe-final reorder (P6) + the `hook` arg.
4. **Inputs-gate trigger skill** (§D).
5. **Schedule/Post terminal** (§F) + remove the scores-manifest.
6. **CD example library + transition vocab + scope-aware brand-profile** (§E.3–4).
7. Reconcile `meta.phases` (workflow) ↔ `clip-machine/SKILL.md` phase table to the SAME 7 phases/names; remove senses rows.

---

## LOCKED decisions (operator sign-off 2026-05-29)
1. **Hook source = WITHIN-CLIP ONLY.** `hookIntro` is a story-tease line selected from inside the clip's own
   range, cut and prepended to the front (plays 2× — once as the framing intro, once in-body), so it still
   adds length → the re-transcribe-final (P6) still applies. It is effectively a richer `coldOpenHook` (a 6–15s
   story-frame vs the single best phrase). **`hookIntro` and `coldOpenHook` are the SAME front beat** — when
   `hook` is ON, the front beat is the `hookIntro` story-tease; do NOT also run a separate coldOpenHook. No
   new footage from elsewhere, no written/VO line.
2. **Schedule/Post = STAGE-AND-WAIT.** The terminal computes `order` + staggered `scheduled_for`, writes the
   full scheduler contract per clip (`stage: ready`, `keeper_path`, `platforms`, `platform_drafts.*`,
   `voice_score`), but does **NOT** auto-invoke content-scheduler — it leaves clips staged and **waits for the
   operator's explicit go** before anything posts. (§F's "invoke immediately" is overridden by this.)
3. **Build order = REFRAME-FIRST, as specced.** Stage 1 = reframe classifier + per-segment gate + the
   `clip-NN-reframe.json` contract + senses-catch migration.
